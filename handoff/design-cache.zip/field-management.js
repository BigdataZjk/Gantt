// Requester aliases are presentation mappings; original requirement values remain traceable.
function installFieldManagement(product,config){
  const {getGroups,getValues,canManage,save,escape,icons}=config,doc=product.ownerDocument;
  const panel=product.querySelector('[data-settings-panel="fields"]');
  const layer=doc.createElement('div');layer.className='fm-layer';layer.hidden=true;
  layer.innerHTML='<button type="button" class="gm-scrim" data-fm-close aria-label="关闭字段管理面板"></button><section class="fm-dialog" role="dialog" aria-modal="true" aria-label="维护提需人集合"></section>';
  product.append(layer);let selected=new Set(),returnFocus=null,editingId=null;
  const entries=()=>[...new Set([...getValues().map(item=>item.value),...getGroups().flatMap(group=>group.aliases)])].filter(Boolean).sort((a,b)=>a.localeCompare(b,'zh-CN'));
  const display=value=>getGroups().find(group=>group.aliases.includes(value)||group.displayName===value)?.displayName||value;
  const close=()=>{layer.hidden=true;product.querySelector('.gm-base').inert=false;returnFocus?.focus({preventScroll:true});};
  function render(){
    const groups=getGroups(),values=entries(),editable=canManage();selected=new Set([...selected].filter(value=>values.includes(value)));
    panel.innerHTML=`<div class="fm-tabs" role="tablist" aria-label="可维护的字段"><button type="button" role="tab" aria-selected="true">提需人</button></div><div class="fm-actions"><button type="button" class="gm-btn" data-fm-create ${editable?'':'disabled'}>新建集合</button><button type="button" class="gm-btn gm-primary" data-fm-merge ${editable&&selected.size?'':'disabled'}>合并 / 加入集合</button><span class="gm-caption" data-fm-count>${selected.size?'已选 '+selected.size+' 个名称':''}</span></div><div class="fm-group-list">${groups.map(group=>`<button type="button" class="fm-group" data-fm-edit="${escape(group.id)}" ${editable?'':'disabled'}><span>${escape(group.displayName)}</span><small>${group.aliases.length?group.aliases.length+' 个名称':'空集合'}</small></button>`).join('')}</div><div class="gm-table-wrap"><table class="gm-table fm-table" aria-label="提需人名称与展示集合"><thead><tr><th><input type="checkbox" data-fm-all aria-label="全选提需人名称" ${editable&&values.length?'':'disabled'}></th><th>原始名称</th><th>统一展示为</th><th>关联需求</th></tr></thead><tbody>${values.map(value=>`<tr><td><input type="checkbox" data-fm-value="${escape(value)}" aria-label="选择${escape(value)}" ${selected.has(value)?'checked':''} ${editable?'':'disabled'}></td><td>${escape(value)}</td><td><span class="fm-display">${escape(display(value))}</span></td><td>${getValues().filter(item=>item.value===value).length}</td></tr>`).join('')||'<tr><td colspan="4">暂无提需人名称，可先新建集合。</td></tr>'}</tbody></table></div><p class="gm-caption fm-note">统一展示名，保留原始录入。${editable?'':'仅超级管理员可维护。'}</p>`;
    syncSelection();icons();
  }
  function syncSelection(){
    const values=entries(),all=panel.querySelector('[data-fm-all]');if(!all)return;
    all.checked=Boolean(values.length)&&values.every(value=>selected.has(value));all.indeterminate=selected.size>0&&!all.checked;
    panel.querySelector('[data-fm-merge]').disabled=!canManage()||!selected.size;
    panel.querySelector('[data-fm-count]').textContent=selected.size?'已选 '+selected.size+' 个名称':'';
  }
  function open(group=null,merge=false){
    if(!canManage())return;
    editingId=group?.id||null;
    returnFocus=doc.activeElement;const groups=getGroups(),aliases=group?[...group.aliases]:merge?[...selected]:[];
    layer.querySelector('section').innerHTML=`<div class="fm-dialog-head"><h3>${group?'维护集合':merge?'合并名称':'新建集合'}</h3><button type="button" class="gm-btn gm-quiet" data-fm-close aria-label="关闭字段管理面板"><i data-lucide="x" aria-hidden="true"></i></button></div><label class="fm-field">目标集合<select data-fm-target><option value="">新建集合</option>${groups.map(item=>`<option value="${escape(item.id)}" ${group?.id===item.id?'selected':''}>${escape(item.displayName)}</option>`).join('')}</select></label><label class="fm-field"><span>统一展示名 <span class="gm-required">*</span></span><input type="text" data-fm-name list="fm-existing-names" value="${escape(group?.displayName||'')}" placeholder="例如：小林 或 林林" maxlength="40"><datalist id="fm-existing-names">${entries().map(value=>`<option value="${escape(value)}"></option>`).join('')}</datalist></label><label class="fm-field">集合中的名称<textarea data-fm-aliases rows="4" placeholder="每行一个名称，也可以留空">${escape(aliases.join('\n'))}</textarea></label><p class="gm-caption">可加入已有集合，也可新增名称。需求中的原始录入会保留。</p><p class="fm-error" role="alert" hidden></p><div class="fm-dialog-actions"><button type="button" class="gm-btn" data-fm-close>取消</button><button type="button" class="gm-btn gm-primary" data-fm-save>保存集合</button></div>`;
    layer.hidden=false;product.querySelector('.gm-base').inert=true;icons();layer.querySelector('[data-fm-name]').focus({preventScroll:true});
  }
  panel.addEventListener('change',event=>{if(!canManage())return;const input=event.target;if(input.hasAttribute('data-fm-all')){selected=new Set(input.checked?entries():[]);for(const checkbox of panel.querySelectorAll('[data-fm-value]'))checkbox.checked=input.checked;}else if(input.hasAttribute('data-fm-value')){input.checked?selected.add(input.dataset.fmValue):selected.delete(input.dataset.fmValue);}syncSelection();});
  panel.addEventListener('click',event=>{const button=event.target.closest('button');if(!button)return;if(button.hasAttribute('data-fm-create'))open();if(button.hasAttribute('data-fm-merge'))open(null,true);if(button.dataset.fmEdit)open(getGroups().find(group=>group.id===button.dataset.fmEdit));});
  layer.addEventListener('change',event=>{if(event.target.hasAttribute('data-fm-target')){const target=getGroups().find(group=>group.id===event.target.value);if(target)layer.querySelector('[data-fm-name]').value=target.displayName;}});
  layer.addEventListener('click',event=>{
    if(event.target.closest('[data-fm-close]')){close();return;}
    if(!event.target.closest('[data-fm-save]')||!canManage())return;
    const name=layer.querySelector('[data-fm-name]').value.trim(),error=layer.querySelector('.fm-error');
    if(!name){error.textContent='请填写统一展示名';error.hidden=false;layer.querySelector('[data-fm-name]').focus();return;}
    const groups=JSON.parse(JSON.stringify(getGroups())),chosen=layer.querySelector('[data-fm-target]').value,target=groups.find(group=>group.id===chosen)||groups.find(group=>group.displayName===name),aliases=[...new Set(layer.querySelector('[data-fm-aliases]').value.split(/[\n,，;；]+/).map(value=>value.trim()).filter(Boolean))],id=target?.id||'group-'+Date.now().toString(36);
    const collision=groups.find(group=>group.displayName===name&&group.id!==id);
    if(collision){error.textContent='这个展示名已有集合，请在目标集合中选择它';error.hidden=false;return;}
    const members=new Set([...(editingId===target?.id?[]:target?.aliases||[]),...aliases]);
    if(target&&target.displayName!==name&&getValues().some(item=>item.value===target.displayName))members.add(target.displayName);
    const next=groups.filter(group=>group.id!==id).map(group=>({...group,aliases:group.aliases.filter(value=>!members.has(value))}));
    next.push({id,displayName:name,aliases:[...members]});close();selected.clear();save(next,name);render();
  });
  layer.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}if(event.key==='Tab'){const nodes=[...layer.querySelector('section').querySelectorAll('input,select,textarea,button:not(:disabled)')];if(event.shiftKey&&event.target===nodes[0]){event.preventDefault();nodes.at(-1).focus();}else if(!event.shiftKey&&event.target===nodes.at(-1)){event.preventDefault();nodes[0].focus();}}});
  return {render,display};
}

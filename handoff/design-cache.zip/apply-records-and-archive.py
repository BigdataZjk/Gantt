from pathlib import Path
import re

p = Path(__file__).parent
file = p / 'requirement-modal-study.html'
s = file.read_text(encoding='utf-8')
backup = p / 'requirement-modal-study-before-records.html'
if not backup.exists():
    backup.write_text(s, encoding='utf-8')


def replace_once(before, after):
    global s
    assert s.count(before) == 1, (before[:100], s.count(before))
    s = s.replace(before, after, 1)


# Reorder existing nodes, keeping identifiers, permissions and remembered active tab.
start = s.index('<nav class="gm-settings-nav"')
end = s.index('</nav>', start)
old = s[start:end]
buttons = dict(re.findall(r'(<button type="button" data-settings-tab="([^"]+)"[^>]*>.*?</button>)', old))
by_key = {key: markup for markup, key in buttons.items()}
opening = old[:old.index('<button')]
s = s[:start] + opening + ''.join(by_key[key] for key in ['roles', 'fields', 'personal', 'logs', 'versions']) + s[end:]
replace_once("设置子页:['角色权限','个性化','版本记录','操作记录','字段管理']", "设置子页:['角色权限','字段管理','个性化','操作记录','版本记录']")
replace_once("记录范围:'版本、操作记录与最近50步撤回为全系统共用，保留操作者'", "记录范围:'全系统共用；操作记录保留最近200条，最近50条内的数据变更支持撤回，保留操作者'")

replace_once("settingsTab:'roles',fieldCatalog:", "settingsTab:'roles',logPagination:{page:1,pageSize:20},fieldCatalog:")
replace_once('settingsTab:s.settingsTab,versions:clone(s.versions)', 'settingsTab:s.settingsTab,logPagination:{...s.logPagination},versions:clone(s.versions)')
replace_once('settingsTab:s.settingsTab,accountQuery:s.accountQuery', 'settingsTab:s.settingsTab,logPagination:{...s.logPagination},accountQuery:s.accountQuery')
replace_once("if(['roles','personal','versions','logs','fields'].includes(pref.settingsTab))s.settingsTab=pref.settingsTab;", "if(['roles','personal','versions','logs','fields'].includes(pref.settingsTab))s.settingsTab=pref.settingsTab;\n    if(pref.logPagination&&typeof pref.logPagination==='object')s.logPagination={...pref.logPagination};")
replace_once("if(s.undoHistory.length>50)s.undoHistory.shift();s.lastAction=action+'：'+target;", "trimOperationHistory();s.logPagination.page=1;s.lastAction=action+'：'+target;")
replace_once("function recordOperation(action,target,changes=[]){s.logs.unshift({id:newId(),time:new Date().toISOString(),actor,action,target,changes});s.lastAction=action+'：'+target;}", "function recordOperation(action,target,changes=[]){s.logs.unshift({id:newId(),time:new Date().toISOString(),actor,action,target,changes});trimOperationHistory();s.logPagination.page=1;s.lastAction=action+'：'+target;}")
replace_once('if(Array.isArray(saved.undoHistory))s.undoHistory=clone(saved.undoHistory).slice(-50);', 'if(Array.isArray(saved.undoHistory))s.undoHistory=clone(saved.undoHistory).slice(-50);trimOperationHistory();')
start = s.index('  function renderLogs(){')
end = s.index('  function renderSettings(){', start)
s = s[:start] + (p / 'operation-records.js').read_text(encoding='utf-8') + '\n' + s[end:]
replace_once("if(kind==='undo'){const index=s.undoHistory.findIndex(step=>step.id===id),entry=s.logs.find(entry=>entry.id===id);return index>=0&&entry&&{title:'撤回至此操作前'", "if(kind==='undo'){if(!canUndoLog(id))return null;const index=s.undoHistory.findIndex(step=>step.id===id),entry=s.logs.find(entry=>entry.id===id);return index>=0&&entry&&{title:'撤回到此动作'")
replace_once("else if(kind==='undo'){const index=s.undoHistory.findIndex(step=>step.id===id);if(index<0)return;", "else if(kind==='undo'){if(!canUndoLog(id))return;const index=s.undoHistory.findIndex(step=>step.id===id);if(index<0)return;")
replace_once("if(button.dataset.logDetails){", "if(button.hasAttribute('data-log-page')){setLogPage(button.dataset.logPage);return;}\n    if(button.dataset.logDetails){")
replace_once("const input=event.target;if(input.hasAttribute('data-requirement-default'))", "const input=event.target;if(input.hasAttribute('data-log-page-size')){setLogPageSize(input);return;}if(input.hasAttribute('data-requirement-default'))")
replace_once("app.addEventListener('input',event=>{\n    const input=event.target;", "app.addEventListener('input',event=>{\n    const input=event.target;\n    if(input.hasAttribute('data-log-page-size')){input.setCustomValidity('');return;}")
replace_once("app.addEventListener('keydown',event=>{\n    if(event.target.matches('[data-demand-tab]')", "app.addEventListener('keydown',event=>{\n    if(event.target.hasAttribute('data-log-page-size')&&event.key==='Enter'){event.preventDefault();setLogPageSize(event.target);return;}\n    if(!s.mode&&event.target.hasAttribute('data-archive-details')&&event.key==='Enter'){event.preventDefault();openArchiveDetails(event.target.dataset.archiveDetails);return;}\n    if(event.target.matches('[data-demand-tab]')")

# Archived names still open a detail dialog, but are never editable.
old_name = '<button type="button" class="gm-link" data-edit="${row.id}" data-requirement-name="${row.id}" aria-haspopup="menu" ${canEdit()?\'\':\'disabled\'}>${esc(row.name)}</button>'
new_name = '<button type="button" class="gm-link" ${row.archived?`data-archive-details="${row.id}" aria-label="${esc(row.name)}，双击查看详情"`:`data-edit="${row.id}"`} data-requirement-name="${row.id}" aria-haspopup="${row.archived?\'dialog\':\'menu\'}" ${row.archived||canEdit()?\'\':\'disabled\'}>${esc(row.name)}</button>'
replace_once(old_name, new_name)
replace_once('  function renderDrawer(){', (p / 'archive-details.js').read_text(encoding='utf-8') + '\n  function renderDrawer(){')
replace_once("if(s.mode.startsWith('account-')){renderAccountDrawer();return;}", "if(s.mode.startsWith('account-')){renderAccountDrawer();return;}\n    if(s.mode==='archive-details'){renderArchiveDetails();return;}")
replace_once("function openEditor(mode,id){\n    if(!canEdit())return;", "function openEditor(mode,id){\n    if(!canEdit())return;\n    if(mode==='edit'&&!s.rows.some(row=>row.id===Number(id)&&!row.archived&&!row.deleted))return;")
replace_once("if(!['create','edit'].includes(s.mode)||!s.draft||s.closing||!canEdit())return;const invalidSchedule=", "if(!['create','edit'].includes(s.mode)||!s.draft||s.closing||!canEdit())return;\n    if(s.mode==='edit'&&!s.rows.some(row=>row.id===s.draft.id&&!row.archived&&!row.deleted))return;const invalidSchedule=")
replace_once("const button=event.target.closest('button[data-edit]');if(button&&canEdit())", "const archived=event.target.closest('button[data-archive-details]');if(archived){event.preventDefault();openArchiveDetails(archived.dataset.archiveDetails);return;}\n    const button=event.target.closest('button[data-edit]');if(button&&canEdit())")
replace_once("window.addEventListener('resize',()=>{if(['create','edit'].includes(s.mode))setDemandTab(activeDemandTab);});", "window.addEventListener('resize',()=>{if(['create','edit','archive-details'].includes(s.mode))setDemandTab(activeDemandTab);});")
replace_once("if(s.mode==='create'){s.draft=clone(s.newDraft);renderDrawer();}", "if(s.mode==='create'){s.draft=clone(s.newDraft);renderDrawer();}\n    else if(s.mode==='archive-details')renderArchiveDetails();")
replace_once("s.lastAction=mode==='create'?'收起并保留新增草稿':'收起并丢弃编辑修改';", "s.lastAction=mode==='create'?'收起并保留新增草稿':mode==='archive-details'?'收起归档详情':'收起并丢弃编辑修改';")
replace_once("mode==='edit'?'未保存的编辑已放弃':'已取消'", "mode==='edit'?'未保存的编辑已放弃':mode==='archive-details'?'':'已取消'")

start = s.index('  async function copyRequirementLink(name){')
end = s.index('  function setDemandTab(', start)
copy_function = '''  async function copyRequirementLink(name){
    const input=drawer.querySelector(`[name="${name}"]`),link=drawer.querySelector(`[data-archive-link="${name}"]`),feedback=drawer.querySelector(`[data-link-feedback="${name}"]`);
    const value=String(input?.value||link?.getAttribute('href')||link?.textContent||'').trim();if(!value)return;let copied=false;
    try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(value);copied=true;}}catch{}
    if(!copied){const current=app.ownerDocument.activeElement;
      if(input){input.focus();input.select();}
      else if(link){const selection=app.ownerDocument.getSelection(),range=app.ownerDocument.createRange();range.selectNodeContents(link);selection.removeAllRanges();selection.addRange(range);}
      try{copied=app.ownerDocument.execCommand('copy');}catch{}current?.focus({preventScroll:true});
    }
    if(feedback?.isConnected)feedback.textContent=copied?'已复制':'请选择链接后按 Ctrl / ⌘ + C 复制';
  }
'''
s = s[:start] + copy_function + s[end:]
replace_once('<script>', '<style>\n' + (p / 'records-and-archive.css').read_text(encoding='utf-8') + '\n</style>\n<script>')
assert len(s.encode('utf-8')) < 1_000_000
file.write_text(s, encoding='utf-8')
print('Updated settings order, paginated audit log and read-only archive detail:', len(s.encode('utf-8')), 'bytes')

const assert=require('node:assert/strict');
const {chromium}=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir='C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
function contrastAudit(product){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=1;
 const context=canvas.getContext('2d',{willReadFrequently:true});
 const rgba=color=>{context.clearRect(0,0,1,1);context.fillStyle=color;context.fillRect(0,0,1,1);return [...context.getImageData(0,0,1,1).data];};
 const luminance=color=>{const v=color.slice(0,3).map(x=>{const c=x/255;return c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4);});return v[0]*.2126+v[1]*.7152+v[2]*.0722;};
 function background(node){if(!node)return [255,255,255];const own=rgba(getComputedStyle(node).backgroundColor);if(own[3]===255)return own;const parent=background(node.parentElement),a=own[3]/255;return own.slice(0,3).map((v,i)=>v*a+parent[i]*(1-a));}
 return [...product.querySelectorAll('.pc-count,.pc-axis-name,.pc-person small,.pc-person b,.pc-nav button,.pc-user .pc-role,.pc-create,[data-panel="pool"] .pc-dictionary,[data-panel="pool"] .pc-priority')].filter(node=>node.getClientRects().length).map(node=>{const a=luminance(rgba(getComputedStyle(node).color)),b=luminance(background(node));return {label:node.textContent.trim(),contrast:(Math.max(a,b)+.05)/(Math.min(a,b)+.05)};});
}
(async()=>{const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});try{
 const page=await browser.newPage({viewport:{width:1060,height:1100},colorScheme:'light'});await page.goto('file:///'+dir+'palette-preview-qa.html');const ui=page.frameLocator('iframe');await ui.locator('.viz-carousel-controls').waitFor();const names=await ui.locator('[data-variant]').evaluateAll(nodes=>nodes.map(e=>e.dataset.variant)),failures=[];let checked=0;
 for(const [index,name] of names.entries()){
  if(index){await ui.locator('.viz-carousel-picker summary').click();await ui.locator('.viz-carousel-options button').filter({hasText:name}).click();}
  const product=ui.locator('.viz-carousel > [data-variant]:not([hidden]) .pc-product');
  for(let pass=0;pass<2;pass++){
   for(const view of ['gantt','pool']){await product.locator(`[data-view="${view}"]`).click();for(const item of await product.evaluate(contrastAudit)){checked++;if(item.contrast<4.5)failures.push({name,dark:await product.locator('[data-theme]').getAttribute('aria-checked'),...item});}}
   await product.locator('[data-theme]').click();
  }
 }
 assert.deepEqual(failures,[]);console.log('Passed '+checked+' foreground/background text contrast checks across all 10 palettes, both themes and both demand views.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});

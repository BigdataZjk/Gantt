const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 1000 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-14T12:00:00+08:00'));
    page.setDefaultTimeout(5000); const errors = []; page.on('pageerror', error => errors.push(error.message));
    const fragment = fs.readFileSync(dir + 'requirement-modal-study.html', 'utf8');
    await page.route('http://gantt-continuous.test/**', route => route.fulfill({ contentType: 'text/html; charset=utf-8', body: '<!doctype html><html><head><meta charset="utf-8"></head><body><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve();}};</script>' + fragment + '</body></html>' }));
    await page.goto('http://gantt-continuous.test/');
    const nav = value => page.locator(`[data-nav="${value}"]`).click();
    const read = () => page.evaluate(() => JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    await nav('gantt'); const base = await read();
    const row = (state, id) => state.rows.find(row => row.id === id);
    const load = async (edit = () => {}) => {
      const data = structuredClone(base); data.revision = (await read()).revision + 1000;
      data.logs = []; data.undoHistory = []; data.actor = '张金科'; data.view = 'gantt'; data.ganttRange = { start: '2026-11-09', end: '2026-12-14' };
      edit(data);
      await page.evaluate(async saved => { window.dispatchEvent(new CustomEvent('openai:set_globals', { detail: { globals: { widgetState: { privateContent: saved } } } })); await new Promise(requestAnimationFrame); }, data);
      await nav('gantt'); return data;
    };
    const cell = (id, date) => page.locator(`tr[data-gantt-row="${id}"] td[data-date="${date}"]`);
    const name = id => page.locator(`[data-gantt-name="${id}"]`);
    const selected = () => page.locator('tr[data-sequence-selected="true"]').evaluateAll(rows => rows.map(row => Number(row.dataset.ganttRow)));
    const point = async locator => { const box = await locator.boundingBox(); assert(box); return { x: box.x + box.width / 2, y: box.y + box.height / 2 }; };
    const resize = async (id, phase, edge, date, during, targetId = id) => {
      const a = await point(page.locator(`tr[data-gantt-row="${id}"] [data-bar-phase="${phase}"] [data-resize-edge="${edge}"]`));
      const b = await point(cell(targetId, date)); await page.mouse.move(a.x, a.y); await page.mouse.down(); await page.mouse.move(b.x, b.y, { steps: 6 });
      if (during) await during(); await page.mouse.up();
    };
    const move = async (id, from, to, targetId = id) => {
      const a = await point(cell(id, from).locator('.gm-bar-piece')), b = await point(cell(targetId, to));
      await page.mouse.move(a.x, a.y); await page.mouse.down({ button: 'right' }); await page.mouse.move(b.x, b.y, { steps: 5 }); await page.mouse.up({ button: 'right' });
    };
    const menu = (id, date) => cell(id, date).click({ button: 'right' });
    const close = async () => { await page.locator('.gm-drawer [data-dismiss]').first().click(); await page.locator('.gm-layer').waitFor({ state: 'hidden' }); };
    const unchangedOthers = (state, before, id) => assert.deepEqual(state.rows.filter(value => value.id !== id), before.rows.filter(value => value.id !== id));

    await load();
    assert.equal(await page.locator('.gm-calendar input[type="checkbox"]').count(), 0);
    assert.equal(await page.locator('.gm-gantt-batchbar').count(), 0);
    assert.equal(await page.locator('[data-sequence-preview]:visible').count(), 0);
    const a = await cell(1, '2026-11-16').locator('.gm-bar-piece').boundingBox(), b = await cell(1, '2026-11-17').locator('.gm-bar-piece').boundingBox();
    assert(Math.abs(a.x + a.width - b.x) < .5, 'Adjacent days form a visually continuous bar');
    assert.equal(await cell(1, '2026-11-17').locator('.gm-bar-piece').evaluate(el => getComputedStyle(el).borderRadius), '0px');
    assert.equal(await cell(1, '2026-11-16').locator('.gm-bar-piece').evaluate(el => getComputedStyle(el).borderTopLeftRadius), '5px');
    assert.equal(await cell(1, '2026-11-18').locator('.gm-bar-piece').evaluate(el => getComputedStyle(el).borderTopRightRadius), '5px');
    assert.equal(await cell(1, '2026-11-17').evaluate(el => getComputedStyle(el).borderLeftWidth), '0px');
    assert.equal(await page.locator('.gm-parallel-symbol').first().evaluate(el => getComputedStyle(el).backgroundColor), 'rgba(0, 0, 0, 0)');

    const original = await load();
    await resize(1, 0, 'end', '2026-11-20', async () => { assert.deepEqual((await read()).rows, original.rows); assert.equal((await read()).logs.length, 0); });
    let state = await read(); assert.equal(row(state, 1).days, 5); assert.equal(row(state, 1).start, '2026-11-16'); assert.equal(state.logs.length, 1); assert.equal(state.logs[0].action, '拉伸排期'); unchangedOthers(state, original, 1);
    await load(); await resize(1, 0, 'start', '2026-11-13'); state = await read(); assert.equal(row(state, 1).start, '2026-11-13'); assert.equal(row(state, 1).days, 4);
    assert.equal(await cell(1, '2026-11-14').locator('.gm-bar-piece.gm-inactive').count(), 1, 'Weekend is faded, not a broken bar');
    assert.equal(await cell(1, '2026-11-14').locator('[data-phase]').count(), 0);
    await load(); await resize(1, 0, 'end', '2026-11-21'); assert.equal(row(await read(), 1).days, 5, 'Resize snaps to Friday instead of inventing overtime');
    await load(); await resize(1, 0, 'start', '2026-11-17'); assert.equal(row(await read(), 1).days, 2);
    await load(); await resize(1, 0, 'end', '2026-11-17'); assert.equal(row(await read(), 1).days, 2);
    await load(); await resize(1, 0, 'end', '2026-11-15'); assert.deepEqual((await read()).rows, base.rows, 'Cannot remove the whole phase by crossing its start');
    await load(); await resize(1, 0, 'end', '2026-11-20', undefined, 2); assert.deepEqual((await read()).rows, base.rows, 'Cannot resize across requirement rows');
    await load(data => { row(data, 1).dayMarks = { '2026-11-25': 'leave' }; });
    await resize(1, 0, 'end', '2026-11-30'); state = await read(); assert.equal(row(state, 1).days, 10); assert.deepEqual(row(state, 1).skippedDates, ['2026-11-25']);
    assert.equal(await cell(1, '2026-11-30').locator('[data-phase]').count(), 1); assert.equal(await cell(1, '2026-11-25').locator('.gm-bar-piece.gm-inactive').count(), 1);
    await page.reload(); await page.locator('tr[data-gantt-row="1"]').waitFor(); assert.equal(await cell(1, '2026-11-30').locator('[data-phase]').count(), 1, 'Resize survives refresh');

    await load(); await resize(3, 0, 'end', '2026-11-20'); assert.deepEqual((await read()).rows, base.rows, 'HOLD cannot be filled by resizing');
    await load(data => { row(data, 3).segments[1].holdBefore = false; }); await resize(3, 0, 'end', '2026-11-30'); state = await read();
    assert.equal(row(state, 3).segments[0].end, '2026-11-20'); assert.equal(row(state, 3).segments[1].start, '2026-11-23'); assert.equal(row(state, 3).days, 7);
    await load(); await resize(3, 1, 'end', '2026-11-27'); state = await read(); assert.equal(row(state, 3).segments[0].end, '2026-11-17'); assert.equal(row(state, 3).segments[1].holdBefore, true); assert.equal(row(state, 3).days, 7);
    await load(); await move(1, '2026-11-16', '2026-11-19'); state = await read(); assert.equal(row(state, 1).start, '2026-11-19'); assert.equal(row(state, 1).days, 3); assert(await page.locator('.gm-day-menu').isHidden()); unchangedOthers(state, base, 1);
    await load(); await move(3, '2026-11-16', '2026-11-23'); assert.deepEqual((await read()).rows, base.rows, 'Moving a phase cannot overlap its sibling');
    await load(); await move(1, '2026-11-16', '2026-11-19', 2); assert.deepEqual((await read()).rows, base.rows);
    await load(); await resize(1, 0, 'end', '2026-11-30', async () => { await page.keyboard.press('Escape'); }); assert.deepEqual((await read()).rows, base.rows, 'Escape cancels resize preview');

    await load(); await menu(1, '2026-11-16'); assert.equal(await page.locator('[data-day-mark="overtime"]').count(), 0); await page.locator('[data-day-mark="leave"]').click();
    assert.equal(await cell(1, '2026-11-16').locator('.gm-bar-piece.gm-inactive').count(), 1); assert.equal(row(await read(), 1).days, 3);
    await menu(1, '2026-11-16'); await page.locator('[data-day-mark="cancel-leave"]').click();
    await menu(1, '2026-11-21'); assert.equal(await page.locator('[data-day-mark="leave"]').count(), 0); await page.locator('[data-day-mark="overtime"]').click();
    await menu(1, '2026-11-21'); await page.locator('[data-day-mark="cancel-overtime"]').click(); assert.equal(row(await read(), 1).days, 3);
    await load(data => Object.assign(row(data, 1), { start: '2026-11-13', overtime: ['2026-11-14'] }));
    await menu(1, '2026-11-14'); await page.locator('[data-day-mark="cancel-overtime"]').click();
    assert.equal(await cell(1, '2026-11-14').locator('.gm-bar-piece.gm-inactive').count(), 1); assert.equal(row(await read(), 1).start, '2026-11-13'); assert.equal(row(await read(), 1).days, 3);
    for (const date of ['2026-11-21', '2026-11-22']) assert.equal(await cell(3, date).locator('[data-mark="hold"]').count(), 0);

    await load(data => { data.rows = data.rows.slice(0, 3).map((value, index) => { const result = { ...value, developer: '张金科', start: ['2026-11-16', '2026-11-17', '2026-11-19'][index], days: 3 }; delete result.segments; return result; }); });
    await name(1).click(); assert.deepEqual(await selected(), [1]); assert(await page.locator('.gm-layer').isHidden(), 'Single click selects instead of editing');
    await name(3).click({ modifiers: ['Control'] }); assert.deepEqual(await selected(), [1, 3]);
    await name(2).click({ modifiers: ['Shift'] }); assert.deepEqual(await selected(), [2, 3]);
    await name(1).click({ modifiers: ['Meta'] }); assert.deepEqual(await selected(), [1, 2, 3]);
    await name(2).click({ button: 'right' }); assert.deepEqual(await selected(), [1, 2, 3]); assert(await page.locator('[data-sequence-preview]').isEnabled());
    await page.locator('[data-sequence-preview]').click(); await close(); assert.equal((await read()).logs.length, 0);
    await name(1).dblclick(); await page.locator('.gm-drawer [name="name"]').waitFor(); assert.equal(await page.locator('.gm-drawer [name="name"]').inputValue(), row(await read(), 1).name); await close();
    await name(1).focus(); await page.keyboard.press('F2'); await page.locator('.gm-drawer [name="name"]').waitFor(); await close();
    await nav('pool'); const pooled = page.locator('.gm-requirement-table tr[data-row="1"] [data-edit]'); await pooled.click(); assert(await page.locator('.gm-layer').isHidden()); await pooled.dblclick(); await page.locator('.gm-drawer [name="name"]').waitFor(); await close();

    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00'));
    await load(data => { Object.assign(row(data, 1), { start: '2026-11-16', days: 5, segments: [{ start: '2026-11-16', end: '2026-11-18' }, { start: '2026-11-23', end: '2026-11-24', holdBefore: true }] }); });
    assert(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count() > 0);
    assert.equal(await page.locator('tr[data-gantt-row="1"] [data-bar-phase="1"] .gm-floating-point').count(), 0);
    await menu(1, '2026-11-17'); await page.locator('[data-day-mark="leave"]').click(); assert.equal(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count(), 0);
    await load(); await page.emulateMedia({ reducedMotion: 'reduce' }); assert.equal(await page.locator('.gm-floating-point').first().evaluate(el => getComputedStyle(el).animationName), 'none'); await page.emulateMedia({ reducedMotion: 'no-preference' });
    await load(data => { data.actor = '孙莉'; }); assert.equal(await page.locator('[data-resize-edge]').count(), 0); assert.equal(await page.locator('[data-sequence-preview]:visible').count(), 0);
    await load();
    for (const width of [1024, 736, 360, 320]) { await page.setViewportSize({ width, height: 1000 }); assert(await page.locator('.gm-app').evaluate(el => el.scrollWidth <= el.clientWidth + 1), 'Layout overflow at ' + width); }
    assert.deepEqual(errors, []);
    console.log('Passed: continuous bars, faded non-working days, both resize edges, shrinking, collision/HOLD guards, leave/calendar math, right dragging, day toggles, modifier selection, context-only sequencing, double-click/F2 editing, particles, persistence, audit, permissions and responsive layout.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });

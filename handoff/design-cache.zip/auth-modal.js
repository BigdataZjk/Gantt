// Efferd Auth Page study: mirrored FloatingPaths, adapted to the existing product modal.
function installAuthModal(product,{accounts,current,guest,passwords,onLogin,onLogout,beforeOpen,escape,icons}){
  const doc=product.ownerDocument,base=product.querySelector('.gm-base'),layer=doc.createElement('div');
  layer.className='gm-auth-layer';layer.hidden=true;
  layer.innerHTML='<button type="button" class="gm-scrim gm-auth-scrim" data-auth-close aria-label="关闭登录窗口"></button><section class="gm-auth-dialog" role="dialog" aria-modal="true" aria-labelledby="gm-auth-title"></section>';
  product.append(layer);
  let returnFocus=null,wasInert=false;
  function paths(){
    return [1,-1].map(position=>`<svg class="gm-auth-paths" viewBox="0 0 696 316" fill="none" aria-hidden="true">${Array.from({length:36},(_,i)=>{
      const d=`M-${380-i*5*position} -${189+i*6}C-${380-i*5*position} -${189+i*6} -${312-i*5*position} ${216-i*6} ${152-i*5*position} ${343-i*6}C${616-i*5*position} ${470-i*6} ${684-i*5*position} ${875-i*6} ${684-i*5*position} ${875-i*6}`;
      return `<path d="${d}" pathLength="1" stroke="currentColor" stroke-width="${(.5+i*.03).toFixed(2)}" stroke-opacity="${Math.min(1,.1+i*.03).toFixed(2)}" style="--gm-path-duration:${20+(i*7+(position===1?0:3))%11}s;--gm-path-delay:-${(i*1.7+(position===1?0:8)).toFixed(1)}s"/>`;
    }).join('')}</svg>`).join('');
  }
  function close(restoreFocus=true){
    if(layer.hidden)return;
    layer.hidden=true;base.inert=wasInert;
    layer.querySelector('section').replaceChildren();
    if(restoreFocus&&returnFocus?.isConnected&&!returnFocus.closest('[inert]'))returnFocus.focus({preventScroll:true});
  }
  function open(){
    if(current()!==guest||!layer.hidden||beforeOpen?.()===false)return;
    returnFocus=doc.activeElement;wasInert=base.inert;
    layer.querySelector('section').innerHTML=`<aside class="gm-auth-art" aria-label="排一下"><div class="gm-auth-graphic" aria-hidden="true">${paths()}</div><div class="gm-auth-brand"><i data-lucide="calendar-range" aria-hidden="true"></i><span>排一下</span></div><div class="gm-auth-art-copy"><p>把需求排好，<br>一起从容推进。</p></div></aside><div class="gm-auth-content"><button type="button" class="gm-btn gm-quiet gm-auth-close" data-auth-close aria-label="关闭登录窗口"><i data-lucide="x" aria-hidden="true"></i></button><form class="gm-auth-form"><div class="gm-auth-heading"><h2 id="gm-auth-title">登录排一下</h2><p>使用已有账号继续协作</p></div><div class="gm-field"><label for="gm-auth-username">用户名</label><input id="gm-auth-username" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required></div>${passwords.fieldMarkup('gm-auth-password','密码','autocomplete="current-password" required')}<p class="gm-auth-error" role="alert" hidden></p><button type="submit" class="gm-btn gm-primary gm-auth-submit">登录</button></form></div>`;
    layer.hidden=false;base.inert=true;icons();layer.querySelector('#gm-auth-username').focus({preventScroll:true});
  }
  function clearError(){const error=layer.querySelector('.gm-auth-error');if(!error)return;error.hidden=true;for(const input of layer.querySelectorAll('input')){input.removeAttribute('aria-invalid');input.removeAttribute('aria-describedby');}}
  function showError(message,target='gm-auth-password'){
    const error=layer.querySelector('.gm-auth-error');error.id='gm-auth-error';error.textContent=message;error.hidden=false;
    const input=layer.querySelector('#'+target);input.setAttribute('aria-invalid','true');input.setAttribute('aria-describedby',error.id);input.focus({preventScroll:true});
  }
  function submit(event){
    event.preventDefault();event.stopPropagation();
    const name=layer.querySelector('#gm-auth-username').value.trim(),secret=layer.querySelector('#gm-auth-password').value;
    const account=accounts().find(account=>account.name===name);
    if(!account||account.status==='已删除'){showError('用户名或密码不正确','gm-auth-username');return;}
    if(account.status!=='启用'){showError('账号已停用，请联系超级管理员','gm-auth-username');return;}
    if(!passwords.has(name)){showError('请先由超级管理员设置初始密码');return;}
    if(!passwords.verify(name,secret)){showError('用户名或密码不正确');return;}
    close(false);onLogin(name);product.querySelector('[data-current-user-avatar]')?.focus({preventScroll:true});
  }
  layer.addEventListener('submit',submit);
  layer.addEventListener('input',event=>{event.stopPropagation();clearError();});
  layer.addEventListener('change',event=>event.stopPropagation());
  layer.addEventListener('click',event=>{if(event.target.closest('[data-auth-close]')){event.stopPropagation();close();}});
  layer.addEventListener('keydown',event=>{
    event.stopPropagation();
    if(event.key==='Escape'){event.preventDefault();close();return;}
    if(event.key!=='Tab')return;
    const nodes=[...layer.querySelector('section').querySelectorAll('input,button:not(:disabled)')].filter(node=>node.getClientRects().length);
    if(event.shiftKey&&doc.activeElement===nodes[0]){event.preventDefault();nodes.at(-1)?.focus();}
    else if(!event.shiftKey&&doc.activeElement===nodes.at(-1)){event.preventDefault();nodes[0]?.focus();}
  });
  product.addEventListener('click',event=>{
    if(event.target.closest('[data-auth-login]'))open();
    if(event.target.closest('[data-auth-logout]')&&current()!==guest){close(false);onLogout();product.querySelector('[data-current-user-avatar]')?.focus({preventScroll:true});}
  });
  return {open,close,sync(){if(!layer.hidden&&current()!==guest)close(false);}};
}

  function actualAdmission(row){return row.segments?.length?row.segments.map(phase=>phase.start).filter(validDate).sort()[0]||'9999-12-31':validDate(row.start)?row.start:'9999-12-31';}
  function orderedGanttRows(rows,person){
    const stored=s.ganttRowOrder?.[person],order=Array.isArray(stored)?stored:[],rank=new Map(order.map((id,index)=>[Number(id),index]));
    return rows.sort((a,b)=>(rank.get(a.id)??Infinity)-(rank.get(b.id)??Infinity)||actualAdmission(a).localeCompare(actualAdmission(b))||a.id-b.id);
  }
  function selectedAdmissionSortNeeded(){
    const groups=new Map();for(const node of app.querySelectorAll('[data-screen="gantt"] tr[data-gantt-row]:not([hidden])')){const row=s.rows.find(row=>row.id===Number(node.dataset.ganttRow));if(!row||!sequenceIds.has(row.id))continue;if(!groups.has(row.developer))groups.set(row.developer,[]);groups.get(row.developer).push(row);}
    return [...groups.values()].some(rows=>rows.some((row,index)=>index&&actualAdmission(rows[index-1])>actualAdmission(row)));
  }
  function sortSelectedByAdmission(){
    if(!isAdmin()||s.mode||sequenceIds.size<2||!selectedAdmissionSortNeeded())return;
    for(const person of new Set(s.rows.filter(row=>sequenceIds.has(row.id)).map(row=>row.developer))){
      const rows=orderedGanttRows(s.rows.filter(row=>!row.deleted&&!row.archived&&row.developer===person),person),sorted=rows.filter(row=>sequenceIds.has(row.id)).sort((a,b)=>actualAdmission(a).localeCompare(actualAdmission(b))||a.id-b.id);let index=0;
      s.ganttRowOrder={...s.ganttRowOrder,[person]:rows.map(row=>sequenceIds.has(row.id)?sorted[index++].id:row.id)};
    }
    closeDayMenu();renderGanttGrid();persist(false);message('已按准入日期升序排列，排期日期未改变');
  }
  function normalTimelineDayWidth(){const height=parseFloat(getComputedStyle(app).getPropertyValue('--gm-row-height'))||38;return Math.max(window.matchMedia('(pointer:coarse)').matches?48:24,height-14)*1.125;}
  function timelineAvailableWidth(){const wrap=app.querySelector('[data-screen="gantt"] .gm-calendar-wrap'),main=app.querySelector('.gm-main');return Math.max(40,(wrap?.clientWidth||main.clientWidth-40)-192);}
  function timelineMinimumZoom(){return Math.min(1,Math.max(1.25,timelineAvailableWidth()/365)/normalTimelineDayWidth());}
  function timelineDayWidth(){return normalTimelineDayWidth()*Math.min(1,Math.max(timelineMinimumZoom(),Number(s.ganttZoom)||1));}
  function zoomedAxisEnd(){
    const normal=s.ganttRange.end||shiftDate(today(),30);if((Number(s.ganttZoom)||1)>=.999)return normal;
    const start=axisStart(),baseDays=Math.max(1,calendarOffset(start,normal)+1),visibleDays=s.ganttZoom<=timelineMinimumZoom()+.00001?365:Math.min(365,Math.ceil(timelineAvailableWidth()/timelineDayWidth()));return shiftDate(start,Math.max(baseDays,visibleDays)-1);
  }
  function applyTimelineZoom(){
    s.ganttZoom=Math.min(1,Math.max(timelineMinimumZoom(),Number(s.ganttZoom)||1));
    if(s.ganttZoom>=.999){s.ganttZoom=1;app.style.removeProperty('--gm-day-width');}else app.style.setProperty('--gm-day-width',timelineDayWidth()+'px');
    const width=timelineDayWidth();app.dataset.ganttScale=width>=20?'day':width>=8?'week':width>=4?'fortnight':'month';
    const reset=app.querySelector('[data-gantt-zoom-reset]');if(reset)reset.hidden=s.ganttZoom===1;
  }
  function ganttDateHeaders(dates,currentDate){
    const width=timelineDayWidth(),spacing=Math.max(1,Math.ceil(20/width));let last=-spacing;
    return dates.map((date,index)=>{const day=Number(date.slice(-2)),candidate=width>=20||index===0&&width>=4||day===1||width>=8&&parseDate(date).getUTCDay()===1||width>=4&&width<8&&day===15,tick=candidate&&index-last>=spacing;if(tick)last=index;
      return `<th class="gm-date ${workday(date)?'':'gm-rest'} ${date===currentDate?'gm-current':''} ${date.endsWith('-01')?'gm-month-day-start':''} ${date===dates.at(-1)&&advance(date).endsWith('-01')?'gm-month-day-end':''}" data-axis-date="${date}" data-month-alternate="${Number(date.slice(5,7))%2}" data-axis-tick="${tick}" scope="col" ${date===currentDate?'aria-current="date"':''} aria-label="${date}${date===currentDate?'，今天':''}"><span class="gm-date-label" aria-hidden="true">${tick?day:''}</span></th>`;
    }).join('');
  }
  let timelineZoomFrame=0,timelineZoomDelta=0,timelineZoomPointer=0,timelineZoomSave=0;
  function zoomTimelineFromWheel(event){
    const wrap=event.target.closest('.gm-calendar-wrap');if(!wrap||s.view!=='gantt'||(!event.ctrlKey&&!event.metaKey))return;
    event.preventDefault();if(s.mode||pointerDrag||pointerResize||pointerAdd)return;
    timelineZoomDelta+=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?600:1);timelineZoomPointer=event.clientX;
    if(timelineZoomFrame)return;
    timelineZoomFrame=requestAnimationFrame(()=>{
      timelineZoomFrame=0;const before=timelineDayWidth(),rect=wrap.getBoundingClientRect(),offset=Math.max(0,timelineZoomPointer-rect.left-192),anchor=(wrap.scrollLeft+offset)/before,next=Math.min(1,Math.max(timelineMinimumZoom(),s.ganttZoom*Math.exp(-timelineZoomDelta*.0025)));timelineZoomDelta=0;
      if(Math.abs(next-s.ganttZoom)<.00001)return;s.ganttZoom=next;renderGanttGrid();wrap.scrollLeft=Math.max(0,anchor*timelineDayWidth()-offset);
      clearTimeout(timelineZoomSave);timelineZoomSave=setTimeout(()=>persist(false),150);
    });
  }
  function resetTimelineZoom(){if(s.ganttZoom===1)return;s.ganttZoom=1;renderGanttGrid();app.querySelector('.gm-calendar-wrap').scrollLeft=0;persist(false);message('已恢复默认比例和缩放前的日期范围');}

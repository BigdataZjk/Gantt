const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1220, height: 1100 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00'));
    page.setDefaultTimeout(5000); const errors = []; page.on('pageerror', error => errors.push(error.message));
    const fragment = fs.readFileSync(dir + 'requirement-modal-study.html', 'utf8');
    await page.route('http://gantt-current.test/**', route => route.fulfill({ contentType: 'text/html; charset=utf-8', body: '<!doctype html><meta charset="utf-8"><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve()}};</script>' + fragment }));
    await page.goto('http://gantt-current.test/');
    const nav = view => page.locator(`[data-nav="${view}"]`).click();
    const read = () => page.evaluate(() => JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    const ids = () => page.locator('tr[data-gantt-row]:not([hidden])').evaluateAll(nodes => nodes.map(node => Number(node.dataset.ganttRow)).sort((a,b) => a-b));
    const cell = (id,date) => page.locator(`tr[data-gantt-row="${id}"] td[data-date="${date}"]`);
    const style = id => page.locator(`tr[data-gantt-row="${id}"]`).getAttribute('style');
    await nav('gantt'); const base = await read();
    const load = async (edit = () => {}) => {
      const data = structuredClone(base); data.revision = (await read()).revision + 1000;
      Object.assign(data, { actor:'张金科',view:'gantt',logs:[],undoHistory:[],versions:[],collapsedPeople:[],ganttRange:{start:'2026-11-09',end:'2026-12-14'},personalPreferences:{} });
      data.filters = {domain:[],developer:[],requestType:[],status:[],query:'',priority:'',start:'',end:''}; edit(data);
      await page.evaluate(async saved => { window.dispatchEvent(new CustomEvent('openai:set_globals',{detail:{globals:{widgetState:{privateContent:saved}}}})); await new Promise(requestAnimationFrame); },data);
      await nav('gantt'); return data;
    };
    const filter = async (key,values,apply = true) => {
      await page.locator(`[data-core-filter-toggle="${key}"]`).click(); await page.locator('[data-core-filter-all]').check(); await page.locator('[data-core-filter-all]').uncheck();
      for (const value of values) await page.locator('[data-core-filter-option]').filter({}).evaluateAll((nodes,val) => { const node=nodes.find(el=>el.dataset.coreFilterOption===val); if(!node)throw Error('Missing option '+val);node.click(); },value);
      if(apply)await page.locator('[data-core-filter-apply]').click();
    };
    const finish = async target => { await target.evaluate(async el => { await new Promise(requestAnimationFrame); for(const animation of el.getAnimations({subtree:true})) if(animation instanceof CSSTransition)animation.finish(); }); };
    const setting = async tab => { await nav('roles'); await page.locator(`[data-settings-tab="${tab}"]`).click(); };
    await load();
    const create = page.locator('[data-new]'),glow=create.locator('.gm-hover-glow');
    assert.equal(await page.locator('canvas[data-fluid-canvas]').count(),0);
    assert(await glow.evaluate(el=>{const diameter=el.getBoundingClientRect().width||parseFloat(getComputedStyle(el).width),width=el.parentElement.clientWidth;return diameter>width&&diameter<width*1.5;}),'Compact light keeps a local bright spot');
    assert.equal(await glow.evaluate(el=>getComputedStyle(el).opacity),'0.5');
    const rect=await create.boundingBox();
    await page.mouse.move(rect.x+12,rect.y+10); await finish(create);
    const left=await glow.evaluate(el=>({left:parseFloat(getComputedStyle(el).left),top:parseFloat(getComputedStyle(el).top),scale:new DOMMatrix(getComputedStyle(el).transform).a,duration:getComputedStyle(el).transitionDuration}));
    assert(Math.abs(left.left-12)<1&&Math.abs(left.top-10)<1); assert.equal(left.scale,1.2); assert.equal(left.duration,'0.4s');
    await page.mouse.move(rect.x+rect.width-10,rect.y+rect.height-9);
    assert(await glow.evaluate((el,x)=>Math.abs(parseFloat(getComputedStyle(el).left)-x)<1,rect.width-10));
    assert.equal(await create.evaluate(el=>getComputedStyle(el).transitionDuration),'0.3s');
    const glowRGB=await create.evaluate(el=>getComputedStyle(el).getPropertyValue('--gm-glow-color'));
    assert(!glowRGB.includes('00ffc3'),'Reference emerald was replaced by product blue');
    await page.mouse.move(8,8); await finish(create); assert.equal(await glow.evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).a),0);
    await page.keyboard.press('Tab'); await create.focus(); await finish(create); assert.equal(await glow.evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).a),1.2,'Keyboard focus reveals glow');
    await create.click(); assert(await page.locator('.gm-layer').isVisible()); await page.locator('.gm-scrim[data-dismiss]').click(); await page.locator('.gm-layer').waitFor({state:'hidden'});
    console.log('Passed: author-matched pointer-follow glow, sizing/timing, leave/focus and existing create action.');

    await load(); const initial=await read();
    await filter('status',['待开发','开发中'],false); assert.deepEqual(await ids(),initial.rows.map(r=>r.id).sort((a,b)=>a-b)); assert.deepEqual((await read()).filters,initial.filters); assert.equal((await read()).logs.length,0);
    await page.locator('[data-core-filter-cancel]').click();
    await filter('status',['待开发','开发中']);
    const statusIds=initial.rows.filter(r=>['待开发','开发中'].includes(r.status)).map(r=>r.id).sort((a,b)=>a-b); assert.deepEqual(await ids(),statusIds);
    await filter('developer',['张金科','李明']);
    const combined=initial.rows.filter(r=>['待开发','开发中'].includes(r.status)&&['张金科','李明'].includes(r.developer)).map(r=>r.id).sort((a,b)=>a-b); assert.deepEqual(await ids(),combined);
    await page.reload(); assert.deepEqual(await ids(),combined); assert.deepEqual((await read()).filters.developer,['张金科','李明']);
    await nav('pool'); assert.equal(await page.locator('.gm-requirement-table tr[data-row]').count(),combined.length); await nav('gantt');
    await page.locator('[data-core-filter-toggle="status"]').click(); await page.locator('[data-core-filter-all]').check(); await page.locator('[data-core-filter-apply]').click();
    assert.deepEqual((await read()).filters.status,[]); assert((await page.locator('[data-core-filter-toggle="status"]').textContent()).includes('全部'));
    await page.locator('[data-core-filter-toggle="status"]').click(); assert.equal(await page.locator('[data-core-filter-option]:checked').count(),5); await page.keyboard.press('Escape');
    await filter('developer',[]); assert.deepEqual((await read()).filters.developer,[]); assert.deepEqual(await ids(),initial.rows.map(r=>r.id).sort((a,b)=>a-b)); assert.equal((await read()).logs.length,0);
    await load(data=>{data.filters.developer='李明';}); assert.deepEqual(await ids(),base.rows.filter(r=>r.developer==='李明').map(r=>r.id).sort((a,b)=>a-b));
    await load(data=>{data.accountRows.push({name:'王,工',role:'编辑者',status:'启用'});data.rows[0].developer='王,工';}); await filter('developer',['王,工']); assert.deepEqual(await ids(),[1]); assert.deepEqual((await read()).filters.developer,['王,工']);
    console.log('Passed: deferred multi-filter application, OR/AND, cancel, all/none, cross-view refresh memory and legacy/punctuation compatibility.');

    await load(); const presets=page.locator('.gm-axis-presets'),end=page.locator('[data-axis-edge="end"]'); assert(await presets.isHidden());
    await end.hover(); assert(await presets.isVisible()); const endBox=await end.boundingBox(),presetBox=await presets.boundingBox();
    await page.mouse.move(presetBox.x+20,endBox.y+endBox.height/2,{steps:12}); await page.waitForTimeout(460); assert(await presets.isVisible(),'Travel to presets is safe');
    const start=await page.locator('[data-axis-edge="start"]').inputValue(); await page.locator('[data-axis-days="60"]').click(); assert.equal(await page.locator('[data-axis-edge="start"]').inputValue(),start); assert.equal(await end.inputValue(),'2027-01-16');
    await page.mouse.move(3,500); assert(await presets.evaluate(el=>el.hidden||el.classList.contains('gm-presets-closing'))); await page.waitForTimeout(110); assert(await presets.isHidden());
    await end.hover(); await page.mouse.move(3,500); await page.waitForTimeout(100); await end.hover(); await page.waitForTimeout(460); assert(await presets.isVisible(),'Returning cancels hiding');
    await page.mouse.move(3,500); await page.waitForTimeout(470); await page.keyboard.press('Tab'); await end.focus(); assert(await presets.isVisible());
    for(let step=0;step<5&&!await page.locator('[data-axis-days="30"]').evaluate(el=>el===document.activeElement);step++)await page.keyboard.press('Tab');
    assert(await page.locator('[data-axis-days="30"]').evaluate(el=>el===document.activeElement));
    await load(data=>{data.ganttRange={start:'2026-11-01',end:'2026-12-31'};});
    for(const key of ['2026-11','2026-12']){
      const month=page.locator(`[data-month="${key}"]`),label=month.locator('.gm-month-label'),a=await month.boundingBox(),b=await label.boundingBox();
      assert(Math.abs((b.x+b.width/2)-(a.x+a.width/2))<1); assert(await month.locator('.gm-month-left.gm-month-boundary').count()===1&&await month.locator('.gm-month-right.gm-month-boundary').count()===1);
    }
    await load(data=>{data.ganttRange={start:'2026-11-09',end:'2026-12-14'};});
    assert.equal(await page.locator('[data-month="2026-11"] .gm-month-left.gm-month-boundary').count(),0); assert.equal(await page.locator('[data-month="2026-12"] .gm-month-right.gm-month-boundary').count(),0);
    console.log('Passed: end-date reveal, safe corridor, immediate/reversible hiding, keyboard operation, end-only presets and month dimensions.');

    await load(); const clean=await read();
    for(const domain of ['流量域','广告域']){const group=clean.rows.filter(row=>row.domain===domain),styles=await Promise.all(group.map(row=>style(row.id)));assert(styles.every(value=>value===styles[0]),'Same domain matches across developers');}
    const untouched=await style(clean.rows.find(r=>r.domain==='流量域').id);
    await setting('personal'); assert.equal(await page.locator('input[data-reduce-motion]').count(),0); await page.locator('[data-domain-color-open="广告域"]').dblclick();
    assert(await page.locator('[data-color-preview] .gm-color-schedule-bar').isVisible()); await page.locator('[data-color-hex]').fill('#7755CC'); assert.equal((await read()).logs.length,0); await page.locator('[data-color-save]').click();
    assert.equal((await read()).domainColorOverrides['广告域'],'#7755cc'); assert.equal((await read()).logs.length,1);
    await nav('gantt'); for(const row of clean.rows.filter(r=>r.domain==='广告域'))assert((await style(row.id)).includes('#7755cc')); assert.equal(await style(clean.rows.find(r=>r.domain==='流量域').id),untouched);
    await page.reload(); assert.equal((await read()).domainColorOverrides['广告域'],'#7755cc');
    for(const actor of ['李明','__guest__']){await load(data=>{data.actor=actor;});await setting('personal');assert(await page.locator('[data-domain-color-open="广告域"]').isDisabled());}
    await load(data=>{data.rows[0].domain='';});assert.equal(await page.locator('tr[data-gantt-row="1"]').getAttribute('data-domain-hue'),'');
    await load(); const beforeTheme=await read(); assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'light');
    await page.locator('[data-theme-toggle]').click(); assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'dark');
    assert.equal(await page.locator('[data-theme-toggle]').getAttribute('aria-checked'),'true'); await page.reload();assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'dark');
    await page.emulateMedia({colorScheme:'light'});assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'dark','Manual appearance wins');
    assert.deepEqual((await read()).logs,beforeTheme.logs);await page.locator('[data-theme-toggle]').click(); assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'light');
    await load(data=>{data.actor='__guest__';}); await page.locator('[data-theme-toggle]').click(); assert.equal(await page.locator('#gm-ui-study').evaluate(el=>el.style.colorScheme),'dark'); await page.locator('[data-new]').hover({force:true}); await finish(create);assert.equal(await glow.evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).a),0,'Disabled guest button has no glow');
    console.log('Passed: shared domain palette, admin-only modal editing, audit, refresh, neutral unassigned domain, removed setting and remembered theme for members/guests.');

    await load(data=>{
      data.ganttRange={start:'2026-09-25',end:'2026-11-30'};
      Object.assign(data.rows[0],{start:'2026-11-13',days:2,segments:[{start:'2026-11-13',end:'2026-11-13'},{start:'2026-11-16',end:'2026-11-16',holdBefore:true}]});
      Object.assign(data.rows[1],{start:'2026-11-13',days:0,segments:[{start:'2026-11-13',end:'2026-11-13'},{start:'2026-11-16',end:'2026-11-17',holdBefore:false}]});
      Object.assign(data.rows[2],{start:'2026-09-30',days:2,segments:[{start:'2026-09-30',end:'2026-09-30'},{start:'2026-10-08',end:'2026-10-08',holdBefore:true}]});
      Object.assign(data.rows[3],{start:'2026-11-13',days:3,dayMarks:{'2026-11-16':'leave'}});
      Object.assign(data.rows[4],{start:'2026-11-13',days:0,dayMarks:{'2026-11-16':'leave'}});
    }); const beforeBridge=await read();
    for(const id of [1,2])for(const date of ['2026-11-14','2026-11-15']){const tile=cell(id,date).locator('.gm-bar-bridge');assert(await tile.count()===1);assert.equal(await tile.getAttribute('data-bar-phase'),null);assert.equal(await cell(id,date).locator('[data-mark="hold"]').count(),0);assert(await tile.evaluate(el=>Math.abs(el.getBoundingClientRect().height-(el.closest('td').getBoundingClientRect().height-1))<.6));}
    for(const date of ['2026-10-01','2026-10-07'])assert.equal(await cell(3,date).locator('.gm-bar-bridge').count(),1);
    for(const id of [4,5]){assert(await cell(id,'2026-11-16').evaluate(el=>getComputedStyle(el).backgroundColor!=='rgba(0, 0, 0, 0)'));assert.equal(await cell(id,'2026-11-16').locator('.gm-bar-piece').evaluate(el=>getComputedStyle(el).backgroundColor),'rgba(0, 0, 0, 0)');}
    const before=await cell(1,'2026-11-13').locator('.gm-bar-piece').evaluate(el=>getComputedStyle(el).borderTopRightRadius);assert.equal(before,'0px','Bridge removes the interior corner');
    await page.reload();assert.deepEqual((await read()).rows,beforeBridge.rows);assert.deepEqual((await read()).logs,beforeBridge.logs);
    await load(data=>{data.ganttRange={start:'2026-11-09',end:'2026-11-30'};Object.assign(data.rows[0],{start:'2026-11-13',days:3});}); assert.equal(await cell(1,'2026-11-14').locator('.gm-bar-piece.gm-inactive').count(),1);
    await page.emulateMedia({reducedMotion:'reduce'});await create.hover();assert.equal(await glow.evaluate(el=>getComputedStyle(el).transitionDuration),'0s');await page.emulateMedia({reducedMotion:'no-preference'});
    console.log('Passed: normal/estimated/weekend/holiday visual connections, true HOLD distinction, full grey personal leave and unchanged schedule/audit.');

    await page.goto('file:///'+dir+'modal-preview-qa.html'); const ui=page.frameLocator('iframe');await ui.locator('[data-nav="gantt"]').click();
    await ui.locator('[data-axis-edge="start"]').fill('2026-11-12');await ui.locator('[data-axis-edge="end"]').fill('2026-12-04');
    await ui.locator('[data-new]').hover();await finish(ui.locator('[data-new]'));await ui.locator('.gm-app').screenshot({path:dir+'hover-glow-gantt-light-qa.png'});
    await ui.locator('[data-theme-toggle]').click();await ui.locator('[data-new]').hover();await finish(ui.locator('[data-new]'));await ui.locator('.gm-app').screenshot({path:dir+'hover-glow-gantt-dark-qa.png'});
    for(const width of [736,360,320]){await page.setViewportSize({width,height:1100});assert(await ui.locator('.gm-app').evaluate(el=>el.scrollWidth<=el.clientWidth+1));await ui.locator('[data-core-filter-toggle="status"]').click();assert(await ui.locator('.gm-core-filter-menu').evaluate(el=>{const a=el.getBoundingClientRect(),b=el.closest('.gm-app').getBoundingClientRect();return a.left>=b.left&&a.right<=b.right;}));await page.keyboard.press('Escape');}
    assert.deepEqual(errors,[]);console.log('Passed: official inline preview, light/dark screenshots and filter popover containment down to 320px.');
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});

// Managed dropdown values and direct, undoable updates of free-text fields.
function installFieldMaintenance(product,config){
  const {rows,domains,domainColor,canManage,merge,addDomain,removeDomain,openDomainColor,tag,escape,icons}=config,doc=product.ownerDocument;
  const fields=[{key:'domain',label:'业务域'},{key:'project',label:'项目'},{key:'requester',label:'提需人'}],panel=product.querySelector('[data-settings-panel="fields"]');
  const layer=doc.createElement('div');layer.className='fm-layer';layer.hidden=true;layer.innerHTML='<button type="button" class="gm-scrim" data-fm-close aria-label="关闭字段维护面板"></button><section class="fm-dialog" role="dialog" aria-modal="true" aria-label="字段维护"></section>';product.append(layer);
  let key='domain',selected=new Set(),returnFocus=null,action=null;
  const field=()=>fields.find(item=>item.key===key),allRows=()=>rows().filter(row=>!row.deleted);
  const values=()=>[...new Set(allRows().map(row=>row[key]).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'zh-CN'));
  const counts=(value,column=key)=>{const matching=allRows().filter(row=>row[column]===value);return {pool:matching.filter(row=>!row.archived).length,archive:matching.filter(row=>row.archived).length,total:matching.length};};
  const close=()=>{layer.hidden=true;product.querySelector('.gm-base').inert=false;returnFocus?.focus({preventScroll:true});action=null;};
  function render(){
    if(!canManage()){panel.innerHTML='';if(!layer.hidden)close();return;}
    selected=new Set([...selected].filter(value=>values().includes(value)));
    const tabs=`<div class="fm-tabs" role="tablist" aria-label="字段分类">${fields.map(item=>`<button type="button" role="tab" data-fm-tab="${item.key}" aria-selected="${key===item.key}">${item.label}</button>`).join('')}</div>`;
    if(key==='domain'){
      panel.innerHTML=tabs+`<div class="fm-actions"><button type="button" class="gm-btn gm-primary" data-fm-add-domain>新增业务域</button><span class="gm-caption">全局默认色；个人自定义配色优先</span></div><div class="gm-table-wrap"><table class="gm-table fm-table" aria-label="业务域枚举"><thead><tr><th>业务域</th><th>默认颜色</th><th>需求池</th><th>归档</th><th>操作</th></tr></thead><tbody>${domains().map(name=>{const c=counts(name,'domain'),color=domainColor(name);return `<tr><td>${tag('domain',name,true)}</td><td><button type="button" class="fm-color" data-fm-color="${escape(name)}" style="background:${color}" aria-label="双击修改${escape(name)}全局默认颜色" data-tooltip="双击修改全局默认色"></button></td><td>${c.pool}</td><td>${c.archive}</td><td><button type="button" class="gm-btn gm-quiet gm-danger-text" data-fm-delete-domain="${escape(name)}" ${c.total?'disabled':''} data-tooltip="${c.total?'仍有 '+c.total+' 条需求引用，请先调整这些需求的业务域':'删除业务域'}">删除</button></td></tr>`;}).join('')||'<tr><td colspan="5">暂无业务域，新增后可在需求表单中选择。</td></tr>'}</tbody></table></div>`;
    }else{
      panel.innerHTML=tabs+`<div class="fm-actions"><button type="button" class="gm-btn gm-primary" data-fm-merge ${selected.size?'':'disabled'}>合并名称</button><span class="gm-caption" data-fm-count></span></div><div class="gm-table-wrap"><table class="gm-table fm-table" aria-label="${field().label}名称维护"><thead><tr><th><input type="checkbox" data-fm-all aria-label="全选${field().label}名称" ${values().length?'':'disabled'}></th><th>名称</th><th>需求池</th><th>归档</th></tr></thead><tbody>${values().map(value=>{const c=counts(value);return `<tr><td><input type="checkbox" data-fm-value="${escape(value)}" aria-label="选择${escape(value)}" ${selected.has(value)?'checked':''}></td><td>${escape(value)}</td><td>${c.pool}</td><td>${c.archive}</td></tr>`;}).join('')||'<tr><td colspan="4">暂无${field().label}记录。</td></tr>'}</tbody></table></div><p class="gm-caption fm-note">覆盖需求池与归档中的所有状态。合并后直接更新字段，支持撤回和版本恢复。</p>`;
      syncSelection();
    }
    icons();
  }
  function syncSelection(){const all=panel.querySelector('[data-fm-all]');if(!all)return;all.checked=Boolean(values().length)&&values().every(value=>selected.has(value));all.indeterminate=selected.size>0&&!all.checked;panel.querySelector('[data-fm-merge]').disabled=!selected.size;panel.querySelector('[data-fm-count]').textContent=selected.size?'已选 '+selected.size+' 个名称':'';}
  function open(mode,name=''){
    if(!canManage())return;returnFocus=doc.activeElement;action={mode,key,selected:[...selected],name};
    let title='',body='',label='';
    if(mode==='merge'){
      title='合并'+field().label;label='确认合并';const affected=allRows().filter(row=>selected.has(row[key]));
      body=`<div class="fm-selected">${[...selected].map(value=>`<span>${escape(value)}</span>`).join('')}</div><label class="fm-field"><span>更新为 <span class="gm-required">*</span></span><input type="text" data-fm-target-name list="fm-target-values" placeholder="选择已有名称或填写新名称"><datalist id="fm-target-values">${values().map(value=>`<option value="${escape(value)}"></option>`).join('')}</datalist></label><p class="gm-caption">需求池 ${affected.filter(row=>!row.archived).length} 条，归档 ${affected.filter(row=>row.archived).length} 条，包含所有状态。</p><p class="gm-caption fm-note">将直接更新这些需求的${field().label}，原值记录在操作日志中。</p>`;
    }else if(mode==='add'){
      title='新增业务域';label='新增';body='<label class="fm-field"><span>业务域名称 <span class="gm-required">*</span></span><input type="text" data-fm-domain-name placeholder="填写业务域名称"></label><p class="gm-caption">创建后可双击色块调整全局默认色。</p>';
    }else{title='删除业务域';label='删除';body=`<p>删除“${escape(name)}”？</p>`;}
    layer.querySelector('section').innerHTML=`<div class="fm-dialog-head"><h3>${title}</h3><button type="button" class="gm-btn gm-quiet" data-fm-close aria-label="关闭字段维护面板"><i data-lucide="x" aria-hidden="true"></i></button></div>${body}<p class="fm-error" role="alert" hidden></p><div class="fm-dialog-actions"><button type="button" class="gm-btn" data-fm-close>取消</button><button type="button" class="gm-btn ${mode==='delete'?'gm-danger':'gm-primary'}" data-fm-commit>${label}</button></div>`;
    layer.hidden=false;product.querySelector('.gm-base').inert=true;icons();(layer.querySelector('input')||layer.querySelector('[data-fm-commit]')).focus({preventScroll:true});
  }
  function commit(){
    if(!canManage()||!action)return;
    const error=layer.querySelector('.fm-error');let reason='';
    if(action.mode==='merge')reason=merge(action.key,action.selected,layer.querySelector('[data-fm-target-name]').value.trim());
    if(action.mode==='add')reason=addDomain(layer.querySelector('[data-fm-domain-name]').value.trim());
    if(action.mode==='delete')reason=removeDomain(action.name);
    if(reason){error.textContent=reason;error.hidden=false;return;}
    close();selected.clear();render();
  }
  panel.addEventListener('change',event=>{const input=event.target;if(input.hasAttribute('data-fm-all')){selected=new Set(input.checked?values():[]);for(const checkbox of panel.querySelectorAll('[data-fm-value]'))checkbox.checked=input.checked;}else if(input.hasAttribute('data-fm-value')){input.checked?selected.add(input.dataset.fmValue):selected.delete(input.dataset.fmValue);}syncSelection();});
  panel.addEventListener('click',event=>{const button=event.target.closest('button');if(!button||!canManage())return;if(button.dataset.fmTab){key=button.dataset.fmTab;selected.clear();render();return;}if(button.hasAttribute('data-fm-merge'))open('merge');if(button.hasAttribute('data-fm-add-domain'))open('add');if(button.dataset.fmDeleteDomain)open('delete',button.dataset.fmDeleteDomain);if(button.dataset.fmColor&&event.detail===0)openDomainColor(button.dataset.fmColor);});
  panel.addEventListener('dblclick',event=>{const button=event.target.closest('[data-fm-color]');if(button&&canManage())openDomainColor(button.dataset.fmColor);});
  layer.addEventListener('click',event=>{if(event.target.closest('[data-fm-close]'))close();else if(event.target.closest('[data-fm-commit]'))commit();});
  layer.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}if(event.key==='Enter'&&event.target.tagName==='INPUT'){event.preventDefault();commit();}if(event.key==='Tab'){const nodes=[...layer.querySelector('section').querySelectorAll('input,button:not(:disabled)')];if(event.shiftKey&&event.target===nodes[0]){event.preventDefault();nodes.at(-1).focus();}else if(!event.shiftKey&&event.target===nodes.at(-1)){event.preventDefault();nodes[0].focus();}}});
  return {render};
}

function managedDomains(){return [...s.fieldCatalog.domains];}
function normalizeManagedData(value){
  if(!value||typeof value!=='object')return value;
  const result={...value},legacy=value.fieldGroups?.requester||[];
  const originalName=name=>legacy.find(group=>group.aliases?.includes(name)||group.displayName===name)?.displayName||name;
  if(Array.isArray(value.rows))result.rows=clone(value.rows).map(row=>({...row,requester:originalName(row.requester)}));
  if(value.history)result.history={...clone(value.history),requester:[...new Set((value.history.requester||[]).map(originalName))]};
  const known=Array.isArray(value.fieldCatalog?.domains)?value.fieldCatalog.domains:['流量域','广告域',...Object.keys(value.domainColors||{})];
  result.fieldCatalog={domains:[...new Set([...known,...(result.rows||[]).map(row=>row.domain)].filter(name=>typeof name==='string'&&name.trim()))]};
  delete result.fieldGroups;return result;
}
function mergeManagedField(field,selected,target){
  if(!isSuper()||!['requester','project'].includes(field))return '当前身份不能维护这个字段';
  if(!target)return '请填写合并后的名称';
  const chosen=new Set(selected),affected=s.rows.filter(row=>!row.deleted&&chosen.has(row[field])&&row[field]!==target);
  if(!affected.length)return '所选名称没有需要更新的需求';
  const before=captureData();for(const row of affected)row[field]=target;
  if(field==='requester')s.history.requester=[...new Set(s.history.requester.map(value=>chosen.has(value)?target:value))];
  recordDataChange('合并'+(field==='requester'?'提需人':'项目'),target,before);renderBase();persist(false);message('已更新 '+affected.length+' 条需求');return '';
}
function addManagedDomain(name){
  if(!isSuper())return '仅超级管理员可新增业务域';
  if(!name)return '请填写业务域名称';
  if(managedDomains().includes(name))return '这个业务域已存在';
  const before=captureData();s.fieldCatalog.domains.push(name);paletteCache.key='';domainPalette(true);
  recordDataChange('新增业务域',name,before);renderBase();persist(false);message('业务域已新增');return '';
}
function removeManagedDomain(name){
  if(!isSuper())return '仅超级管理员可删除业务域';
  if(s.rows.some(row=>!row.deleted&&row.domain===name))return '仍有需求引用，请先调整相关需求的业务域';
  const before=captureData();s.fieldCatalog.domains=s.fieldCatalog.domains.filter(value=>value!==name);delete s.domainColors[name];delete s.domainColorOverrides[name];
  s.filters.domain=normalizeFilterValues(s.filters.domain).filter(value=>value!==name);paletteCache.key='';
  recordDataChange('删除业务域',name,before);renderBase();persist(false);message('业务域已删除');return '';
}

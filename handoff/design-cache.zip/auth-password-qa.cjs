const fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir=__dirname+'/',source=fs.readFileSync(dir+'requirement-modal-study.html','utf8');
for(const match of source.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g))new Function(match[1]);
(async()=>{const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
try{
  const context=await browser.newContext({viewport:{width:1120,height:1100}}),page=await context.newPage(),errors=[];
  page.setDefaultTimeout(5000);page.on('pageerror',error=>errors.push(error.message));
  await context.addInitScript({path:dir+'lucide-qa-runtime.js'});
  await context.addInitScript(()=>{window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve();}};});
  await page.route('http://auth-ui.test/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<meta charset="utf-8">'+source}));
  await page.goto('http://auth-ui.test/');const app=page.locator('.gm-app');await app.locator('.gm-brand svg').waitFor();
  const nav=async view=>{if(view!=='roles'&&await app.locator('.gm-requirement-tabs').isHidden())await app.locator('[data-main-nav="requirements"]').click();await app.locator(`[data-nav="${view}"]`).click();};
  const settings=async tab=>{await nav('roles');await app.locator(`[data-settings-tab="${tab}"]`).click();};
  const read=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
  await nav('pool');const base=await read(),superName=base.accountRows.find(account=>account.role==='超级管理员').name,ordinary=base.accountRows.find(account=>account.role==='协作者').name;
  const poolButton=await app.locator('[data-new]').boundingBox();assert(await app.locator('[data-search-slot="header"]').isVisible());
  await nav('gantt');const ganttButton=await app.locator('[data-new]').boundingBox();assert.equal(poolButton.x,ganttButton.x);assert.equal(poolButton.y,ganttButton.y);assert((await app.locator('.gm-shared-filters').boundingBox()).y>=(await app.locator('.gm-requirement-tabs').boundingBox()).y);
  await nav('archive');assert(await app.locator('[data-new]').isHidden());assert(await app.locator('[data-search-slot="header"]').isVisible());
  await settings('roles');assert(await app.locator('[data-new]').isHidden());assert(await app.locator('[data-search-slot="header"]').isHidden());assert.equal(await app.locator('.gm-settings-nav button:visible').count(),5);
  let restoredRevision=10000;
  const restore=async patch=>{const state={...await read(),...patch};state.revision=Math.max(state.revision+1000,restoredRevision+=1000);await page.evaluate(saved=>window.dispatchEvent(new CustomEvent('openai:set_globals',{detail:{globals:{widgetState:{privateContent:saved}}}})),state);await page.waitForTimeout(30);};
  const passwordLayer=app.locator('.gm-password-layer'),auth=app.locator('.gm-auth-layer');
  const secretA='UiCheck!5849',secretB='UiUpdate!7612';
  await settings('roles');await app.locator(`[data-account-password-manage="${ordinary}"]`).click();
  await app.locator('#gm-password-new').fill(secretA);await passwordLayer.locator('[data-password-eye="gm-password-new"]').click();assert.equal(await app.locator('#gm-password-new').getAttribute('type'),'text');
  await passwordLayer.locator('[data-password-eye="gm-password-new"]').click();assert.equal(await app.locator('#gm-password-new').getAttribute('type'),'password');
  await passwordLayer.locator('[data-password-commit]').click();await passwordLayer.waitFor({state:'hidden'});
  await app.locator(`[data-account-password-manage="${ordinary}"]`).click();assert.equal(await app.locator('#gm-password-current').inputValue(),secretA);await passwordLayer.locator('[data-password-close]').last().click();

  await restore({actor:'__guest__',view:'gantt'});const before=await read();
  await app.locator('[data-current-user-avatar]').click();await auth.waitFor({state:'visible'});
  assert.equal(await auth.locator('input').count(),2);assert.equal(await auth.locator('input[type="email"]').count(),0);assert.equal(await auth.locator('.gm-auth-paths').count(),2);assert.equal(await auth.locator('.gm-auth-paths path').count(),72);
  assert(await app.locator('.gm-base').evaluate(node=>node.inert));assert.equal(await page.locator(':focus').getAttribute('id'),'gm-auth-username');
  await auth.locator('.gm-auth-close').focus();await page.keyboard.press('Shift+Tab');assert(await auth.locator('[type="submit"]').evaluate(node=>node===document.activeElement));await page.keyboard.press('Tab');assert(await auth.locator('.gm-auth-close').evaluate(node=>node===document.activeElement));
  await auth.locator('#gm-auth-username').fill(ordinary);await auth.locator('#gm-auth-password').fill('bad-password');await auth.locator('[type="submit"]').click();assert.equal(await auth.locator('.gm-auth-error').innerText(),'用户名或密码不正确');assert((await app.locator('[data-current-user-avatar]').getAttribute('aria-label')).includes('游客'));
  await auth.locator('#gm-auth-password').fill(secretA);await auth.locator('[data-password-eye]').click();assert.equal(await auth.locator('#gm-auth-password').getAttribute('type'),'text');await auth.locator('[data-password-eye]').click();
  await auth.locator('#gm-auth-username').fill('不存在的账号');await auth.locator('[type="submit"]').click();assert.equal(await auth.locator('.gm-auth-error').innerText(),'用户名或密码不正确');
  await auth.locator('#gm-auth-username').fill(superName);await auth.locator('[type="submit"]').click();assert.equal(await auth.locator('.gm-auth-error').innerText(),'请先由超级管理员设置初始密码');
  await page.keyboard.press('Escape');await auth.waitFor({state:'hidden'});assert.equal(await auth.locator('input').count(),0);assert.equal((await read()).logs.length,before.logs.length);assert.deepEqual((await read()).rows,before.rows);
  await app.locator('[data-current-user-avatar]').click();assert.equal(await auth.locator('#gm-auth-username').inputValue(),'');await auth.locator('#gm-auth-username').fill(ordinary);await auth.locator('#gm-auth-password').fill(secretA);await auth.locator('#gm-auth-password').press('Enter');await auth.waitFor({state:'hidden'});assert.equal((await read()).actor,ordinary);assert.equal((await read()).view,'gantt');assert.equal(await app.locator('.gm-base').evaluate(node=>node.inert),false);
  await page.reload();await app.locator('.gm-brand svg').waitFor();assert.equal((await read()).actor,ordinary);assert(await auth.isHidden());
  // Credentials deliberately do not survive a reload in this interaction-only study.
  await restore({actor:superName,view:'roles',settingsTab:'roles'});await app.locator(`[data-account-password-manage="${ordinary}"]`).click();await app.locator('#gm-password-new').fill(secretA);await passwordLayer.locator('[data-password-commit]').click();
  await restore({actor:ordinary,view:'roles',settingsTab:'personal'});assert.equal(await app.locator('[data-account-password-manage]').count(),0);await app.locator('[data-self-password]').click();
  await app.locator('#gm-password-current').fill('wrong');await app.locator('#gm-password-new').fill(secretB);await passwordLayer.locator('[data-password-commit]').click();assert.equal(await passwordLayer.locator('.gm-password-error').innerText(),'当前密码不正确');
  await app.locator('#gm-password-current').fill(secretA);await passwordLayer.locator('[data-password-commit]').click();await passwordLayer.waitFor({state:'hidden'});
  await app.locator('[data-auth-logout]').click();assert.equal((await read()).actor,'__guest__');await app.locator('[data-current-user-avatar]').click();await auth.locator('#gm-auth-username').fill(ordinary);await auth.locator('#gm-auth-password').fill(secretA);await auth.locator('[type="submit"]').click();assert(await auth.locator('.gm-auth-error').isVisible());await auth.locator('#gm-auth-password').fill(secretB);await auth.locator('[type="submit"]').click();await auth.waitFor({state:'hidden'});assert.equal((await read()).actor,ordinary);
  await settings('personal');await app.locator('[data-self-password]').click();await app.locator('#gm-password-current').fill(secretB);await restore({actor:superName});await passwordLayer.waitFor({state:'hidden'});assert.equal(await passwordLayer.locator('input').count(),0);
  const leaked=await page.evaluate(secrets=>Object.keys(localStorage).some(key=>secrets.some(secret=>localStorage.getItem(key).includes(secret)))||secrets.some(secret=>JSON.stringify(window.openai.widgetState).includes(secret)),[secretA,secretB]);assert.equal(leaked,false);
  console.log('Passed login modal, username/password/eye controls, form validation, keyboard focus, dismissal, remembered identity, logout, administrator reset, self-service password change, identity isolation and no credentials in persisted data.');

  await restore({actor:'__guest__',view:'pool'});
  for(const width of [1060,736,480,320])for(const theme of ['light','dark']){
    await page.setViewportSize({width,height:1000});await page.evaluate(theme=>{const product=document.querySelector('.gm-app');product.style.colorScheme=theme;product.dataset.theme=theme;},theme);
    await app.locator('[data-current-user-avatar]').click();await auth.waitFor({state:'visible'});
    const geometry=await auth.locator('.gm-auth-dialog').evaluate(node=>{const dialog=node.getBoundingClientRect(),product=node.closest('.gm-app').getBoundingClientRect();return {left:dialog.left,right:dialog.right,productLeft:product.left,productRight:product.right,width:node.clientWidth,scrollWidth:node.scrollWidth,art:!!node.querySelector('.gm-auth-art').getClientRects().length,fields:[...node.querySelectorAll('input,button')].map(input=>{const r=input.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom};})};});
    assert(geometry.left>=geometry.productLeft&&geometry.right<=geometry.productRight);assert(geometry.scrollWidth<=geometry.width+1);assert(geometry.art);assert(geometry.fields.every(field=>field.left>=geometry.left&&field.right<=geometry.right));
    const contrast=await auth.locator('.gm-auth-content').evaluate(node=>{const rgb=text=>text.match(/[\d.]+/g).slice(0,3).map(Number),lum=color=>{const values=rgb(color).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});return values[0]*.2126+values[1]*.7152+values[2]*.0722;},bg=getComputedStyle(node).backgroundColor,foreground=getComputedStyle(node.querySelector('label')).color,muted=getComputedStyle(node.querySelector('.gm-auth-heading p')).color;const ratio=fg=>(Math.max(lum(fg),lum(bg))+.05)/(Math.min(lum(fg),lum(bg))+.05);return {primary:ratio(foreground),secondary:ratio(muted)};});
    assert(contrast.primary>=4.5&&contrast.secondary>=4.5,JSON.stringify({width,theme,contrast}));
    await app.screenshot({path:dir+`auth-modal-${width}-${theme}-qa.png`,animations:'disabled'});
    await page.keyboard.press('Escape');await auth.waitFor({state:'hidden'});
  }
  console.log('Passed responsive login composition at 320/480/736/1060px, preserved animated art, light/dark label contrast, and no clipped form controls.');
  await page.emulateMedia({reducedMotion:'reduce'});await app.locator('[data-current-user-avatar]').click();assert.equal(await auth.locator('path').first().evaluate(node=>getComputedStyle(node).animationName),'none');await auth.locator('.gm-auth-scrim').click({position:{x:20,y:20}});await auth.waitFor({state:'hidden'});assert.deepEqual(errors,[]);
  await context.close();

  // Also inspect the official sandbox wrapper, which has different storage and host styles.
  const official=await browser.newContext({viewport:{width:1080,height:1050}}),p=await official.newPage(),officialErrors=[];p.on('pageerror',error=>officialErrors.push(error.message));
  await p.route('https://unpkg.com/lucide@1.17.0/dist/umd/lucide.js',route=>route.fulfill({contentType:'text/javascript',body:fs.readFileSync(dir+'lucide-qa-runtime.js','utf8')}));
  await p.route('http://auth-wrapper.test/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:fs.readFileSync(dir+'modal-preview-qa.html','utf8')}));
  await p.goto('http://auth-wrapper.test/');const frame=p.frameLocator('iframe');await frame.locator('.gm-brand svg').waitFor();
  const inner=p.frames().find(frame=>frame.parentFrame());
  await inner.evaluate(()=>{const product=document.querySelector('.gm-app');product.querySelector('[data-nav="pool"]').click();});await p.waitForTimeout(100);
  await inner.evaluate(()=>{const saved=window.openai.widgetState?.privateContent;if(!saved)throw new Error('No wrapper state');});
  // Read compressed widget state rather than assuming sandbox localStorage access.
  await inner.evaluate(async()=>{let saved=window.openai.widgetState.privateContent;if(saved.packed){const data=Uint8Array.from(atob(saved.packed),char=>char.charCodeAt(0));saved=JSON.parse(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate'))).text());}saved.actor='__guest__';saved.revision+=1000;window.dispatchEvent(new CustomEvent('openai:set_globals',{detail:{globals:{widgetState:{privateContent:saved}}}}));});
  await frame.locator('[data-current-user-avatar]').click();await frame.locator('.gm-auth-dialog').waitFor();await frame.locator('.gm-auth-dialog').evaluate(node=>Promise.all(node.getAnimations().map(animation=>animation.finished.catch(()=>{}))));await p.screenshot({path:dir+'auth-modal-official-wrapper-qa.png'});assert.deepEqual(officialErrors,[]);await official.close();
  console.log('Passed official sandbox rendering with runtime icons and no errors.');
}finally{await browser.close();}})().catch(error=>{console.error(error);process.exit(1);});

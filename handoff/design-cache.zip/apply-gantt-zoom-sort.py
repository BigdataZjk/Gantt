from pathlib import Path
p=Path(__file__).parent;f=p/'requirement-modal-study.html';s=f.read_text(encoding='utf-8')

def replace_once(before,after):
    global s
    assert s.count(before)==1,(before[:100],s.count(before))
    s=s.replace(before,after,1)

replace_once("ganttRange:{start:'',end:''},collapsedPeople:","ganttRange:{start:'',end:''},ganttZoom:1,ganttRowOrder:{},collapsedPeople:")
replace_once("const axisStart=()=>s.ganttRange.start||shiftDate(today(),-7),axisEnd=()=>s.ganttRange.end||shiftDate(today(),30);", "const axisStart=()=>s.ganttRange.start||shiftDate(today(),-7),axisEnd=()=>zoomedAxisEnd();")
replace_once('  function renderSequenceControls(){',(p/'gantt-zoom-sort.js').read_text(encoding='utf-8')+'\n  function renderSequenceControls(){')
assert s.count("ganttRange:{...s.ganttRange},collapsedPeople:")==2
s=s.replace("ganttRange:{...s.ganttRange},collapsedPeople:","ganttRange:{...s.ganttRange},ganttZoom:s.ganttZoom,ganttRowOrder:clone(s.ganttRowOrder),collapsedPeople:")
replace_once("if(Array.isArray(pref.collapsedPeople))", "if(typeof pref.ganttZoom==='number')s.ganttZoom=Math.max(.001,Math.min(1,pref.ganttZoom));\n    if(pref.ganttRowOrder&&typeof pref.ganttRowOrder==='object')s.ganttRowOrder=clone(pref.ganttRowOrder);\n    if(Array.isArray(pref.collapsedPeople))")
replace_once('<div class="gm-person-controls" role="group" aria-label="人员分组">','<div class="gm-person-controls" role="group" aria-label="人员分组"><button type="button" class="gm-btn" data-gantt-zoom-reset hidden data-tooltip="恢复默认比例及缩放前的日期范围"><i data-lucide="rotate-ccw" aria-hidden="true"></i>重置比例</button>')
replace_once("const start=axisStart(),end=axisEnd(),currentDate=today(),dates=[];", "applyTimelineZoom();const start=axisStart(),end=axisEnd(),currentDate=today(),dates=[];")
a=s.index("${dates.map(date=>`<th class=\"gm-date ")
b=s.index(".join('')}",a)+len(".join('')}")
s=s[:a]+'${ganttDateHeaders(dates,currentDate)}'+s[b:]
replace_once("rows.filter(row=>row.developer===person).sort((a,b)=>(a.start||'9999').localeCompare(b.start||'9999'))", "orderedGanttRows(rows.filter(row=>row.developer===person),person)")
replace_once("label=month.count<6?number+' 月':year+' 年 '+number+' 月';", "label=month.count<6||month.count*timelineDayWidth()<110?number+' 月':year+' 年 '+number+' 月';")
replace_once('const previousStart=axisStart(),next={start:axisStart(),end:axisEnd()};','const previousStart=axisStart(),next={start:axisStart(),end:axisEnd()};')
replace_once("if(edge==='start'||next.start!==axisStart())s.ganttRange.start=next.start;", "s.ganttZoom=1;\n    if(edge==='start'||next.start!==axisStart())s.ganttRange.start=next.start;")
replace_once("<button type=\"button\" role=\"menuitem\" data-sequence-clear>", "<button type=\"button\" role=\"menuitem\" data-gantt-sort-selected ${selectedAdmissionSortNeeded()?'':'disabled'}><i data-lucide=\"arrow-down-wide-narrow\" aria-hidden=\"true\"></i>按准入日期排序</button><button type=\"button\" role=\"menuitem\" data-sequence-clear>")
replace_once("if(button.hasAttribute('data-sequence-preview'))", "if(button.hasAttribute('data-gantt-sort-selected')){sortSelectedByAdmission();return;}\n    if(button.hasAttribute('data-gantt-zoom-reset')){resetTimelineZoom();return;}\n    if(button.hasAttribute('data-sequence-preview'))")
replace_once('  initHoverGlowButton();', "  app.addEventListener('wheel',zoomTimelineFromWheel,{passive:false});\n  window.addEventListener('resize',()=>{if(s.view==='gantt'&&s.ganttZoom<1&&!s.mode)renderGanttGrid();});\n  initHoverGlowButton();")
replace_once('<script>', '<style>\n'+(p/'gantt-enhancements.css').read_text(encoding='utf-8')+'\n</style>\n<script>')
assert len(s.encode('utf-8'))<1_000_000
f.write_text(s,encoding='utf-8');print('Applied selection sorting and timeline zoom:',len(s.encode('utf-8')),'bytes')

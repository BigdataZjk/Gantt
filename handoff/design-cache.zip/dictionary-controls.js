// One shared rendering for dictionary values in list cells, filter choices and form dropdowns.
function installDictionaryControls(product,{tag,priorityTag,icons}){
  const doc=product.ownerDocument,popover=doc.createElement('div');popover.className='gm-enum-menu';popover.hidden=true;popover.setAttribute('role','listbox');product.append(popover);let current=null;
  const kind=select=>select.name==='domain'?'domain':select.name==='status'?'status':select.name==='requestType'||select.dataset.requirementDefault==='requestType'?'requestType':'priority';
  const valueMarkup=(select,value)=>kind(select)==='priority'?priorityTag(value):value?tag(kind(select),value):'<span class="gm-muted">-</span>';
  function sync(select){const button=select.parentElement.querySelector('[data-enum-trigger]');if(!button)return;button.disabled=select.disabled;button.innerHTML=valueMarkup(select,select.value)+'<i data-lucide="chevron-down" aria-hidden="true"></i>';}
  function close(focus=false){popover.hidden=true;const old=current;current=null;if(old){const button=old.parentElement?.querySelector('[data-enum-trigger]');button?.setAttribute('aria-expanded','false');if(focus)button?.focus({preventScroll:true});}}
  function open(select){
    if(select.disabled)return;close();current=select;const button=select.parentElement.querySelector('[data-enum-trigger]');button.setAttribute('aria-expanded','true');popover.innerHTML=[...select.options].map((option,index)=>`<button type="button" role="option" aria-selected="${option.selected}" data-enum-option="${index}" ${option.disabled?'disabled':''}>${valueMarkup(select,option.value)}</button>`).join('');popover.hidden=false;
    const app=product.getBoundingClientRect(),r=button.getBoundingClientRect();popover.style.left=Math.max(8,Math.min(r.left-app.left,app.width-popover.offsetWidth-8))+'px';popover.style.top=Math.max(8,Math.min(r.bottom-app.top+6,app.height-popover.offsetHeight-8))+'px';popover.querySelector('[aria-selected="true"]')?.focus({preventScroll:true});icons();
  }
  function hydrate(){
    for(const select of product.querySelectorAll('select[name="domain"],select[name="requestType"],select[name="status"],select[data-requirement-default]')){
      if(select.dataset.enumEnhanced){sync(select);continue;}
      select.dataset.enumEnhanced='true';const wrap=doc.createElement('span');wrap.className='gm-enum-control';select.before(wrap);wrap.append(select);select.hidden=true;const button=doc.createElement('button');button.type='button';button.className='gm-enum-trigger';button.dataset.enumTrigger='';button.id=select.id+'-trigger';button.setAttribute('aria-haspopup','listbox');button.setAttribute('aria-expanded','false');wrap.append(button);
      const label=select.id&&product.querySelector(`label[for="${select.id}"]`);if(label)label.htmlFor=button.id;
      button.addEventListener('click',()=>current===select?close(true):open(select));button.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();open(select);}});sync(select);
    }
  }
  popover.addEventListener('click',event=>{const button=event.target.closest('[data-enum-option]');if(!button||!current)return;const select=current;select.value=select.options[Number(button.dataset.enumOption)].value;close();select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));if(select.isConnected){sync(select);select.parentElement.querySelector('[data-enum-trigger]')?.focus({preventScroll:true});}icons();});
  popover.addEventListener('keydown',event=>{if(event.key==='Tab'){event.preventDefault();close(true);return;}if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close(true);return;}if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();const options=[...popover.querySelectorAll('button:not(:disabled)')],index=options.indexOf(doc.activeElement),next=event.key==='Home'?0:event.key==='End'?options.length-1:(index+(event.key==='ArrowDown'?1:options.length-1))%options.length;options[next]?.focus({preventScroll:true});}});
  product.addEventListener('pointerdown',event=>{if(!popover.contains(event.target)&&!event.target.closest('[data-enum-trigger]'))close();},true);window.addEventListener('resize',()=>close());return {hydrate,close};
}

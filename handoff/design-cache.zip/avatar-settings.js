function mountAvatarSettings(host,config){
  const {name,profile,enabled,save,escape,icons}=config;let selected=profile().avatarPreset||'initial';
  function paint(){
    const image=readAvatarImage(name);
    host.innerHTML=`<div class="pr-profile-heading">头像</div><div class="pr-avatar-settings"><span class="pr-profile-preview">${avatarMarkup(name,{avatarPreset:selected},escape)}</span><div><div class="pr-preset-grid" role="group" aria-label="预设头像">${[...avatarPresets,...(image?[{id:'custom',label:'已上传头像'}]:[])].map(preset=>`<button type="button" class="pr-preset" data-avatar-choice="${preset.id}" data-tooltip="${preset.label}" aria-label="${preset.label}" aria-pressed="${selected===preset.id}" ${enabled?'':'disabled'}>${avatarMarkup(name,{avatarPreset:preset.id},escape)}</button>`).join('')}</div><div class="pr-upload-row"><button type="button" class="pr-upload-button" ${enabled?'':'disabled'}><i data-lucide="image-up" aria-hidden="true"></i>上传头像</button><span>JPG、PNG、WebP、GIF</span><input type="file" class="pr-upload-input" accept="image/png,image/jpeg,image/webp,image/gif,.gif" aria-label="上传自定义头像" hidden ${enabled?'':'disabled'}></div><p class="pr-avatar-error" role="alert" hidden></p>${enabled?'':'<p class="pr-avatar-note">登录后可设置头像</p>'}</div></div>`;icons();
  }
  host.addEventListener('click',event=>{const button=event.target.closest('button');if(!button||!enabled)return;if(button.dataset.avatarChoice){selected=button.dataset.avatarChoice;save({avatarPreset:selected});paint();}if(button.classList.contains('pr-upload-button'))host.querySelector('input[type="file"]').click();});
  host.addEventListener('change',event=>{
    const input=event.target;if(input.type!=='file'||!enabled)return;const file=input.files?.[0];if(!file)return;
    const fail=text=>{const error=host.querySelector('.pr-avatar-error');if(error){error.textContent=text;error.hidden=false;}};
    const gif=file.type==='image/gif'||!file.type&&/\.gif$/i.test(file.name);
    if(!gif&&!['image/png','image/jpeg','image/webp'].includes(file.type)){fail('请选择 JPG、PNG、WebP 或 GIF 图片');return;}
    if(file.size>5*1024*1024){fail('请选择 5 MB 以内的图片');return;}
    const reader=new FileReader();reader.onerror=()=>fail('图片读取失败，请重新选择');
    reader.onload=()=>{
      if(!host.isConnected)return;const image=new Image();image.onerror=()=>fail('无法读取这张图片，请重新选择');
      image.onload=()=>{
        if(!host.isConnected)return;let data;
        if(gif){data=String(reader.result);if(!data.startsWith('data:image/gif;'))data='data:image/gif;base64,'+data.split(',')[1];}
        else{const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const context=canvas.getContext('2d'),side=Math.min(image.width,image.height);context.drawImage(image,(image.width-side)/2,(image.height-side)/2,side,side,0,0,128,128);data=canvas.toDataURL('image/webp',.88);}
        avatarImages.set(name,data);try{localStorage.setItem('paiyixia-avatar-v1:'+name,data);}catch{}
        selected='custom';save({avatarPreset:selected});paint();
      };
      image.src=String(reader.result);
    };
    reader.readAsDataURL(file);
  });paint();
  return {refresh(){selected=profile().avatarPreset||'initial';paint();}};
}

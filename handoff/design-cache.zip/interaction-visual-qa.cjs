const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1056, height: 1100 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00'));
    page.setDefaultTimeout(5000); const errors = []; page.on('pageerror', error => errors.push(error.message));
    await page.goto('file:///' + dir + 'modal-preview-qa.html'); const ui = page.frameLocator('iframe');
    assert.equal(await ui.locator('.gm-brand > span').textContent(), '排一下');
    await ui.locator('.gm-topbar').screenshot({ path: dir + 'shiny-button-idle-qa.png' });
    await ui.locator('[data-new]').hover();
    await ui.locator('[data-new]').evaluate(async el => { await new Promise(requestAnimationFrame); for (const animation of el.getAnimations({ subtree: true })) if (animation instanceof CSSTransition) animation.finish(); });
    await ui.locator('.gm-topbar').screenshot({ path: dir + 'shiny-button-hover-qa.png' });
    await ui.locator('[data-nav="gantt"]').click();
    await ui.locator('[data-axis-edge="start"]').fill('2026-11-12'); await ui.locator('[data-axis-edge="end"]').fill('2026-12-04');
    await ui.locator('[data-gantt-name="1"]').click(); await ui.locator('[data-gantt-name="3"]').click({ modifiers: ['Control'] });
    await ui.locator('tr[data-gantt-row="3"] td[data-date="2026-11-16"] .gm-bar-piece').hover();
    await ui.locator('.gm-delivery-guide[data-delivery-row="3"]').waitFor();
    await ui.locator('.tooltip').waitFor(); assert.equal(await ui.locator('.tooltip').textContent(), '用户标签回流  4人天');
    await ui.locator('.gm-app').screenshot({ path: dir + 'delivery-guide-light-qa.png' });
    await page.emulateMedia({ colorScheme: 'dark' });
    await ui.locator('.gm-app').screenshot({ path: dir + 'delivery-guide-dark-qa.png' });
    await ui.locator('[data-nav="roles"]').click(); await ui.locator('[data-settings-tab="personal"]').click();
    await ui.locator('[data-color-open]').dblclick(); await ui.locator('[data-color-hex]').fill('#00A074');
    await ui.locator('.gm-app').screenshot({ path: dir + 'color-bar-preview-dark-qa.png' });
    for (const width of [736, 360, 320]) {
      await page.setViewportSize({ width, height: 1100 });
      assert(await ui.locator('.gm-app').evaluate(el => el.scrollWidth <= el.clientWidth + 1));
      assert(await ui.locator('.gm-color-dialog').evaluate(el => el.scrollWidth <= el.clientWidth + 1));
    }
    await ui.locator('.gm-app').screenshot({ path: dir + 'color-bar-preview-mobile-qa.png' });
    assert.deepEqual(errors, []); console.log('Passed: official preview geometry, light/dark delivery guides, color-bar preview and 320px modal layout.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });

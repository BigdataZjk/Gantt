const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1220, height: 1100 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00')); page.setDefaultTimeout(5000);
    const errors = []; page.on('pageerror', error => errors.push(error.message));
    const fragment = fs.readFileSync(dir + 'requirement-modal-study.html', 'utf8');
    await page.route('http://gantt-groups.test/**', route => route.fulfill({ contentType: 'text/html; charset=utf-8', body: '<!doctype html><meta charset="utf-8"><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve()}};</script>' + fragment }));
    await page.goto('http://gantt-groups.test/');
    const nav = value => page.locator(`[data-nav="${value}"]`).click();
    const read = () => page.evaluate(() => JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    const p = value => page.locator(`[data-priority-filter="${value}"]`);
    const head = name => page.locator(`[data-person-toggle="${name}"]`);
    const rows = () => page.locator('tr[data-gantt-row]:not([hidden])').evaluateAll(nodes => nodes.map(node => Number(node.dataset.ganttRow)).sort((a,b) => a-b));
    const selected = () => page.locator('tr[data-sequence-selected="true"]').evaluateAll(nodes => nodes.map(node => Number(node.dataset.ganttRow)).sort((a,b) => a-b));
    await nav('gantt'); const base = await read();
    const load = async (edit = () => {}) => {
      const data = structuredClone(base); data.revision = (await read()).revision + 1000; data.actor = '张金科'; data.view = 'gantt';
      data.filters = { domain:'',developer:'',requestType:'',query:'',status:'',start:'',end:'',priority:'' }; data.collapsedPeople = []; data.logs = []; data.undoHistory = [];
      data.ganttRange = { start:'2026-11-09',end:'2026-12-14' }; edit(data);
      await page.evaluate(async saved => { window.dispatchEvent(new CustomEvent('openai:set_globals', { detail: { globals: { widgetState: { privateContent: saved } } } })); await new Promise(requestAnimationFrame); }, data);
      await nav('gantt'); return data;
    };
    await load();
    assert.equal(await page.locator('[data-priority-filter]').count(), 3); assert.equal(await page.locator('[data-priority-filter=""]').count(), 0);
    assert.equal(await page.locator('.gm-gantt-priorities').count(), 0); assert.deepEqual(await rows(), [1,2,3,4,5,6,7,8]);
    await p('P0').click(); assert.deepEqual(await rows(), [1,3]);
    await p('P2').click(); assert.deepEqual(await rows(), [1,3,5,8]);
    await p('P0').click(); assert.deepEqual(await rows(), [5,8]);
    await p('P2').click(); assert.deepEqual(await rows(), [1,2,3,4,5,6,7,8], 'No priorities means no filter');
    await page.locator('[data-priority-all]').click(); assert.equal(await page.locator('[data-priority-filter][aria-pressed="true"]').count(), 3); assert(await page.locator('[data-priority-all]').isHidden()); assert.deepEqual(await rows(), [1,2,3,4,5,6,7,8]);
    await p('P1').click(); assert.deepEqual(await rows(), [1,3,5,8]); assert(await page.locator('[data-priority-all]').isVisible());
    await page.locator('[data-filter="developer"]').selectOption('李明'); assert.deepEqual(await rows(), [3,8]);
    const beforeReload = await read(); await page.reload(); assert.equal((await read()).filters.priority, 'P0,P2'); assert.deepEqual(await rows(), [3,8]); assert.deepEqual((await read()).rows, beforeReload.rows); assert.equal((await read()).logs.length, 0);
    await nav('pool'); assert.equal(await page.locator('.gm-requirement-table tr[data-row]').count(), 2); assert.equal(await p('P0').getAttribute('aria-pressed'), 'true'); assert.equal(await p('P2').getAttribute('aria-pressed'), 'true');

    let original = await load();
    const controls = (await head('张金科').getAttribute('aria-controls')).split(' '); assert.equal(controls.length, 3);
    assert.equal(await page.locator('.gm-person-toggle .gm-person-caret').count(), await page.locator('.gm-person-toggle').count(), 'Small disclosure triangle for each person');
    await page.locator('[data-gantt-name="1"]').click(); await page.locator('[data-gantt-name="3"]').click({ modifiers: ['Control'] });
    await head('张金科').click(); assert.equal(await head('张金科').getAttribute('aria-expanded'), 'false'); assert.deepEqual(await rows(), [3,4,5,6,8]); assert.deepEqual(await selected(), [3], 'Hidden rows cannot remain in a batch action');
    assert((await head('张金科').textContent()).includes('3 条')); for (const id of controls) assert(await page.locator('#' + id).isHidden());
    await page.keyboard.press('Control+a'); assert.deepEqual(await selected(), [3,4,5,8], 'Select-all only includes expanded groups');
    const wrap = page.locator('.gm-calendar-wrap'); await wrap.evaluate(el => el.scrollLeft = 120); const scroll = await wrap.evaluate(el => el.scrollLeft);
    const group = page.locator('[data-person-group="张金科"]'), groupRect = await group.boundingBox(), wrapRect = await wrap.boundingBox();
    await page.mouse.click(wrapRect.x + wrapRect.width - 40, groupRect.y + groupRect.height / 2);
    assert.equal(await head('张金科').getAttribute('aria-expanded'), 'true', 'The blank part of the header also toggles the group'); assert.equal(await wrap.evaluate(el => el.scrollLeft), scroll);
    await head('张金科').focus(); await page.keyboard.press('Space'); assert.equal(await head('张金科').getAttribute('aria-expanded'), 'false');
    let state = await read(); assert.deepEqual(state.rows, original.rows); assert.equal(state.logs.length, 0); assert.equal(state.undoHistory.length, 0); assert.deepEqual(state.collapsedPeople, ['张金科']);
    await page.reload(); assert.equal(await head('张金科').getAttribute('aria-expanded'), 'false'); assert.deepEqual(await rows(), [3,4,5,6,8]);
    await head('张金科').focus(); await page.keyboard.press('Enter'); assert.equal(await head('张金科').getAttribute('aria-expanded'), 'true');
    await head('').click(); assert(await page.locator('tr[data-gantt-row="6"]').isHidden()); await head('').click(); assert(await page.locator('tr[data-gantt-row="6"]').isVisible());
    await load(data => { data.actor = '__guest__'; }); await head('李明').click(); assert(await page.locator('tr[data-gantt-row="3"]').isHidden()); await p('P0').click(); assert.deepEqual(await rows(), [1]); assert.equal((await read()).logs.length, 0);

    await load();
    const rect = locator => locator.evaluate(el => { const r=el.getBoundingClientRect(); return {left:r.left,right:r.right,top:r.top,bottom:r.bottom}; });
    const core = await rect(page.locator('.gm-shared-filters')), priorities = await rect(page.locator('.gm-priority-filters')), axis = await rect(page.locator('.gm-axis-controls'));
    assert(Math.abs(priorities.right - core.right) < 1); assert(Math.abs(axis.left - core.left) < 1); assert(axis.top >= core.bottom + 10);
    const all = await rect(page.locator('[data-priority-all]')); assert(all.bottom < core.bottom); assert(all.top >= priorities.bottom - 2);
    assert.equal(new Set(await page.locator('[data-priority-filter]').evaluateAll(nodes => nodes.map(node => node.getBoundingClientRect().top))).size, 1);
    for (const view of ['pool','archive']) {
      await nav(view); const coreBox = await rect(page.locator('.gm-shared-filters')), actions = await rect(page.locator('.gm-filter-actions'));
      assert(Math.abs(actions.left - coreBox.left) < 1); assert(actions.top >= coreBox.bottom + 10); assert(Math.abs(actions.top - coreBox.bottom - (axis.top - core.bottom)) < 1, 'Secondary controls use the same row on all pages');
      await page.locator('.gm-columns > summary').click(); const popover = await rect(page.locator('.gm-columns > .gm-filter-popover')); assert(popover.left >= coreBox.left - 1); await page.keyboard.press('Escape');
      await page.locator('.gm-more-filters > summary').click(); assert(await page.locator('#gm-filter-start').isVisible()); await page.keyboard.press('Escape');
    }
    await nav('pool'); await page.locator('.gm-columns > summary').click(); const beforeOrder = (await read()).columnOrder;
    await page.locator('[data-column-move="requester"][data-direction="-1"]').click(); assert.notDeepEqual((await read()).columnOrder, beforeOrder); assert.equal((await read()).logs.length, 0); await page.keyboard.press('Escape');
    for (const width of [1024,736,360,320]) {
      await page.setViewportSize({width,height:1100});
      for (const view of ['gantt','pool','archive']) { await nav(view); assert(await page.locator('.gm-app').evaluate(el => el.scrollWidth <= el.clientWidth + 1), 'Overflow on ' + view + ' at ' + width); }
    }
    await page.setViewportSize({width:1056,height:1100}); await page.goto('file:///' + dir + 'modal-preview-qa.html'); const ui=page.frameLocator('iframe');
    await ui.locator('[data-nav="gantt"]').click(); await ui.locator('[data-axis-edge="start"]').fill('2026-11-12'); await ui.locator('[data-axis-edge="end"]').fill('2026-12-04');
    await ui.locator('[data-person-toggle="李明"]').click();
    assert.equal(await ui.locator('.gm-parallel-symbol').first().evaluate(el => getComputedStyle(el).height), '24px');
    assert.equal(await ui.locator('.gm-parallel-symbol svg').first().evaluate(el => getComputedStyle(el).height), '22px');
    assert.equal(await ui.locator('.gm-parallel-symbol').first().evaluate(el => getComputedStyle(el).backgroundColor), 'rgba(0, 0, 0, 0)');
    await ui.locator('.gm-app').screenshot({path:dir+'group-priority-gantt-qa.png'});
    await ui.locator('[data-nav="pool"]').click(); await ui.locator('[data-priority-filter="P0"]').click(); await ui.locator('[data-priority-filter="P1"]').click();
    await ui.locator('.gm-app').screenshot({path:dir+'group-priority-pool-qa.png'});
    await ui.locator('tr[data-row="1"] [data-requirement-name]').click({button:'right'}); await ui.locator('[data-requirement-action="archive"]').click(); await ui.locator('[data-nav="archive"]').click();
    await ui.locator('.gm-app').screenshot({path:dir+'group-priority-archive-qa.png'});
    await page.emulateMedia({colorScheme:'dark'}); await ui.locator('[data-nav="gantt"]').click(); await ui.locator('.gm-app').screenshot({path:dir+'group-priority-dark-qa.png'});
    assert.deepEqual(errors, []);
    console.log('Passed: priority multi-selection, none/all semantics and persistence, collapsible person headers and keyboard access, retained data/audit, visible-only batch selection, guest access, left secondary rows, pool/archive parity, popovers/field ordering, larger transparent arrows, and responsive layouts.');
  } finally { await browser.close(); }
})().catch(error => {console.error(error);process.exit(1)});

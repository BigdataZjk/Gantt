// Historical daily-cell interaction study. Current bar interactions are covered by continuous-gantt-qa.cjs.
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 1000 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-14T12:00:00+08:00'));
    page.setDefaultTimeout(5000);
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    const fragment = fs.readFileSync(dir + 'requirement-modal-study.html', 'utf8');
    await page.route('http://gantt-gestures.test/**', route => route.fulfill({ contentType: 'text/html; charset=utf-8', body: '<!doctype html><html><head><meta charset="utf-8"></head><body><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve();}};</script>' + fragment + '</body></html>' }));
    await page.goto('http://gantt-gestures.test/');
    const nav = value => page.locator(`[data-nav="${value}"]`).click();
    const read = () => page.evaluate(() => JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    await nav('gantt');
    const base = await read();
    const load = async (edit = () => {}) => {
      const fixture = structuredClone(base);
      fixture.revision = (await read()).revision + 1000;
      fixture.ganttRange = { start: '2026-11-09', end: '2026-12-14' };
      fixture.logs = []; fixture.undoHistory = []; fixture.filters.priority = ''; fixture.view = 'gantt';
      edit(fixture);
      await page.evaluate(async data => {
        window.dispatchEvent(new CustomEvent('openai:set_globals', { detail: { globals: { widgetState: { privateContent: data } } } }));
        await new Promise(requestAnimationFrame);
      }, fixture);
      await nav('gantt');
      return fixture;
    };
    const cell = (id, date) => page.locator(`tr[data-gantt-row="${id}"] td[data-date="${date}"]`);
    const fill = (id, date) => cell(id, date).locator('button.gm-fill');
    const point = async locator => {
      const rect = await locator.boundingBox(); assert(rect, 'Missing gesture target');
      return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    };
    const gesture = async (id, from, to, button = 'left', targetId = id, during) => {
      const a = await point(fill(id, from)), b = await point(cell(targetId, to));
      await page.mouse.move(a.x, a.y); await page.mouse.down({ button });
      await page.mouse.move(b.x, b.y, { steps: 5 });
      if (during) await during();
      await page.mouse.up({ button });
    };
    const candidates = () => page.locator('.gm-range-candidate').evaluateAll(cells => cells.map(el => el.dataset.date));
    const unchangedOthers = (state, fixture, id) => assert.deepEqual(state.rows.filter(row => row.id !== id), fixture.rows.filter(row => row.id !== id));
    const row = (state, id) => state.rows.find(value => value.id === id);

    assert.deepEqual(await page.locator('.gm-nav > button').allTextContents(), ['甘特图', '需求池', '需求归档', '设置']);
    const fixture = await load();
    await gesture(1, '2026-11-16', '2026-11-19', 'right', 1, async () => {
      assert(await page.locator('.gm-app').evaluate(el => el.classList.contains('gm-dragging')), 'Right drag requires no hold timer');
    });
    let state = await read();
    assert.equal(row(state, 1).start, '2026-11-19'); assert.equal(row(state, 1).days, 3);
    assert.equal(await fill(1, '2026-11-23').count(), 1);
    assert(await page.locator('.gm-day-menu').isHidden());
    unchangedOthers(state, fixture, 1); assert.equal(state.logs.length, 1);
    await fill(1, '2026-11-19').click({ button: 'right' });
    assert(await page.locator('.gm-day-menu').isVisible(), 'Stationary right click opens date menu');
    await page.keyboard.press('Escape');

    await load();
    await gesture(3, '2026-11-16', '2026-11-23', 'right');
    state = await read(); assert.deepEqual(state.rows, base.rows); assert.equal(state.logs.length, 0);
    await gesture(1, '2026-11-16', '2026-11-19', 'right', 2);
    state = await read(); assert.deepEqual(state.rows, base.rows); assert.equal(state.logs.length, 0);

    const leaveFixture = await load(data => { row(data, 1).dayMarks = { '2026-11-25': 'leave' }; });
    await gesture(1, '2026-11-17', '2026-11-30');
    assert.deepEqual(await candidates(), ['2026-11-19', '2026-11-20', '2026-11-23', '2026-11-24', '2026-11-26', '2026-11-27', '2026-11-30']);
    assert.equal(await page.locator('[data-add-range]').count(), 1);
    state = await read(); assert.deepEqual(state.rows, leaveFixture.rows); assert.equal(state.logs.length, 0);
    await page.locator('[data-add-range]').click();
    state = await read(); assert.equal(row(state, 1).days, 10); assert.equal(row(state, 1).start, '2026-11-16');
    assert.deepEqual(row(state, 1).skippedDates, ['2026-11-25']);
    assert.equal(await cell(1, '2026-11-30').locator('[data-phase]').count(), 1);
    assert.equal(await cell(1, '2026-11-25').locator('[data-phase]').count(), 0);
    assert.equal(state.logs.length, 1); assert.equal(state.logs[0].action, '延长排期'); assert.equal(state.undoHistory.length, 1);
    unchangedOthers(state, leaveFixture, 1);
    await page.reload(); await page.locator('tr[data-gantt-row="1"]').waitFor();
    assert.equal(await cell(1, '2026-11-30').locator('[data-phase]').count(), 1, 'Extended delivery persists');
    await nav('pool');
    assert.equal(await page.locator('tr[data-row="1"] td[data-key="delivery"]').textContent(), '11/30');

    await load(); await gesture(1, '2026-11-17', '2026-11-30'); await page.keyboard.press('Escape');
    assert.equal(await page.locator('[data-add-range]').count(), 0); assert.deepEqual((await read()).rows, base.rows);
    await gesture(1, '2026-11-17', '2026-11-30'); await page.locator('.gm-brand').click();
    assert.equal(await page.locator('[data-add-range]').count(), 0); assert.deepEqual((await read()).rows, base.rows);
    await gesture(1, '2026-11-17', '2026-11-30', 'left', 2);
    assert.equal(await page.locator('[data-add-range]').count(), 0); assert.equal((await read()).logs.length, 0);

    await load(); await gesture(1, '2026-11-17', '2026-11-12');
    assert.deepEqual(await candidates(), ['2026-11-12', '2026-11-13']);
    await page.locator('[data-add-range]').click(); state = await read();
    assert.equal(row(state, 1).start, '2026-11-12'); assert.equal(row(state, 1).days, 5);
    assert.equal(await cell(1, '2026-11-18').locator('[data-phase]').count(), 1);

    await load(); await gesture(3, '2026-11-16', '2026-11-30');
    assert.equal(await page.locator('[data-add-range]').count(), 0, 'HOLD cannot be filled');
    assert.equal((await read()).logs.length, 0);
    const normalGap = await load(data => { row(data, 3).segments[1].holdBefore = false; });
    await gesture(3, '2026-11-16', '2026-11-30');
    assert.deepEqual(await candidates(), ['2026-11-18', '2026-11-19', '2026-11-20']);
    await page.locator('[data-add-range]').click(); state = await read();
    assert.equal(row(state, 3).segments[0].end, '2026-11-20');
    assert.deepEqual(row(state, 3).segments[1], row(normalGap, 3).segments[1]); assert.equal(row(state, 3).days, 7);

    await load(data => { row(data, 1).start = '2026-09-28'; data.ganttRange = { start: '2026-09-21', end: '2026-10-16' }; });
    await gesture(1, '2026-09-29', '2026-10-12');
    assert.deepEqual(await candidates(), ['2026-10-08', '2026-10-09', '2026-10-10', '2026-10-12']);
    await page.locator('[data-add-range]').click(); state = await read(); assert.equal(row(state, 1).days, 7);
    assert.equal(await cell(1, '2026-10-12').locator('[data-phase]').count(), 1);

    await load(data => { row(data, 5).start = '2026-11-19'; });
    await gesture(5, '2026-11-20', '2026-11-26'); await page.locator('[data-add-range]').click();
    assert.equal(row(await read(), 5).days, 6, 'Placeholder converts to actual scheduled duration without losing original cells');

    await load();
    for (const date of ['2026-11-18', '2026-11-19', '2026-11-20']) assert.equal(await cell(3, date).locator('[data-mark="hold"]').count(), 1);
    for (const date of ['2026-11-21', '2026-11-22']) {
      assert.equal(await cell(3, date).locator('[data-mark="hold"]').count(), 0, 'Weekend is not HOLD');
      assert((await cell(3, date).getAttribute('aria-label')).includes('休息日'));
    }
    await load(data => {
      Object.assign(row(data, 3), { start: '2026-09-30', days: 2, segments: [{ start: '2026-09-30', end: '2026-09-30' }, { start: '2026-10-08', end: '2026-10-08', holdBefore: true }] });
      data.ganttRange = { start: '2026-09-28', end: '2026-10-16' };
    });
    for (let day = 1; day <= 7; day++) assert.equal(await cell(3, '2026-10-0' + day).locator('[data-mark="hold"]').count(), 0, 'Legal holiday is not HOLD');
    await load(data => {
      Object.assign(row(data, 3), { start: '2026-10-09', days: 2, segments: [{ start: '2026-10-09', end: '2026-10-09' }, { start: '2026-10-12', end: '2026-10-12', holdBefore: true }] });
      data.ganttRange = { start: '2026-10-08', end: '2026-10-16' };
    });
    assert.equal(await cell(3, '2026-10-10').locator('[data-mark="hold"]').count(), 1, 'Makeup Saturday is a working HOLD day');
    assert.equal(await cell(3, '2026-10-11').locator('[data-mark="hold"]').count(), 0);

    await load();
    await fill(1, '2026-11-16').click({ button: 'right' });
    const actions = page.locator('.gm-day-menu > [data-day-mark]');
    assert.equal(await actions.count(), 1); assert.equal((await actions.textContent()).trim(), '休假');
    assert.equal(await page.locator('[data-day-mark="normal"]').count(), 0, 'Redundant reset action is removed');
    assert.equal((await read()).logs.length, 0);
    await page.keyboard.press('Home');
    assert.equal(await page.evaluate(() => document.activeElement.dataset.dayMark), 'leave', 'Single-action menu remains keyboard accessible');
    await page.locator('[data-day-mark="leave"]').click();
    state = await read(); assert.equal(row(state, 1).days, 3); assert.equal(row(state, 1).start, '2026-11-16');
    await fill(1, '2026-11-16').click({ button: 'right' }); assert.equal((await actions.textContent()).trim(), '取消休假');
    await page.locator('[data-day-mark="cancel-leave"]').click(); state = await read();
    assert.equal(row(state, 1).dayMarks['2026-11-16'], undefined); assert.equal(row(state, 1).days, 3);
    assert.equal(await fill(1, '2026-11-18').count(), 1); assert.equal(state.logs.length, 2);
    await fill(1, '2026-11-16').click({ button: 'right' }); assert.equal((await actions.textContent()).trim(), '休假'); await page.keyboard.press('Escape');
    await cell(1, '2026-11-21').click({ button: 'right' }); assert.equal((await actions.textContent()).trim(), '加班');
    await page.locator('[data-day-mark="overtime"]').click();
    await fill(1, '2026-11-21').click({ button: 'right' }); assert.equal((await actions.textContent()).trim(), '取消加班');
    await page.locator('[data-day-mark="cancel-overtime"]').click(); assert.equal(await fill(1, '2026-11-21').count(), 0, 'Cancel overtime returns empty weekend to rest');
    state = await read(); assert.equal(row(state, 1).days, 3); assert.equal(row(state, 1).start, '2026-11-16');
    await load(data => { Object.assign(row(data, 1), { start: '2026-11-20', overtime: ['2026-11-21'], dayMarks: { '2026-11-21': 'overtime' } }); });
    await fill(1, '2026-11-21').click({ button: 'right' });
    assert.equal(await actions.count(), 1); assert.equal((await actions.textContent()).trim(), '取消加班');
    assert.equal((await read()).logs.length, 0); await page.keyboard.press('Escape');

    await load();
    await gesture(1, '2026-11-17', '2026-11-30');
    const add = page.locator('[data-add-range]'), addRect = await add.boundingBox(), cellRect = await cell(1, '2026-11-30').boundingBox();
    assert(addRect.x > cellRect.x && addRect.x + addRect.width < cellRect.x + cellRect.width, 'Add action stays inside its cell');
    assert(addRect.y > cellRect.y && addRect.y + addRect.height < cellRect.y + cellRect.height, 'Add action does not cover adjacent rows');
    assert.equal(await add.evaluate(el => getComputedStyle(el).backgroundColor), 'rgba(0, 0, 0, 0)', 'Add action has no heavy fill');
    assert(await add.evaluate(el => el.ownerDocument.activeElement !== el), 'Mouse selection does not force an outline around add');
    await page.keyboard.press('Escape'); assert.equal(await add.count(), 0);
    assert.equal(await page.locator('th.gm-current[aria-current="date"]').count(), 1);
    assert.equal(await cell(1, '2026-11-14').evaluate(el => getComputedStyle(el).boxShadow), 'none', 'No vertical today line');
    const todayTint = await cell(1, '2026-11-14').evaluate(el => getComputedStyle(el).backgroundColor);
    assert(/^rgba\(.+, 0\./.test(todayTint), 'Today column uses a translucent fill');
    for (const id of base.rows.map(value => value.id)) assert.equal(await cell(id, '2026-11-14').evaluate(el => getComputedStyle(el).backgroundColor), todayTint);
    assert((await page.locator('th.gm-current').evaluate(el => getComputedStyle(el).boxShadow)).includes('0px 2px'), 'Today line is on top of the date header');

    const liveFixture = data => {
      Object.assign(row(data, 1), { status: '开发中', start: '2026-11-13', days: 6, segments: [{ start: '2026-11-13', end: '2026-11-17', overtime: ['2026-11-14'] }, { start: '2026-11-19', end: '2026-11-20', holdBefore: true }] });
    };
    await load(liveFixture);
    assert(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count() > 0);
    assert(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count() <= 10, 'Particle density is bounded for each phase');
    assert.deepEqual(await page.locator('tr[data-gantt-row="1"] .gm-live-phase').evaluateAll(buttons => [...new Set(buttons.map(button => button.dataset.phase))]), ['0'], 'Only the phase containing today animates');
    assert.equal(await page.locator('tr[data-gantt-row="1"] [data-phase="1"] .gm-floating-point').count(), 0);
    assert.equal(await page.locator('tr[data-gantt-row="2"] .gm-floating-point').count(), 0);
    assert.equal(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').first().evaluate(el => getComputedStyle(el).pointerEvents), 'none');
    await fill(1, '2026-11-14').click({ button: 'right' }); await page.locator('[data-day-mark="cancel-overtime"]').click();
    assert.equal(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count(), 0, 'Canceling overtime today stops motion throughout the phase');
    await load(data => { liveFixture(data); row(data, 1).segments[0].overtime = []; });
    assert.equal(await page.locator('.gm-floating-point').count(), 0, 'Ordinary weekend does not animate');
    for (const status of ['待评审', '待开发', '已完成', 'HOLD']) {
      await load(data => { liveFixture(data); row(data, 1).status = status; });
      assert.equal(await page.locator('.gm-floating-point').count(), 0, 'Only development status animates: ' + status);
    }
    await load(data => { liveFixture(data); row(data, 1).developer = ''; });
    assert.equal(await page.locator('.gm-floating-point').count(), 0, 'Unassigned demand does not animate');
    await load(data => { liveFixture(data); data.personalPreferences['张金科'] = { reduceMotion: true }; });
    assert.equal(await page.locator('.gm-floating-point').first().evaluate(el => getComputedStyle(el).animationName), 'none');
    await load(liveFixture); await page.emulateMedia({ reducedMotion: 'reduce' });
    assert.equal(await page.locator('.gm-floating-point').first().evaluate(el => getComputedStyle(el).animationName), 'none');
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00'));
    await load();
    assert(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count() > 0, 'Working today inside development phase animates');
    await fill(1, '2026-11-17').click({ button: 'right' }); await page.locator('[data-day-mark="leave"]').click();
    assert.equal(await page.locator('tr[data-gantt-row="1"] .gm-floating-point').count(), 0, 'Working-day leave today stops motion throughout the phase');
    await load(data => { row(data, 1).start = '2026-11-13'; row(data, 1).days = 2; });
    assert.equal(await page.locator('.gm-floating-point').count(), 0, 'Past phase does not animate');
    await load(data => { row(data, 1).start = '2026-11-18'; });
    assert.equal(await page.locator('.gm-floating-point').count(), 0, 'Future phase does not animate');
    await load(data => { Object.assign(row(data, 1), { start: '2026-11-16', days: 2, segments: [{ start: '2026-11-16', end: '2026-11-16' }, { start: '2026-11-19', end: '2026-11-19', holdBefore: true }] }); });
    assert.equal(await page.locator('.gm-floating-point').count(), 0, 'HOLD interval is not a live development phase');

    await load(data => { data.actor = '孙莉'; });
    await gesture(1, '2026-11-16', '2026-11-19', 'right');
    await gesture(1, '2026-11-17', '2026-11-30');
    assert.equal(await page.locator('[data-add-range]').count(), 0); assert.deepEqual((await read()).rows, base.rows);
    await load(data => { data.personalPreferences['张金科'] = { reduceMotion: true }; });
    await gesture(1, '2026-11-17', '2026-11-30');
    assert.equal(await page.locator('.gm-range-candidate').first().evaluate(el => getComputedStyle(el, '::before').animationName), 'none');
    await page.keyboard.press('Escape');
    for (const width of [1024, 736, 320]) {
      await page.setViewportSize({ width, height: 1000 });
      for (const view of ['gantt', 'pool', 'archive']) {
        await nav(view);
        const selector = view === 'gantt' ? '.gm-gantt-priorities' : '.gm-priority-filters';
        const a = await page.locator(selector).boundingBox(), b = await page.locator('.gm-main').boundingBox();
        assert(a.x < b.x + 25, `${view} priorities must be on the left at ${width}`);
        assert(await page.locator('.gm-app').evaluate(el => el.scrollWidth <= el.clientWidth + 1), `Overflow at ${width}`);
      }
    }
    assert.deepEqual(errors, []);
    console.log('Passed: gestures, calendar/HOLD, direct day toggles without reset, in-cell add, translucent today column/top marker, current development particles, split/status/calendar/leave guards, reduced motion, audit, persistence and layout.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });

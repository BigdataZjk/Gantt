// Product-requested pointer-relative speech bubbles, offset from the cursor and flipped at edges.
function installProductTooltips(product){
  const doc=product.ownerDocument,bubble=doc.createElement('div');bubble.className='gm-tooltip-bubble';bubble.hidden=true;bubble.id='gm-product-tooltip';bubble.setAttribute('role','tooltip');product.append(bubble);
  let active=null,point=null,timer=0,frame=0;
  const convert=()=>{for(const node of product.querySelectorAll('[data-tooltip]')){node.dataset.productTooltip=node.dataset.tooltip;node.removeAttribute('data-tooltip');}if(active&&!active.isConnected)hide();};
  function hide(){clearTimeout(timer);cancelAnimationFrame(frame);bubble.hidden=true;if(active){const ids=(active.getAttribute('aria-describedby')||'').split(/\s+/).filter(id=>id&&id!==bubble.id);ids.length?active.setAttribute('aria-describedby',ids.join(' ')):active.removeAttribute('aria-describedby');}active=null;point=null;}
  function position(){
    frame=0;if(!active||bubble.hidden)return;
    const app=product.getBoundingClientRect(),rect=active.getBoundingClientRect(),p=point||{x:rect.left+rect.width/2,y:rect.bottom},width=bubble.offsetWidth,height=bubble.offsetHeight;
    let x=p.x-app.left+16,y=p.y-app.top+20,side='below',align='right';
    if(x+width>app.width-8){x=p.x-app.left-width-16;align='left';}
    if(y+height>app.height-8){y=p.y-app.top-height-20;side='above';}
    bubble.style.left=Math.max(8,Math.min(x,app.width-width-8))+'px';bubble.style.top=Math.max(8,Math.min(y,app.height-height-8))+'px';bubble.dataset.side=side;bubble.dataset.align=align;
  }
  function activate(node,event){
    if(active===node)return;hide();active=node;point=event?{x:event.clientX,y:event.clientY}:null;
    timer=setTimeout(()=>{if(!active)return;bubble.textContent=active.dataset.productTooltip;if(!bubble.textContent)return;bubble.hidden=false;const ids=new Set((active.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean));ids.add(bubble.id);active.setAttribute('aria-describedby',[...ids].join(' '));position();},100);
  }
  product.addEventListener('pointerover',event=>{if(event.pointerType==='touch')return;const node=event.target.closest('[data-product-tooltip]');if(node)activate(node,event);else hide();});
  product.addEventListener('pointermove',event=>{if(!active)return;point={x:event.clientX,y:event.clientY};if(!frame)frame=requestAnimationFrame(position);});
  product.addEventListener('pointerout',event=>{if(active&&!active.contains(event.relatedTarget))hide();});
  product.addEventListener('focusin',event=>{const node=event.target.closest('[data-product-tooltip]');if(node)activate(node);});
  product.addEventListener('focusout',hide);product.addEventListener('pointerdown',hide);product.addEventListener('pointerleave',hide);product.addEventListener('scroll',hide,true);window.addEventListener('resize',hide);
  new MutationObserver(convert).observe(product,{subtree:true,childList:true,attributes:true,attributeFilter:['data-tooltip']});convert();return {hide};
}

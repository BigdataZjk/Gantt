  function trimOperationHistory(){
    s.logs=s.logs.slice(0,200);
    const recent=new Set(s.logs.slice(0,50).map(entry=>entry.id));
    s.undoHistory=s.undoHistory.filter(step=>recent.has(step.id)).slice(-50);
  }
  function logPageState(){
    const saved=s.logPagination||{},pageSize=Number.isInteger(saved.pageSize)&&saved.pageSize>=1&&saved.pageSize<=200?saved.pageSize:20;
    const pages=Math.max(1,Math.ceil(s.logs.length/pageSize)),page=Math.max(1,Math.min(pages,Math.floor(Number(saved.page)||1)));
    s.logPagination={page,pageSize};return {page,pageSize,pages,start:(page-1)*pageSize};
  }
  function canUndoLog(id){return s.logs.slice(0,50).some(entry=>entry.id===id)&&s.undoHistory.some(step=>step.id===id);}
  function renderLogs(){
    const {page,pageSize,pages,start}=logPageState(),entries=s.logs.slice(start,start+pageSize),visibleEnd=Math.min(start+pageSize,s.logs.length);
    const row=entry=>{
      const eligible=canUndoLog(entry.id),old=s.logs.findIndex(item=>item.id===entry.id)>=50;
      const reason=!isAdmin()?'仅管理员和超级管理员可撤回':old?'已超出最近 50 条操作':!eligible?'此动作不支持撤回，或已被撤回':'';
      return `<tr data-log="${entry.id}"><td>${timeLabel(entry.time)}</td><td>${esc(entry.actor)}</td><td>${esc(entry.action)}</td><td>${esc(entry.target)}</td><td><button type="button" class="gm-link" data-log-details="${entry.id}">查看变更</button></td><td><span ${reason?`data-tooltip="${esc(reason)}"`:''}><button type="button" class="gm-link" data-log-undo="${entry.id}" ${isAdmin()&&eligible?'':'disabled'}>撤回到此动作</button></span></td></tr>`;
    };
    app.querySelector('[data-settings-panel="logs"]').innerHTML=`<div class="gm-settings-tools gm-log-tools"><span class="gm-caption">全系统共用 · 保留最近 200 条</span><span class="gm-caption">最近 50 条内的数据变更可撤回</span></div><div class="gm-table-wrap"><table class="gm-table gm-logs-table" aria-label="操作记录"><thead><tr><th>时间</th><th>操作人</th><th>操作</th><th>对象</th><th>详情</th><th>撤回</th></tr></thead><tbody>${entries.length?entries.map(row).join(''):'<tr><td colspan="6" class="gm-empty">暂无正式操作记录</td></tr>'}</tbody></table></div><nav class="gm-log-pagination" aria-label="操作记录分页"><span class="gm-caption" role="status" aria-live="polite">共 ${s.logs.length} 条${s.logs.length?' · '+(start+1)+'–'+visibleEnd:''}</span><div class="gm-log-page-controls"><label class="gm-log-page-size" for="gm-log-page-size"><span>每页</span><input id="gm-log-page-size" type="number" min="1" max="200" step="1" required value="${pageSize}" data-log-page-size aria-label="操作记录每页行数"><span>条</span></label><div class="gm-log-page-navigation"><button type="button" class="gm-btn gm-quiet" data-log-page="${page-1}" aria-label="上一页操作记录" ${page<=1?'disabled':''}><i data-lucide="chevron-left" aria-hidden="true"></i></button><span class="gm-log-page-number" aria-label="第 ${page} 页，共 ${pages} 页">${page} / ${pages}</span><button type="button" class="gm-btn gm-quiet" data-log-page="${page+1}" aria-label="下一页操作记录" ${page>=pages?'disabled':''}><i data-lucide="chevron-right" aria-hidden="true"></i></button></div></div></nav>`;
  }
  function setLogPage(value){
    const {pages}=logPageState(),focused=app.ownerDocument.activeElement,focusLabel=focused?.hasAttribute('data-log-page')?focused.getAttribute('aria-label'):'';
    s.logPagination.page=Math.max(1,Math.min(pages,Number(value)||1));renderLogs();icons();persist(false);
    if(focusLabel){const matching=app.querySelector(`[data-log-page][aria-label="${focusLabel}"]`);(matching&&!matching.disabled?matching:app.querySelector('[data-log-page]:not(:disabled)'))?.focus({preventScroll:true});}
  }
  function setLogPageSize(input){
    const value=Number(input.value);
    if(!input.value||!Number.isInteger(value)||value<1||value>200){input.setCustomValidity('请输入 1–200 之间的整数');input.reportValidity();return;}
    input.setCustomValidity('');const focused=app.ownerDocument.activeElement===input;
    s.logPagination={page:1,pageSize:value};renderLogs();icons();persist(false);
    if(focused)app.querySelector('[data-log-page-size]')?.focus({preventScroll:true});
  }

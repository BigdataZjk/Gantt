// Password interaction study. Entered values stay in this preview's memory, outside snapshots and widget state.
function installPasswordControls(product,{current,loggedIn,isSuper,onChanged,escape,icons}){
  const doc=product.ownerDocument,secrets=new Map(),layer=doc.createElement('div');layer.className='gm-password-layer';layer.hidden=true;layer.innerHTML='<button type="button" class="gm-scrim" data-password-close aria-label="关闭密码面板"></button><section class="gm-password-dialog" role="dialog" aria-modal="true" aria-label="修改密码"></section>';product.append(layer);let target='',reset=false,returnFocus=null,openedBy='';
  function fieldMarkup(id,label,attributes='',value='',required=false) {
    return `<div class="gm-field"><label for="${escape(id)}">${escape(label)}${required?'<span class="gm-required" aria-hidden="true">*</span>':''}</label><div class="gm-password-input"><input id="${escape(id)}" type="password" ${attributes} ${required?'required':''} value="${escape(value)}"><button type="button" class="gm-password-eye" data-password-eye="${escape(id)}" data-password-label="${escape(label)}" aria-label="${escape('显示'+label)}" aria-controls="${escape(id)}" aria-pressed="false" data-tooltip="显示密码" ${attributes.includes('readonly')&&!value?'disabled':''}><i data-lucide="eye" aria-hidden="true"></i></button></div></div>`;
  }
  function close(){layer.hidden=true;product.querySelector('.gm-base').inert=false;returnFocus?.focus({preventScroll:true});layer.querySelector('section').innerHTML='';target='';}
  function open(name,superReset=false){
    if(!loggedIn()||superReset&&!isSuper()||!superReset&&name!==current())return;
    target=name;reset=superReset;openedBy=current();returnFocus=doc.activeElement;const known=secrets.get(name)||'',title=reset?'重设密码':'修改密码';
    layer.querySelector('section').innerHTML=`<div class="gm-password-head"><div><h3>${title}</h3><span class="gm-caption">${escape(name)}</span></div><button type="button" class="gm-btn gm-quiet" data-password-close aria-label="关闭密码面板"><i data-lucide="x" aria-hidden="true"></i></button></div>${fieldMarkup('gm-password-current','当前密码',reset?'readonly placeholder="尚未设置"':'autocomplete="current-password"',reset?known:'')}${fieldMarkup('gm-password-new','新密码','autocomplete="new-password"')}<p class="gm-password-error" role="alert" hidden></p><div class="gm-password-actions"><button type="button" class="gm-btn" data-password-close>取消</button><button type="button" class="gm-btn gm-primary" data-password-commit disabled>${reset?'保存新密码':'修改密码'}</button></div>`;
    layer.hidden=false;product.querySelector('.gm-base').inert=true;icons();layer.querySelector(reset?'#gm-password-new':'#gm-password-current').focus({preventScroll:true});
  }
  function update(){const next=layer.querySelector('#gm-password-new').value,old=layer.querySelector('#gm-password-current').value;layer.querySelector('[data-password-commit]').disabled=!next||(!reset&&!old)||next===(reset?secrets.get(target):old);layer.querySelector('.gm-password-error').hidden=true;}
  function commit(){
    if(!target||!loggedIn()||reset&&!isSuper())return;const old=layer.querySelector('#gm-password-current').value,next=layer.querySelector('#gm-password-new').value,error=layer.querySelector('.gm-password-error');
    const reason=!next?'请输入新密码':!reset&&!secrets.has(target)?'请先由超级管理员设置初始密码':!reset&&secrets.get(target)!==old?'当前密码不正确':next===secrets.get(target)?'新密码没有变化':'';
    if(reason){error.textContent=reason;error.hidden=false;return;}
    const name=target,superReset=reset;secrets.set(name,next);close();onChanged(name,superReset);
  }
  product.addEventListener('click',event=>{const button=event.target.closest('button');if(!button)return;
    if(button.dataset.passwordEye){const input=doc.getElementById(button.dataset.passwordEye);if(!input)return;const show=input.type==='password';input.type=show?'text':'password';button.setAttribute('aria-pressed',String(show));button.setAttribute('aria-label',(show?'隐藏':'显示')+(button.dataset.passwordLabel||'密码'));button.dataset.tooltip=show?'隐藏密码':'显示密码';button.innerHTML=`<i data-lucide="${show?'eye-off':'eye'}" aria-hidden="true"></i>`;icons();input.focus({preventScroll:true});return;}
    if(button.hasAttribute('data-self-password'))open(current());if(button.dataset.accountPasswordManage&&isSuper())open(button.dataset.accountPasswordManage,true);
  });
  layer.addEventListener('input',update);layer.addEventListener('click',event=>{if(event.target.closest('[data-password-close]'))close();else if(event.target.closest('[data-password-commit]'))commit();});
  layer.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}if(event.key==='Enter'&&event.target.tagName==='INPUT'){event.preventDefault();commit();}if(event.key==='Tab'){const nodes=[...layer.querySelector('section').querySelectorAll('input,button:not(:disabled)')];if(event.shiftKey&&event.target===nodes[0]){event.preventDefault();nodes.at(-1).focus();}else if(!event.shiftKey&&event.target===nodes.at(-1)){event.preventDefault();nodes[0].focus();}}});
  return {sync(){if(!layer.hidden&&(!loggedIn()||openedBy!==current()||reset&&!isSuper()))close();},fieldMarkup,set(name,value){if(value)secrets.set(name,value);},has:name=>secrets.has(name),verify:(name,value)=>secrets.has(name)&&secrets.get(name)===value};
}

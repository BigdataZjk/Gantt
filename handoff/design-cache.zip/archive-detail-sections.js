  function openArchiveDetails(id){
    const row=s.rows.find(item=>item.id===Number(id)&&item.archived&&!item.deleted);if(!row||s.mode)return;
    openUtilityDrawer('archive-details',{id:row.id});
  }
  function renderArchiveDetails(){
    const row=s.rows.find(item=>item.id===Number(s.draft?.id)&&item.archived&&!item.deleted);if(!row)return;
    const archiveDate=value=>validDate(value)?value:'-';
    const field=(label,value,wide=false)=>`<div class="gm-readonly-field${wide?' gm-readonly-wide':''}"><dt>${label}</dt><dd>${value||'-'}</dd></div>`;
    const link=(label,key)=>{
      const value=String(row[key]||'').trim();if(!value)return field(label,'-',true);
      const text=esc(value),valid=/^https?:\/\/[^\s]+$/i.test(value);
      return field(label,`<div class="gm-readonly-link">${valid?`<a href="${text}" target="_blank" rel="noopener noreferrer" data-archive-link="${key}">${text}</a>`:`<span data-archive-link="${key}">${text}</span>`}<button type="button" class="gm-btn gm-quiet" data-link-copy="${key}" aria-label="复制${label}" data-tooltip="复制${label}"><i data-lucide="copy" aria-hidden="true"></i></button></div><span class="gm-link-feedback" data-link-feedback="${key}" role="status" aria-live="polite"></span>`,true);
    };
    const phases=phaseList(row),segments=phases.length>1?`<section class="gm-readonly-schedule"><h4>分段排期</h4><ol>${phases.map((phase,index)=>`${index&&hasWorkingHold(row,index)?`<li class="gm-readonly-hold">HOLD · ${archiveDate(advance(phases[index-1].end))}—${archiveDate(shiftDate(phase.start,-1))}</li>`:''}<li><span class="gm-caption">第 ${index+1} 段</span><span>${archiveDate(phase.start)}—${archiveDate(phase.end)}</span><span>${phaseDays(phase)} 人天</span></li>`).join('')}</ol></section>`:'';
    const marks=Object.entries(row.dayMarks||{}).sort(([a],[b])=>a.localeCompare(b)),markList=marks.length?`<section class="gm-readonly-daymarks"><h4>日期标记</h4><div>${marks.map(([date,type])=>`<span>${archiveDate(date)} · ${{leave:'休假',overtime:'加班',rest:'取消加班'}[type]||esc(type)}</span>`).join('')}</div></section>`:'';
    drawer.innerHTML=`<header class="gm-drawer-head"><div><h3 id="gm-dialog-title">需求详情</h3><span class="gm-caption">已归档 · 只读${row.archivedAt?' · '+esc(timeLabel(row.archivedAt)):''}</span></div><button type="button" class="gm-btn gm-quiet" data-dismiss aria-label="收起需求详情"><i data-lucide="x" aria-hidden="true"></i></button></header>
      <div class="gm-form gm-archive-details"><div class="gm-archive-sections">
        <section class="gm-archive-section" data-archive-section="basic" aria-labelledby="gm-archive-basic-title"><h4 id="gm-archive-basic-title">基本信息</h4><dl class="gm-readonly-grid">
          ${field('需求名',`<div class="gm-readonly-name">${priority(row.priority)}<span>${esc(row.name)}</span></div>`,true)}
          ${field('状态',dictionaryTag('status',row.status))}${field('提需日期',archiveDate(row.requestedAt))}${field('提需人',esc(row.requester||'-'),true)}${link('PRD 链接','prd')}
        </dl></section>
        <section class="gm-archive-section" data-archive-section="schedule" aria-labelledby="gm-archive-schedule-title"><h4 id="gm-archive-schedule-title">排期信息</h4><dl class="gm-readonly-grid">
          ${field('业务域',dictionaryTag('domain',row.domain))}${field('需求类型',dictionaryTag('requestType',row.requestType))}${field('开发人',esc(row.developer||'-'))}${field('开发人天',row.days===0?'0 · 待估人天':String(row.days??'-'))}${field('准入日期',archiveDate(row.start))}${field('交付日期',archiveDate(delivery(row)))}${link('望岳工单链接','wangyue')}
        </dl>${segments}${markList}</section>
        <section class="gm-archive-section" data-archive-section="extra" aria-labelledby="gm-archive-extra-title"><h4 id="gm-archive-extra-title">补充信息</h4><dl class="gm-readonly-grid">
          ${field('项目',esc(row.project||'-'),true)}${link('BRD 链接','brd')}${field('评审日期',archiveDate(row.review))}${field('预期交付日期',archiveDate(row.expected))}${field('备注',`<span class="gm-readonly-notes">${esc(row.notes||'-')}</span>`,true)}
        </dl></section>
      </div><div class="gm-form-actions"><span class="gm-caption">恢复到需求池后可编辑</span><button type="button" class="gm-btn" data-dismiss>关闭</button></div></div>`;
    icons();
  }

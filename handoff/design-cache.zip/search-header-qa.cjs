const fs=require('node:fs');
const assert=require('node:assert/strict');
const {chromium}=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir='C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1220,height:1100},colorScheme:'light'}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));page.setDefaultTimeout(4000);
  const source=fs.readFileSync(dir+'requirement-modal-study.html','utf8');
  await page.route('http://gantt-search.test/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<!doctype html><meta charset="utf-8"><style>body{margin:0}</style><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve()}};</script>'+source}));
  await page.goto('http://gantt-search.test/');
  const search=page.locator('.gm-shared-search'),input=search.locator('input'),toggle=search.locator('button');
  const open=async()=>{await toggle.click();await input.waitFor({state:'visible'});await page.waitForFunction(()=>document.activeElement?.matches('[data-search-input]'));};
  const closed=async()=>{await page.waitForFunction(()=>document.querySelector('.gm-shared-search').dataset.expanded==='false');assert(await input.isDisabled());};
  const read=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
  assert.equal(await search.getAttribute('data-expanded'),'false');await open();await page.waitForTimeout(350);assert(await input.evaluate(e=>e===document.activeElement));
  await page.locator('.gm-brand').click();await closed();await open();await page.keyboard.press('Tab');await page.keyboard.press('Tab');await closed();
  await open();await input.fill('增长');assert(await input.evaluate(e=>e===document.activeElement),'Typing must not detach or blur the input');await page.locator('.gm-brand').click();assert.equal(await search.getAttribute('data-expanded'),'true');assert.equal((await read()).filters.query,'增长');
  await page.reload();assert.equal(await search.getAttribute('data-expanded'),'true');assert.equal(await input.inputValue(),'增长');await input.focus();await input.fill('');await page.locator('.gm-brand').click();await closed();assert.equal((await read()).filters.query,'');
  await open();await input.fill('   ');await page.locator('.gm-brand').click();await closed();assert.equal((await read()).filters.query,'');
  await open();await input.fill('增长');await input.press('Escape');await closed();assert.equal((await read()).filters.query,'');assert(await toggle.evaluate(e=>e===document.activeElement));
  await open();await input.fill('广告');await toggle.click();await closed();assert.equal((await read()).filters.query,'');
  await open();await page.reload();await closed();
  await open();await input.fill('增长');await page.locator('[data-nav="roles"]').click();await closed();await open();await input.fill('李明');assert.equal(await page.locator('table[aria-label="账号列表"] tbody tr').count(),1);await page.locator('.gm-brand').click();assert.equal(await search.getAttribute('data-expanded'),'true');
  await page.locator('[data-nav="gantt"]').click();assert.equal(await input.inputValue(),'增长');await page.locator('[data-nav="roles"]').click();assert.equal(await input.inputValue(),'李明');await input.focus();await input.press('Escape');await closed();
  await page.locator('[data-settings-tab="personal"]').click();assert(await page.locator('[data-search-slot]').isHidden());await page.locator('[data-settings-tab="roles"]').click();await closed();
  assert.equal((await read()).logs.length,0,'Search and header presentation must not write audit records');
  const user=await page.locator('.gm-user').evaluate(e=>{const [name,role]=e.children;const a=name.getBoundingClientRect(),b=role.getBoundingClientRect();return {name:a.toJSON(),role:b.toJSON()};});assert(user.role.y>=user.name.bottom);assert.equal(user.name.x,user.role.x);
  const theme=await page.locator('[data-theme-toggle]').boundingBox();assert.equal(theme.width,50);assert.equal(theme.height,26);
  for(const width of [1024,736,620,480,360,320]){await page.setViewportSize({width,height:1100});await open();await page.waitForTimeout(350);assert(await page.locator('.gm-app').evaluate(e=>e.scrollWidth<=e.clientWidth+1),'No overflow at '+width);const app=await page.locator('.gm-app').boundingBox(),capsule=await page.locator('.gm-search-capsule').boundingBox();assert(capsule.x>=app.x-1&&capsule.x+capsule.width<=app.x+app.width+1,'Capsule inside app at '+width);await input.press('Escape');await closed();await page.waitForTimeout(250);}
  await page.setViewportSize({width:1024,height:1000});await page.locator('[data-nav="gantt"]').click();await input.focus();await input.press('Escape');await closed();await open();await page.waitForTimeout(350);await page.locator('.gm-app').screenshot({path:dir+'compact-search-header-light-qa.png'});await page.locator('[data-theme-toggle]').click();await page.waitForTimeout(350);await page.locator('.gm-app').screenshot({path:dir+'compact-search-header-dark-qa.png'});
  assert.deepEqual(errors,[]);console.log('Passed: empty blur/outside/whitespace collapse, persistent nonempty query, Escape/close clearing, empty reload normalization, separate account search, no audits, vertical identity, compact theme control and responsive capsule down to 320px.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});

const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1150, height: 1000 }, colorScheme: 'light' });
    await page.clock.setFixedTime(new Date('2026-11-14T12:00:00+08:00'));
    page.setDefaultTimeout(5000); const errors = []; page.on('pageerror', error => errors.push(error.message));
    const fragment = fs.readFileSync(dir + 'requirement-modal-study.html', 'utf8');
    await page.route('http://gantt-sequence.test/**', route => route.fulfill({ contentType: 'text/html; charset=utf-8', body: '<!doctype html><html><head><meta charset="utf-8"></head><body><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve();}};</script>' + fragment + '</body></html>' }));
    await page.goto('http://gantt-sequence.test/');
    const nav = value => page.locator(`[data-nav="${value}"]`).click();
    const read = () => page.evaluate(() => JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    await nav('gantt'); const base = await read();
    const row = (state, id) => state.rows.find(row => row.id === id);
    const abc = () => base.rows.slice(0, 3).map((value, index) => {
      const result = structuredClone(value); delete result.segments; delete result.overtime; delete result.dayMarks;
      return { ...result, id: index + 1, name: 'ABC'[index], developer: '张金科', start: ['2026-11-16', '2026-11-18', '2026-11-19'][index], days: [3, 2, 3][index] };
    });
    const load = async (edit = () => {}) => {
      const data = structuredClone(base); data.revision = (await read()).revision + 1000;
      data.rows = abc(); data.logs = []; data.undoHistory = []; data.actor = '张金科'; data.view = 'gantt'; data.ganttRange = { start: '2026-11-09', end: '2026-12-14' };
      edit(data);
      await page.evaluate(async saved => { window.dispatchEvent(new CustomEvent('openai:set_globals', { detail: { globals: { widgetState: { privateContent: saved } } } })); await new Promise(requestAnimationFrame); }, data);
      await nav('gantt'); return data;
    };
    const cell = (id, date) => page.locator(`tr[data-gantt-row="${id}"] td[data-date="${date}"]`);
    const menu = async (id, date) => { await cell(id, date).click({ button: 'right' }); };
    const choose = async ids => { for (let index=0;index<ids.length;index++) await page.locator(`[data-gantt-name="${ids[index]}"]`).click({modifiers:index?['Control']:[]}); };
    const preview = async () => { await page.locator('tr[data-sequence-selected="true"] [data-gantt-name]').first().click({button:'right'}); await page.locator('[data-sequence-preview]').click(); };
    const close = async () => { await page.locator('.gm-drawer [data-dismiss]').first().click(); await page.locator('.gm-layer').waitFor({ state: 'hidden' }); };
    const apply = async () => { await page.locator('[data-sequence-apply]').click(); await page.locator('.gm-layer').waitFor({ state: 'hidden' }); return read(); };

    await load(); await menu(1, '2026-11-16');
    assert.equal(await page.locator('[data-day-mark="overtime"]').count(), 0, 'Workday cannot offer overtime');
    assert.equal(await page.locator('[data-day-mark="leave"]').count(), 1);
    await page.locator('[data-day-mark="leave"]').click(); await menu(1, '2026-11-16');
    assert.equal(await page.locator('[data-day-mark="cancel-leave"]').count(), 1);
    await page.locator('[data-day-mark="cancel-leave"]').click();
    assert.equal(row(await read(), 1).days, 3); assert.equal(row(await read(), 1).start, '2026-11-16');
    await menu(1, '2026-11-21'); assert.equal(await page.locator('[data-day-mark="leave"]').count(), 0, 'Rest day cannot offer leave');
    await page.locator('[data-day-mark="overtime"]').click(); await menu(1, '2026-11-21');
    await page.locator('[data-day-mark="cancel-overtime"]').click(); assert.equal(await cell(1, '2026-11-21').locator('.gm-fill').count(), 0);
    await load(data => Object.assign(row(data, 1), { start: '2026-11-20', overtime: ['2026-11-21'] }));
    await menu(1, '2026-11-21'); assert.equal(await page.locator('[data-day-mark="normal"]').count(), 0);
    await page.locator('[data-day-mark="cancel-overtime"]').click();
    let state = await read(); assert.equal(row(state, 1).dayMarks['2026-11-21'], 'rest'); assert.equal(row(state, 1).days, 3); assert.equal(row(state, 1).start, '2026-11-20');
    assert.deepEqual(row(state, 1).overtime, ['2026-11-21']); assert.equal(await cell(1, '2026-11-21').locator('.gm-fill').count(), 0, 'Implicit overtime can be canceled without shifting dates');
    await menu(1, '2026-11-21'); await page.locator('[data-day-mark="overtime"]').click();
    assert.equal(await cell(1, '2026-11-21').locator('[data-mark="overtime"]').count(), 1);
    await load(data => Object.assign(row(data, 1), { dayMarks: { '2026-11-16': 'overtime', '2026-11-21': 'leave' } }));
    assert.equal(await cell(1, '2026-11-16').locator('[data-mark="overtime"]').count(), 0, 'Legacy invalid workday overtime is ignored');
    assert.equal(await cell(1, '2026-11-21').locator('[data-mark="leave"]').count(), 0, 'Legacy invalid rest-day leave is ignored');

    const locked = await load(); await choose([1, 3]); assert.equal((await read()).logs.length, 0);
    await preview(); assert(await page.locator('[data-sequence-apply]').isDisabled());
    assert((await page.locator('.gm-sequence-warnings').textContent()).includes('B'));
    assert.equal(await page.locator('[data-sequence-change]').count(), 0); await close();
    assert.deepEqual((await read()).rows, locked.rows, 'A/B/C locked overlaps remain unchanged when only A and C selected');
    await load(); await choose([1, 2, 3]); await preview();
    assert.equal(await page.locator('[data-sequence-change]').count(), 2); assert.equal((await read()).logs.length, 0, 'Preview does not commit');
    state = await apply(); assert.equal(row(state, 1).start, '2026-11-16'); assert.equal(row(state, 2).start, '2026-11-19'); assert.equal(row(state, 3).start, '2026-11-23');
    assert.deepEqual(state.rows.map(value => value.days), [3, 2, 3]); assert.equal(state.logs.length, 1); assert.equal(state.logs[0].action, '顺排需求'); assert.equal(state.undoHistory.length, 1);
    await load(); await choose([1, 2]); await preview();
    assert((await page.locator('[data-sequence-change="3"]').textContent()).includes('随动'));
    state = await apply(); assert.equal(row(state, 2).start, '2026-11-19'); assert.equal(row(state, 3).start, '2026-11-20', 'Unselected C keeps one-day overlap with B');
    await load(data => { row(data, 3).dayMarks = { '2026-11-20': 'leave' }; });
    await choose([1, 2]); await preview(); assert(await page.locator('[data-sequence-apply]').isDisabled(), 'Cannot change unselected C overlap count by moving into a leave day');
    assert((await page.locator('.gm-sequence-warnings').textContent()).includes('交叠天数')); await close();

    await load(data => { data.rows = data.rows.slice(0, 2); Object.assign(row(data, 2), { days: 4, segments: [{ start: '2026-11-18', end: '2026-11-19' }, { start: '2026-11-23', end: '2026-11-24', holdBefore: true }] }); });
    await choose([1, 2]); await preview(); state = await apply();
    assert.equal(row(state, 2).days, 4); assert.equal(row(state, 2).segments[0].start, '2026-11-19'); assert.equal(row(state, 2).segments[0].end, '2026-11-20');
    assert.equal(row(state, 2).segments[1].start, '2026-11-24'); assert.equal(row(state, 2).segments[1].end, '2026-11-25'); assert.equal(row(state, 2).segments[1].holdBefore, true);
    await load(data => {
      data.rows = data.rows.slice(0, 2); data.rows.push({ ...data.rows[0], id: 9, name: 'E', developer: '李明', days: 2 }, { ...data.rows[0], id: 10, name: 'F', developer: '李明', start: '2026-11-17', days: 2 });
    });
    await choose([1, 2, 9, 10]); await preview(); state = await apply();
    assert.equal(row(state, 2).start, '2026-11-19'); assert.equal(row(state, 10).start, '2026-11-18', 'Developers sequence independently');
    await load(data => { data.rows = data.rows.slice(0, 2); row(data, 2).start = '2026-11-23'; });
    await choose([1, 2]); await preview(); assert(await page.locator('[data-sequence-apply]').isDisabled()); await close();
    assert.equal(row(await read(), 2).start, '2026-11-23', 'Forward sequencing does not pull future tasks backward');

    await load(data => { data.rows = data.rows.slice(0, 2); Object.assign(row(data, 1), { start: '2026-09-28', days: 3 }); Object.assign(row(data, 2), { start: '2026-09-29', days: 3 }); data.ganttRange = { start: '2026-09-28', end: '2026-10-16' }; });
    await choose([1, 2]); await preview(); state = await apply(); assert.equal(row(state, 2).start, '2026-10-08');
    assert.equal(await cell(2, '2026-10-10').locator('[data-phase]').count(), 1, 'Sequencing honors makeup Saturday');
    await menu(2, '2026-10-10'); assert.equal(await page.locator('[data-day-mark="overtime"]').count(), 0); assert.equal(await page.locator('[data-day-mark="leave"]').count(), 1); await page.keyboard.press('Escape');
    await load(data => { row(data, 2).days = 0; }); await choose([1, 2]); await preview(); state = await apply(); assert.equal(row(state, 2).days, 0, 'Unestimated duration remains unestimated');

    await load(); await choose([1, 2]); await preview();
    const external = await read(); external.revision += 100; row(external, 3).notes = '最新备注';
    await page.evaluate(async data => { window.dispatchEvent(new CustomEvent('openai:set_globals', { detail: { globals: { widgetState: { privateContent: data } } } })); await new Promise(requestAnimationFrame); }, external);
    await page.locator('[data-sequence-apply]').click(); assert(await page.locator('.gm-layer').isVisible(), 'Stale preview must refresh before apply');
    state = await apply(); assert.equal(row(state, 3).notes, '最新备注', 'Applying refreshed preview preserves newer data');
    await load(); await page.locator('[data-gantt-name="1"]').click(); await page.keyboard.press('Control+a'); assert.equal(await page.locator('tr[data-sequence-selected="true"]').count(), 3);
    await page.locator('[data-gantt-name="1"]').click({button:'right'}); await page.locator('[data-sequence-clear]').click(); assert.equal(await page.locator('tr[data-sequence-selected="true"]').count(), 0);
    await load(data => { data.actor = '孙莉'; }); assert.equal(await page.locator('.gm-calendar input[type="checkbox"]').count(), 0); assert.equal(await page.locator('[data-sequence-preview]:visible').count(), 0); assert.equal(await page.locator('[data-resize-edge]').count(), 0);
    await load();
    assert.equal(await page.locator('.gm-create-shiny').evaluate(el => getComputedStyle(el).animationName), 'gm-shiny-angle, gm-shiny-angle');
    await page.emulateMedia({ reducedMotion: 'reduce' });
    assert.equal(await page.locator('.gm-create-shiny').evaluate(el => getComputedStyle(el).animationName), 'none');
    assert.deepEqual(errors, []);
    console.log('Passed: work/rest/makeup menus, cancel implicit and explicit overtime, legacy invalid marks, locked A/B/C, full sequencing, unselected carry, HOLD gaps, multiple developers, Chinese holidays, no-op previews, stale-state refresh, audit and permissions.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });

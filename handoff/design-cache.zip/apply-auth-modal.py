from pathlib import Path

directory = Path(__file__).parent
source = directory / 'requirement-modal-study.html'
text = source.read_text(encoding='utf-8')
backup = directory / 'requirement-modal-study-before-auth.html'
if not backup.exists():
    backup.write_text(text, encoding='utf-8')


def replace_once(old, new):
    global text
    assert text.count(old) == 1, (old[:90], text.count(old))
    text = text.replace(old, new, 1)


old_start = text.index('// Password interaction study.')
old_end = text.index('// Product UI study:', old_start)
text = text[:old_start] + (directory / 'password-controls.js').read_text(encoding='utf-8') + '\n' + text[old_end:]
replace_once('  let dictionaryControls=null,passwordControls=null;', '  let dictionaryControls=null,passwordControls=null,authControls=null;')
replace_once('function icons(){passwordControls?.sync();dictionaryControls?.hydrate();', 'function icons(){passwordControls?.sync();authControls?.sync();dictionaryControls?.hydrate();')
replace_once("onProfile:()=>{s.view='roles';s.settingsTab='personal';renderBase();persist(false);}", "onProfile:()=>{if(actor===guestActor){authControls?.open();return;}s.view='roles';s.settingsTab='personal';renderBase();persist(false);}")

security_old = '<div><button type="button" class="gm-btn" data-self-password ${loggedIn?\'\':\'disabled\'}>修改密码</button></div>'
security_new = '<div class="gm-account-security-actions">${loggedIn?\'<button type="button" class="gm-btn" data-self-password>修改密码</button><button type="button" class="gm-btn gm-quiet" data-auth-logout>退出登录</button>\':\'<button type="button" class="gm-btn" data-auth-login>登录</button>\'}</div>'
replace_once(security_old, security_new)
helper = directory / 'individual-domain-colors.js'
helper_text = helper.read_text(encoding='utf-8')
assert helper_text.count(security_old) == 1
helper.write_text(helper_text.replace(security_old, security_new, 1), encoding='utf-8')

replace_once('  dictionaryControls=installDictionaryControls(app,', "  authControls=installAuthModal(app,{accounts:()=>s.accountRows,current:()=>actor,guest:guestActor,passwords:passwordControls,beforeOpen:()=>{if(s.mode)return false;closeCoreFilter();closeDayMenu();closeRequirementMenu();resetAxisPresets();for(const details of filterActions.querySelectorAll('details'))details.open=false;return true;},onLogin:name=>{switchViewer(name);s.lastAction='登录：'+name;persist(false);message('已登录');},onLogout:()=>{switchViewer(guestActor);s.lastAction='退出登录';persist(false);message('已退出登录');},escape:esc,icons});\n  dictionaryControls=installDictionaryControls(app,")

first_script = text.index('<script>')
text = text[:first_script] + '<style>\n' + (directory / 'auth-modal.css').read_text(encoding='utf-8') + '\n</style>\n' + text[first_script:]
helper_start = text.index('// Password interaction study.')
text = text[:helper_start] + (directory / 'auth-modal.js').read_text(encoding='utf-8') + '\n' + text[helper_start:]
assert len(text.encode('utf-8')) < 1_000_000
source.write_text(text, encoding='utf-8')
print('Integrated login modal:', len(text.encode('utf-8')), 'bytes')

// Immediate field-row dragging, with checkbox clicks and keyboard reordering retained.
function installFieldReorder(container,{selector,keyOf,onCommit}){
  let drag=null,suppressUntil=0;
  const rows=()=>[...container.querySelectorAll(selector)];
  const finish=commit=>{
    if(!drag)return;
    const current=drag;drag=null;current.row.classList.remove('field-is-dragging');
    container.classList.remove('field-list-dragging');
    if(container.hasPointerCapture?.(current.id))container.releasePointerCapture(current.id);
    if(current.active){suppressUntil=performance.now()+350;if(commit)onCommit(rows().map(keyOf));}
  };
  container.addEventListener('pointerdown',event=>{
    const row=event.target.closest(selector);
    if(event.button!==0||!row||event.target.closest('input,button,a'))return;
    drag={row,id:event.pointerId,x:event.clientX,y:event.clientY,active:false};
  });
  container.addEventListener('pointermove',event=>{
    if(!drag||drag.id!==event.pointerId)return;
    if(!drag.active&&Math.hypot(event.clientX-drag.x,event.clientY-drag.y)<3)return;
    if(!drag.active){drag.active=true;container.setPointerCapture(event.pointerId);drag.row.classList.add('field-is-dragging');container.classList.add('field-list-dragging');}
    event.preventDefault();
    const bounds=container.getBoundingClientRect();
    if(event.clientY<bounds.top+24)container.scrollTop-=12;
    if(event.clientY>bounds.bottom-24)container.scrollTop+=12;
    const target=container.ownerDocument.elementFromPoint(event.clientX,event.clientY)?.closest(selector);
    if(!target||!container.contains(target)||target===drag.row)return;
    const rect=target.getBoundingClientRect();
    if(event.clientY<rect.top+rect.height/2)target.before(drag.row);else target.after(drag.row);
  });
  container.addEventListener('pointerup',event=>{if(drag?.id===event.pointerId)finish(true);});
  container.addEventListener('pointercancel',()=>finish(false));
  container.addEventListener('lostpointercapture',()=>finish(true));
  container.addEventListener('click',event=>{if(performance.now()<suppressUntil){event.preventDefault();event.stopImmediatePropagation();}},true);
  container.addEventListener('keydown',event=>{
    if(!event.altKey||!['ArrowUp','ArrowDown'].includes(event.key))return;
    const row=event.target.closest(selector),list=rows(),index=list.indexOf(row),next=index+(event.key==='ArrowUp'?-1:1);
    if(index<0||next<0||next>=list.length)return;
    event.preventDefault();const key=keyOf(row);
    if(next<index)list[next].before(row);else list[next].after(row);
    onCommit(rows().map(keyOf));
    rows().find(node=>keyOf(node)===key)?.querySelector('input')?.focus({preventScroll:true});
  });
  container.ownerDocument.addEventListener('pointerup',event=>{if(drag?.id===event.pointerId)finish(false);});
}

  function deleteSelectedScheduleSegment(){
    if(!daySelection||!isAdmin()||s.mode)return;
    const {rowId,phaseIndex}=daySelection,row=s.rows.find(item=>item.id===rowId&&!item.deleted&&!item.archived);
    if(!row||!Number.isInteger(phaseIndex)||phaseIndex<0)return;
    const phases=clone(phaseList(row)),removed=phases[phaseIndex];if(!removed||!validDate(removed.start)||!validDate(removed.end))return;
    const before=captureData();phases.splice(phaseIndex,1);
    if(phases.length){
      phases[0].holdBefore=false;row.segments=phases;row.start=phases[0].start;delete row.singleEnd;
      if(!collapseSingleSegment(row))row.days=phases.reduce((total,phase)=>total+phaseDays(phase),0);
    }else{
      row.start='';delete row.singleEnd;delete row.segments;delete row.overtime;delete row.skippedDates;
    }
    if(row.dayMarks){row.dayMarks=Object.fromEntries(Object.entries(row.dayMarks).filter(([date])=>date<removed.start||date>removed.end));if(!Object.keys(row.dayMarks).length)delete row.dayMarks;}
    recordDataChange('删除排期段',row.name,before);closeDayMenu();renderBase();persist(false);
    message(phases.length?'已删除此段排期':'已清空排期日期，预估人天保留');
    app.querySelector(`[data-gantt-name="${rowId}"]`)?.focus({preventScroll:true});
  }

from pathlib import Path
import re

p=Path(__file__).parent
source=p/'requirement-modal-study.html'
s=source.read_text(encoding='utf-8')
backup=p/'requirement-modal-study-before-followups.html'
if not backup.exists(): backup.write_text(s,encoding='utf-8')

def replace_once(before,after):
    global s
    assert s.count(before)==1,(before[:100],s.count(before))
    s=s.replace(before,after,1)

a=s.index('// Password interaction study.');b=s.index('// Product UI study:',a)
s=s[:a]+(p/'password-controls.js').read_text(encoding='utf-8')+'\n'+s[b:]
replace_once("passwordControls.fieldMarkup('gm-account-password',(editing?'重设密码':'初始密码')+(creating?req:''),'data-account-password autocomplete=\"new-password\" placeholder=\"'+(editing?'留空则保留原密码':'设置初始密码')+'\"')", "passwordControls.fieldMarkup('gm-account-password',editing?'重设密码':'初始密码','data-account-password autocomplete=\"new-password\" placeholder=\"'+(editing?'留空则保留原密码':'设置初始密码')+'\"','',creating)")
replace_once("const fields=[{key:'requester',label:'提需人'},{key:'domain',label:'业务域'},{key:'project',label:'项目'}]", "const fields=[{key:'domain',label:'业务域'},{key:'project',label:'项目'},{key:'requester',label:'提需人'}]")
replace_once("let key='requester',selected=new Set()", "let key='domain',selected=new Set()")

archive=(p/'archive-detail-sections.js').read_text(encoding='utf-8')
a=s.index('  function openArchiveDetails(id){');b=s.index('  function renderDrawer(){',a)
s=s[:a]+archive+'\n'+s[b:]
(p/'archive-details.js').write_text(archive,encoding='utf-8')
replace_once("if(['create','edit','archive-details'].includes(s.mode))setDemandTab(activeDemandTab);", "if(['create','edit'].includes(s.mode))setDemandTab(activeDemandTab);")
a=s.index('#gm-ui-study .gm-log-tools {');b=s.index('</style>',a)
s=s[:a]+(p/'records-and-archive.css').read_text(encoding='utf-8')+'\n'+s[b:]

avatar=(p/'avatar-settings.js').read_text(encoding='utf-8').strip()
pattern=r'function mountAvatarSettings\(host,config\)\{[\s\S]*?\n\}'
s,count=re.subn(pattern,lambda _:avatar,s,count=1);assert count==1
presence_file=p/'presence-profile.js';presence=presence_file.read_text(encoding='utf-8')
presence,count=re.subn(pattern,lambda _:avatar,presence,count=1);assert count==1
presence_file.write_text(presence,encoding='utf-8')

replace_once('daySelection={rowId:row.id,date,anchor};','daySelection={rowId:row.id,date,anchor,phaseIndex:current?.phase??-1};')
old='''${action?`<button type="button" role="menuitem" data-day-mark="${action[0]}"><i data-lucide="${action[2]}" aria-hidden="true"></i>${action[1]}</button>`:'''
new='''${action?`<button type="button" role="menuitem" data-day-mark="${action[0]}"><i data-lucide="${action[2]}" aria-hidden="true"></i>${action[1]}</button>${current.phase>=0?'<div class="gm-day-menu-divider" role="separator"></div><button type="button" role="menuitem" class="gm-danger-text" data-segment-delete><i data-lucide="trash-2" aria-hidden="true"></i>删除此段排期</button>':''}`:'''
replace_once(old,new)
replace_once('  function setDayMark(value){',(p/'delete-schedule-segment.js').read_text(encoding='utf-8')+'\n  function setDayMark(value){')
replace_once("if(button.hasAttribute('data-day-mark')){setDayMark(button.dataset.dayMark);return;}", "if(button.hasAttribute('data-segment-delete')){deleteSelectedScheduleSegment();return;}\n    if(button.hasAttribute('data-day-mark')){setDayMark(button.dataset.dayMark);return;}")
assert len(s.encode('utf-8'))<1_000_000
source.write_text(s,encoding='utf-8')
print('Applied password, archive sections, field order, GIF avatars and segment deletion:',len(s.encode('utf-8')),'bytes')

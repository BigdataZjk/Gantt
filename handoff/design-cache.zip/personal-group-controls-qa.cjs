const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-611-0_26.1112.611.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const dir = 'C:/Users/Administrator/.codex/visualizations/2026/11/13/01a1d561-bceb-73c0-a63c-ad1d3664dce9/';
(async()=>{
  const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
  try{
    const page=await browser.newPage({viewport:{width:1220,height:1100},colorScheme:'light'}),errors=[];
    await page.clock.setFixedTime(new Date('2026-11-17T12:00:00+08:00'));page.setDefaultTimeout(5000);page.on('pageerror',e=>errors.push(e.message));
    const fragment=fs.readFileSync(dir+'requirement-modal-study.html','utf8');
    await page.route('http://gantt-defaults.test/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<!doctype html><meta charset="utf-8"><script>window.openai={widgetState:null,setWidgetState(value){this.widgetState=value;return Promise.resolve()}};</script>'+fragment}));
    await page.goto('http://gantt-defaults.test/');
    const nav=view=>page.locator(`[data-nav="${view}"]`).click();
    const read=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('gantt-ui-data-v5')));
    const setting=async()=>{await nav('roles');await page.locator('[data-settings-tab="personal"]').click();};
    const defaults=async(key,value)=>{if(!await page.locator(`[data-requirement-default="${key}"]`).isVisible())await setting();await page.locator(`[data-requirement-default="${key}"]`).selectOption(value);};
    const create=async()=>{if(!await page.locator('[data-new]').isVisible())await nav('gantt');await page.locator('[data-new]').click();};
    const close=async()=>{await page.locator('.gm-drawer [data-dismiss]').first().click();await page.locator('.gm-layer').waitFor({state:'hidden'});};
    await nav('gantt');const base=await read();
    const load=async(edit=()=>{})=>{const data=structuredClone(base);Object.assign(data,{revision:(await read()).revision+1000,actor:'张金科',view:'gantt',logs:[],undoHistory:[],versions:[],drafts:{},personalPreferences:{},collapsedPeople:[],ganttRange:{start:'2026-11-09',end:'2026-12-14'}});data.filters={domain:[],developer:[],requestType:[],status:[],priority:'',query:'',start:'',end:''};edit(data);await page.evaluate(async saved=>{window.dispatchEvent(new CustomEvent('openai:set_globals',{detail:{globals:{widgetState:{privateContent:saved}}}}));await new Promise(requestAnimationFrame);},data);await nav('gantt');return data;};
    await load();await setting();assert.equal(await page.locator('[data-requirement-default="requestType"]').inputValue(),'常规需求');assert.equal(await page.locator('[data-requirement-default="priority"]').inputValue(),'P1');
    await defaults('requestType','数据需求');await defaults('priority','P0');let saved=await read();assert.equal(saved.logs.length,0);assert.deepEqual(saved.rows,base.rows);assert.deepEqual(saved.undoHistory,[]);
    await create();assert.equal(await page.locator('[name="requestType"]').inputValue(),'数据需求');assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P0');
    await page.locator('[name="name"]').fill('保留我写的草稿');await page.locator('[name="priority"][value="P2"]').check();await close();
    await defaults('requestType','常规需求');await defaults('priority','P1');await create();assert.equal(await page.locator('[name="name"]').inputValue(),'保留我写的草稿');assert.equal(await page.locator('[name="requestType"]').inputValue(),'数据需求');assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P2');
    await close();await page.reload();await create();assert.equal(await page.locator('[name="name"]').inputValue(),'保留我写的草稿');assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P2');await page.locator('[name="prd"]').fill('https://example.com/prd/default-test');await page.locator('[name="requester"]').fill('产品小林');await page.locator('[data-save]').click();await page.locator('.gm-layer').waitFor({state:'hidden'});
    saved=await read();assert.equal(saved.rows[0].requestType,'数据需求');assert.equal(saved.rows[0].priority,'P2');assert.equal(saved.logs.length,1);
    await create();assert.equal(await page.locator('[name="name"]').inputValue(),'');assert.equal(await page.locator('[name="requestType"]').inputValue(),'常规需求');assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P1');await close();
    await load(data=>{data.actor='李明';data.personalPreferences={'张金科':{defaultRequestType:'常规需求',defaultPriority:'P2'},'李明':{defaultRequestType:'数据需求',defaultPriority:'P0'}};});await setting();assert.equal(await page.locator('[data-requirement-default="priority"]').inputValue(),'P0');await create();assert.equal(await page.locator('[name="requestType"]').count(),0);assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P0');await page.locator('[name="name"]').fill('编辑者按默认类型录入');await page.locator('[name="prd"]').fill('https://example.com/prd/editor-test');await page.locator('[data-save]').click();await page.locator('.gm-layer').waitFor({state:'hidden'});assert.equal((await read()).rows[0].requestType,'数据需求');
    await load(data=>{data.personalPreferences={'张金科':{defaultRequestType:'数据需求',defaultPriority:'P2'}};});await page.reload();await create();assert.equal(await page.locator('[name="requestType"]').inputValue(),'数据需求');assert.equal(await page.locator('[name="priority"]:checked').inputValue(),'P2');await close();
    await load(data=>{data.actor='__guest__';});await setting();assert(await page.locator('[data-requirement-default="requestType"]').isDisabled());assert(await page.locator('[data-requirement-default="priority"]').isDisabled());
    console.log('Passed: per-account defaults, pristine drafts, typed draft preservation across refresh, submitted draft reset, editor hidden-field defaults and guest read-only state.');

    await load();const initial=await read(),allNames=await page.locator('[data-person-toggle]').count(),expand=page.locator('[data-person-bulk="expand"]'),collapse=page.locator('[data-person-bulk="collapse"]');
    assert(allNames>2);assert(await expand.isDisabled());assert(await collapse.isEnabled());await page.locator('[data-gantt-name="1"]').click();await page.locator('[data-gantt-name="3"]').click({modifiers:['Control']});await collapse.click();
    assert.equal(await page.locator('tr[data-gantt-row]:not([hidden])').count(),0);assert.equal(await page.locator('tr[data-sequence-selected="true"]').count(),0);assert(await collapse.isDisabled());assert(await expand.isEnabled());
    await page.reload();assert.equal(await page.locator('tr[data-gantt-row]:not([hidden])').count(),0);await expand.click();assert.equal(await page.locator('tr[data-gantt-row]:not([hidden])').count(),base.rows.length);assert(await expand.isDisabled());
    await page.locator('[data-person-toggle="张金科"]').click();assert(await expand.isEnabled());assert(await collapse.isEnabled());await expand.click();
    const header=await page.locator('[data-person-group="张金科"]').evaluate(el=>({height:el.getBoundingClientRect().height,font:parseFloat(getComputedStyle(el.querySelector('button')).fontSize),bg:getComputedStyle(el.querySelector('th')).backgroundColor,body:getComputedStyle(document.querySelector('tr[data-gantt-row] th')).backgroundColor}));assert(header.height>=36&&header.height<44);assert.equal(header.font,14);assert.notEqual(header.bg,header.body);
    const wrap=page.locator('.gm-calendar-wrap');await wrap.evaluate(el=>el.scrollLeft=160);assert(await page.locator('[data-person-group="张金科"] th').evaluate(el=>{const a=el.getBoundingClientRect(),b=el.closest('.gm-calendar-wrap').getBoundingClientRect();return Math.abs(a.left-b.left)<2;}));
    saved=await read();assert.deepEqual(saved.rows,initial.rows);assert.deepEqual(saved.logs,initial.logs);assert.deepEqual(saved.undoHistory,initial.undoHistory);
    await load(data=>{data.actor='__guest__';});await collapse.click();assert.equal(await page.locator('tr[data-gantt-row]:not([hidden])').count(),0);await expand.click();assert.equal((await read()).logs.length,0);
    console.log('Passed: bulk collapse/expand, no-op disabled buttons, selection cleanup, remembered folds, guest access, unchanged schedules/audit and stronger frozen group headers.');

    await load();const end=page.locator('[data-axis-edge="end"]'),presets=page.locator('.gm-axis-presets'),start=await page.locator('[data-axis-edge="start"]').inputValue();assert(await presets.isHidden());await end.hover();assert.deepEqual(await presets.locator('button').allTextContents(),['30D','60D']);
    await page.locator('[data-axis-days="30"]').click();assert.equal(await end.inputValue(),'2026-12-17');assert.equal(await page.locator('[data-axis-edge="start"]').inputValue(),start);
    await page.locator('[data-axis-days="60"]').click();assert.equal(await end.inputValue(),'2027-01-16');assert.equal(await page.locator('[data-axis-edge="start"]').inputValue(),start);
    await page.mouse.move(4,4);assert(await presets.evaluate(el=>el.hidden||el.classList.contains('gm-presets-closing')),'Slide-out starts immediately, with no lingering delay');await page.waitForTimeout(110);assert(await presets.isHidden());
    await end.hover();const a=await end.boundingBox(),b=await presets.boundingBox();await page.mouse.move(b.x+15,a.y+a.height/2,{steps:8});assert(await presets.isVisible());await page.mouse.move(4,4);await page.waitForTimeout(20);await end.hover();await page.waitForTimeout(110);assert(await presets.isVisible());
    const metrics=await page.locator('[data-new],[data-axis-edge],.gm-filter-control,[data-person-bulk]').evaluateAll(nodes=>nodes.map(el=>el.getBoundingClientRect().height));assert(metrics.every(height=>Math.abs(height-32)<.1),metrics.join(','));
    await create();assert.equal(await page.locator('[name="name"]').evaluate(el=>el.getBoundingClientRect().height),32);assert.equal(await page.locator('[data-save]').evaluate(el=>el.getBoundingClientRect().height),32);await close();
    console.log('Passed: 30D/60D end-only presets, immediate 80ms dismissal, safe pointer travel, re-entry and consistent 32px standard controls.');

    await page.goto('file:///'+dir+'modal-preview-qa.html');const ui=page.frameLocator('iframe');await ui.locator('[data-nav="gantt"]').click();await ui.locator('[data-axis-edge="start"]').fill('2026-11-12');await ui.locator('[data-axis-edge="end"]').fill('2026-12-04');await ui.locator('[data-axis-edge="end"]').hover();await page.waitForTimeout(200);await ui.locator('.gm-app').screenshot({path:dir+'personal-groups-light-qa.png'});
    await ui.locator('[data-theme-toggle]').click();await page.waitForTimeout(320);await ui.locator('[data-axis-edge="end"]').hover();await ui.locator('.gm-app').screenshot({path:dir+'personal-groups-dark-qa.png'});
    await ui.locator('[data-nav="roles"]').click();await ui.locator('[data-settings-tab="personal"]').click();await ui.locator('.gm-app').screenshot({path:dir+'new-defaults-dark-qa.png'});
    for(const width of [736,360,320]){await page.setViewportSize({width,height:1100});for(const view of ['gantt','pool','archive','roles']){await ui.locator(`[data-nav="${view}"]`).click();assert(await ui.locator('.gm-app').evaluate(el=>el.scrollWidth<=el.clientWidth+1),'Overflow on '+view+' at '+width);}await ui.locator('[data-nav="gantt"]').click();await ui.locator('[data-axis-edge="end"]').hover();assert(await ui.locator('.gm-axis-controls').evaluate(el=>el.scrollWidth<=el.clientWidth+1));}
    assert.deepEqual(errors,[]);console.log('Passed: official preview, light/dark group/default settings and responsive layout down to 320px.');
  }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});

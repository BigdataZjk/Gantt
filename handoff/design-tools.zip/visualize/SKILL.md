---
name: visualize
description: "Create visualizations and interactive tools directly in conversation. Proactively use to show how something works; explore 'what happens when', 'what changes', or 'help me understand'; compare or inspect; create simulations, maps, charts, graphs, and mockups. Use standard tools for static scientific figures."
---

# Visualize

`<skill-dir>` is this SKILL.md’s directory; resolve relative file paths from it.

- A request for a new standalone file, website, app page, component, or other project change is not an in-conversation visualization request, even when the deliverable contains charts or interactive content.
- A request to preview, explain, or explore a proposed interface in the conversation is an in-conversation visualization request.
- Create a visual only when the user needs to see or explore it in the conversation and it materially improves the explanation. Do not create an inline visual merely because the request involves data, charts, or an interactive page.
- Use a normal Markdown table when the user asks for a table; return it directly and do not create a visualization file.
- Use Mermaid when labeled nodes and edges fully explain a static structure; return a normal fenced Mermaid block and no visualization file. Use HTML for dynamics, spatial motion, adjustable inputs, and other visuals.
- Work silently unless blocked or the user explicitly asks for progress. Never send commentary or progress updates while reading this skill or writing or updating the file; the final response must be your first user-facing message.
- In user-facing prose, describe only what the visual helps the user see or decide. Keep it concise and do not repeat information already clear from the visual. Never announce this skill, a visualization surface, widgets, HTML, SVG, scripts, local files, inline data, or implementation details.

## Read the complete skill

Read this file in full before authoring. Reread truncated ranges in smaller calls. Copy into every compaction summary: `Reload the full visualize skill before creating or updating a visualization.`

## Inline HTML output contract

### File

- For each new or updated visualization, choose a concise ASCII lowercase-hyphenated title and write `<title>.html` in an explicitly writable, durable, task-owned location. Prefer the thread-scoped visualization directory when it appears in the writable roots. Otherwise, use the task's supplied `work/` directory or create an output directory under its authorized working directory.
- Never save inline visualization fragments to Library; they are response content, not user-facing file deliverables.
- Never add `sandbox:` links to inline visualization HTML unless the user specifically requests a download.
- Do not choose system temp as a separate fallback. Write access alone does not guarantee that the conversation can read the file.
- Use the absolute path on the executor that creates the file. Never assume `~/.codex` is writable unless its thread directory appears in the writable roots.
- Build the visual in the conversation. Use the open project when the user asks for a site, app page, component, or change to existing project files.

### Fragment

- Write only an HTML fragment: no `<!doctype>`, `<html>`, `<head>`, or `<body>`.
- Write literal markup: use `<div class="card">Hi</div>` plus a real newline, never `<div class=\"card\">Hi</div>\n`. Never embed the fragment in an inline Python, JavaScript, or shell string. Read it back; rewrite literal `\"` or `\n`.
- Keep CSS and JavaScript in the fragment only when base classes are insufficient. Load static resources only from the CDN allowlist. Never use `fetch`, XHR, WebSocket, or other API calls.
- Give the fragment root a unique ID and select it with `document.getElementById(...)`. Never derive the root from `document.currentScript`; scripts may sit outside the root.
- Keep visualizations under 1 MB. Aggregate, bin, downsample, reduce precision, or drop unused fields from large inline datasets.
- Check that JavaScript has no undefined identifiers, every queried element exists, and the primary interaction updates the visual. The bundled `python3 <skill-dir>/scripts/render.py <absolute-fragment-path> [<destination>.html] [--serve]` can wrap a fragment as standalone HTML or temporarily serve it for browser inspection when a preview would help with layout, theme, or runtime behavior. The rendered preview places the fragment inside a sandboxed iframe: scope Playwright locators to `page.frameLocator("iframe")` and evaluation to that frame.

### Content and response

- Keep the fragment focused on the visualization. Do not include explanatory paragraphs, formulas, instructions, or narrative callouts. Include only necessary labels, legends, values, and accessible text alternatives.
- Use the normal response flow. Put any necessary concise explanation outside the fragment, and add this visualization content reference on its own line where the visual should appear, using the absolute executor-side file path:

```text
visualize{"path":"<absolute-path>/<title>.html"}
```

- Use wide mode for request waterfalls, error stack traces, flame charts, and week or month calendars, even when shown alone. Keep a day calendar at regular width. Also use wide mode for a full-screen desktop app mockup with its application shell, or when several compact chart panels must stay side by side for a readable comparison. Keep other single plots, maps, grids, diagrams, timelines, contained mockups, dialogs, and mobile screens at regular width. Stack independent views vertically. To request the expandable inline surface (up to 1,024px), add `"mode":"wide"` alongside `"path"` in the final response reference:

```text
visualize{"path":"<absolute-path>/<title>.html","mode":"wide"}
```

- Whenever you create or update an inline visualization, include its content reference only in that same turn's final response (never in commentary or progress updates), even when editing an existing file or reusing a path shown in an earlier turn.
- The JSON object may also include a `title` when needed.
- Emit only the content reference for the fragment. Never announce it as an artifact, website, output, attachment, link, or download, and never add a Markdown link to it. Do not append a Markdown table or repeat the visual's data; add at most one short conclusion when the user needs an explanation.

### External resources

- The CSP allows `cdnjs.cloudflare.com`, `esm.sh`, `cdn.jsdelivr.net`, `unpkg.com`, `fonts.googleapis.com`, `fonts.gstatic.com`, and `fonts.bunny.net`, plus version-pinned scripts under `https://persistent.oaistatic.com/plugins/visualize/`. Other origins and paths are blocked and fail silently.

## Exporting an existing visualization

- Keep the fragment as the editable inline source. When the user explicitly asks to save, export, or publish a visualization that is already shown in the conversation, render it with `python3 <skill-dir>/scripts/render.py <absolute-fragment-path> <destination>.html`.
- Apply this export flow only when the user explicitly asks to turn the existing inline source or visualization into a website. For a general website request, build a new responsive site in the output directory or open project, using Sites when appropriate, without applying this skill's guidance.
- Keep only `window.openai.widgetState` and `window.openai.setWidgetState` calls from window\.openai.\* when exporting: the standalone wrapper supplies fallback state storage. Replace other host-only interactions before using the standalone HTML outside Codex.
- When the user asks to publish or host an existing visualization and the `sites` skill is available, use it to choose the project, write the rendered standalone document as `index.html`, and publish it.
- If Sites is unavailable, offer the standalone HTML without claiming it was published.

## Runtime styles

### Color

- In each color pair, the base token is a surface and its `-foreground` token is the content on that surface. `--muted` is a surface fill; use `--muted-foreground` for secondary text.
- Make every fill, stroke, text, border, shadow, chart, and canvas color theme-aware. Never hardcode light or dark palettes such as white panels, off-white backgrounds, black text, slate strokes, or Tailwind color literals.
- Keep text readable against its actual background. Muted or secondary colors must retain clear contrast; never use `.text-muted` inside `.card` or another filled container unless its background preserves that contrast.
- Available theme variables include `--background`, `--foreground`, `--card`, `--card-foreground`, `--popover`, `--popover-foreground`, `--primary`, `--primary-foreground`, `--secondary`, `--secondary-foreground`, `--muted`, `--muted-foreground`, `--accent`, `--accent-foreground`, `--destructive`, `--border`, `--input`, `--ring`, `--blue`, `--orange`, `--green`, `--red`, `--purple`, and `--yellow`. Use `currentColor` inside SVG.
- Never add decorative borders, outlines, or strokes to progress tracks, meters, bars, stacked segments, or other filled quantitative marks. Use a subtle neutral or translucent track and distinguish marks with fill, contrast, spacing, or opacity.
- Use `--viz-series-1` for one measure or active state. Use `--viz-series-2` through `--viz-series-6` only for important persistent category, series, or status identity; never give every peer a different color by default.
  - For categorical tiles or nodes, prefer a soft low-opacity series fill with a neutral or transparent border; never color every outline.
  - Keep mappings stable and pair color with labels, shapes, or line styles.
  - Secondary series colors are theme-derived; never assume hues or use them decoratively.
- When color encodes a category or series, apply it consistently to the corresponding visual marks—not just the legend—and keep large-area fills subtle.
- Use series colors only for chart lines, marks, and legend swatches. Keep values, axis text, and direct labels in `--foreground` or `--muted-foreground`.
- Keep chart grids and inactive structure thin and neutral. Use 1-2px neutral structural paths; never thicken, dash, or double-stroke the whole structure.
- Use `.btn-primary` for high-emphasis actions; its neutral fill is supplied by the utility. Use `--primary` and `--primary-foreground` for filled selected, active, or pressed controls. Reserve `--accent` and `--accent-foreground` for subtle interactive surfaces and soft highlights. Buttons with `aria-pressed="true"`, `aria-selected="true"`, or `.is-selected` already use the primary pairing; `.nav-pills .nav-link.active` keeps selection neutral.

### Typography

- Scale type with `--font-size-base`. Use normal text by default and `.text-small` only for secondary annotations; at the default scale these are 14px and 12px. Never make supporting text smaller than 11px.
- `h1`, `h2`, and `h3` are available; use one concise visible heading for a self-contained chart or graph, with short panel headings only when needed. Do not restate the prompt or add a redundant title to other visualizations.
- Use only weights `400` and `500`. Never set custom font sizes or line heights.
- Use `.tabular-nums` on changing or aligned numbers. Avoid it for editorial or decorative numerals.
- Headings and paragraphs have zero margins. Add root-scoped spacing with `calc(var(--font-size-base) * ...)`: 1× between content blocks or charts and before section headings, 0.5× after `h1` or from a heading to a visual, and 0.25× from `h2`/`h3` to supporting text.
- Apply each gap once with layout `gap` or margins, keep title/subtitle groups together, and leave the outer edge unpadded.

## Composition

Read the guides relevant to the visualization being created or updated. These guides govern presentation; they do not change when to create a visualization.

Choose the smallest composition that fits.

- Prefer interaction detail over permanent panels, toolbars, repeated legends, or long stacks. Add only requested controls, use one mechanism per state, and never invent search, filter, or reset controls.
- Keep filters, selections, and other presentation-only interactions local. For drill-down actions that ask Codex to investigate or explain selected data, call `await window.openai.sendFollowUpMessage({ prompt, title })`, where the optional `title` is a concise confirmation-dialog heading of up to 250 characters. Include the selected values and requested investigation in the prompt, and label the action clearly.
- Show only metrics that explain the requested behavior. Put live values in control headers or on the visual before cards. Treat maxima as ceilings, not targets. Never invent qualitative scores, status cards, or secondary fact grids to fill space.

### Remembering inline interaction state

- Read saved state from `window.openai.widgetState` when rendering. Listen for `openai:set_globals` and apply `event.detail.globals.widgetState` when present. Use defaults for missing or incompatible state.
- After meaningful interactions, call `window.openai.setWidgetState({ modelContent, privateContent }).catch(() => {})`. Updates are optimistic. Both fields accept JSON or `null` and may be omitted (treated as `null`). Each call replaces the snapshot; keep it under 16 KiB. Never save on load or state events.
- Put choices useful for follow-up questions in `modelContent`, UI details worth restoring in `privateContent`, and transient or recomputable values in memory. Only `modelContent` may reach the model: delivery is best-effort and not guaranteed across clients. Never rely on it; saving never starts a turn. No secrets or images.

### UI mockups

For requests to design, preview, or explore a product interface—including a standalone dialog, card, or control—read [mockups.md](mockups.md) for product styling, variant carousels, and design controls.

### Built-in widgets

Use these prebuilt widgets when they fit the data. Read the corresponding guide:

- Calendar (`widgets/calendar.md`): day, week, and month schedules.
- Waterfall (`widgets/waterfall.md`): timed request spans.
- Flame chart (`widgets/flamechart.md`): sampled CPU stacks.
- Stack trace (`widgets/stacktrace.md`): error call stacks.

### Interactive explainer or simulation

- Use compact controls or status, one compact dominant visual, and at most one single-line selected-state detail. Default to no summary cards; allow up to three only when changing metrics are central.
- Crop empty space and fit the available inline width. For step-throughs, add only requested step controls and update one current visual; never add parameter controls, formulas, metric cards, or side-by-side steps unless asked.

### Maps

For geographic maps, including maps within another visualization, read [maps.md](maps.md) for sourced geometry, projection, and map-specific validation.

### Dense categorical grid

- Use one compact horizontal selected-item summary, then a grid with exactly one readable identifier per cell, then one small legend. Render only that identifier as visible cell text; put all other metadata in an accessible label or one summary line, not badges or fact grids. Allow only selection unless asked.

### Part-to-whole or time allocation

- Use compact metrics and one stacked chart of category allocation per period. Never substitute totals-only bars or duplicate it as a heatmap and totals chart.

### Illustrated overviews

- For a walkthrough of successive screens, draw one illustrated HTML/SVG overview. Show all the named screens together, connect their sketches in order, and mark the cue that identifies each step. For a question about how a visible field changes, use the illustrated HTML/SVG overview to show its before and after values on one recognizable screen or record. Use the same view to show how parts fit or to mark a matching or changed field on each record. Read `<skill-dir>/technical-illustrations.md` for the drawing style.

## Layout and accessibility

- Use semantic HTML, keyboard-accessible controls, and concise labels.
- Use `aria-live="polite"` for dynamic results, selections, and simulator updates. Use `role="alert"` for validation errors. Do not announce every hover or animation frame.
- Keep the top-level surface transparent and unframed, and fill the available conversation width. Design for 736px, or 1,024px in wide mode, and support widths down to 320px. Stack side-by-side content when it no longer fits.
- At every supported width, text, controls, cards, toolbars, and dynamic content must fit without overlap or clipping. Reflow by stacking or wrapping; use `.table-responsive` only when table columns cannot fit. The host sizes the frame to its content, so avoid fixed outer widths, other horizontal overflow, internal scrolling, `position: fixed`, and viewport-height layouts.
- Size every SVG from its actual container. At narrow widths, reduce ticks, declutter annotations, and keep visible text at least 11 screen pixels; never shrink a fixed-width `viewBox`.
- Keep native tab order; never add `tabindex`.
- Use native `button`, `input`, `select`, and `textarea` elements with matching utilities; never recreate controls.
- Keep browser or utility focus styles; never override them.
- On coarse pointers, provide non-overlapping effective targets about 44px by 44px without breaking 320px layouts; visible icons and marks may stay small. Keep fine-pointer controls compact, and let shared utilities own touch sizing and at least 16px editable-field text.
- Keep essential content and actions available without hover.
- Try to keep 90×50px clear for host controls (top-right in LTR hosts, top-left in RTL hosts).

## Design system

- Let utilities own geometry, appearance, and interaction. Use the matching utility for every button and form control. Never restyle utilities, descendants, or pseudo-elements: no custom sizes, spacing, borders, radii, shadows, colors, or interaction states.

### Surfaces and layout

- `.card`: The only card-like HTML surface. Use its base class unchanged for a necessary numeric summary, selected-item summary, or bounded interactive field. Before adding a fill, border, radius, or shadow to any layout container, either use `.card` or leave it transparent and unframed; never recreate card chrome on rows, panels, tiles, sections, or wrappers. Keep charts, maps, diagrams, tables, controls, and the whole visualization unframed. Never nest cards; show 2-4 summaries near the top only when useful. Structural groupings and repeated content are not bounded interactive fields. Organize them with layout or visual marks, not container chrome.
- `.viz-stat`: Use a summary `.card` with one muted label, one `.viz-stat-value`, and at most one short context or delta line.
- `.viz-grid`: Use for peer metrics or choices instead of a custom grid. It creates as many equal-width columns as fit and stacks when narrow. Never use it for the whole visual or a horizontally scrolling card row. Keep groups to 2-3 columns at 736px and controls in a separate row.
- `.viz-row`: Use as a wrapping horizontal group with centered related values or inline actions that may wrap when narrow.
- `<hr>`: Use a native horizontal rule for a subtle theme-aware separator.
- `.nav.nav-pills` + `.nav-link`: Use the accessible, interactive [Tabs](#tabs) API below.
- `.progress` + `.progress-bar`: `<div class="progress" role="progressbar" aria-label="Progress" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><div class="progress-bar" style="width:25%"></div></div>`
- `.viz-tile`: Add to a selectable dense-grid `.btn`; it stretches to fill its grid cell, preserves category fill, and uses an accent ring instead of solid selection. Never add another selected, pressed, border, outline, or shadow rule.
- `.viz-badge`: Use as a compact display-only accent pill for a short status, category, or value; never as a button.
- `.viz-controls`: Use as a wrapping row for controls affecting the same visualization. Keep button groups compact. Put labeled fields directly inside as `.form-label`; fields form at most two columns and stack when narrow.

### Tabs

- `.nav.nav-pills[role="tablist"]`: Group content-width native `.nav-link[role="tab"]` buttons and label the group with `aria-label`. Add `.nav-justified` only when tabs should share and fill the row equally.
- `.nav-link[role="tab"]`: Give each button a unique `id`, `type="button"`, `aria-controls`, and `aria-selected`. Mark the initial tab `.active` and `aria-selected="true"`; use `disabled` or `aria-disabled="true"` when needed.
- `[role="tabpanel"]`: Match `id` to its tab's `aria-controls`, set `aria-labelledby` to the tab's `id`, and mark inactive panels `hidden`. Tabs can have separate panels or point to one shared panel.
- Tab behavior is already implemented by the JavaScript runtime and does not need to be wired.

```html
<div class="nav nav-pills" role="tablist" aria-label="Platform">
  <button
    class="nav-link active"
    id="mac"
    role="tab"
    aria-controls="mac-panel"
    aria-selected="true"
    type="button"
  >
    macOS
  </button>
  <button
    class="nav-link"
    id="linux"
    role="tab"
    aria-controls="linux-panel"
    aria-selected="false"
    type="button"
  >
    Linux
  </button>
</div>
<div id="mac-panel" role="tabpanel" aria-labelledby="mac">macOS content</div>
<div id="linux-panel" role="tabpanel" aria-labelledby="linux" hidden>
  Linux content
</div>
```

### Controls

- Use `.cursor-interaction` on custom interactive elements, including locally styled widget controls. It follows the host cursor preference; never hardcode `cursor:pointer`. Shared controls already apply it. Preserve text, drag and disabled cursors for those states.

- Place related inputs and buttons on one row, aligned at their vertical centers. Put labels and values on a separate row above them.
- `.btn`: Use for a content-sized secondary action. Add `.btn-primary` for one main action per control group or `.btn-ghost` for low emphasis.
- `.btn-block`: Add to a `.btn` only when the action should intentionally fill the available inline space. Never use it for ordinary row actions.
- `<a>`: Use for links. Add `.btn` to style a link as a button.
- `[data-tooltip]`: Use for concise supplementary plain text on static or dynamic triggers; the sandbox handles hover, focus, and touch and creates `.tooltip` elements. Keep essential content visible and triggers labeled. Never use `title`, custom markup, or initialization. Example: `<button type="button" data-tooltip="Reset view">Reset</button>`.
- When a visible label is truncated, put its full text in `data-tooltip` on the existing accessible trigger so hover, focus, and tap reveal it.
- `[data-tooltip-placement]`: Optionally prefer `top` (default), `right`, `bottom`, or `left`; collision handling may flip it.
- `.form-check`: Prefer a wrapping `<label class="form-check">` around the native `.form-check-input` and `.form-check-label` text so the whole row is tappable. An explicit label with matching `for` and input `id` also works.
- `.form-switch`: Add to `.form-check` around a native checkbox.
- `.form-control`: Pair a native text, date, file, or color input—or a textarea—with `.form-label`.
- `.form-control-color`: Add to `.form-control` for a compact native color input.
- `.form-select`: Pair a native select with `.form-label`.
- `.form-range`: Pair a native range with a visible label; put its current value and units immediately before it.

### Tables

- `.table`: Use on a semantic table for a quiet, unframed data view. It provides wrapping cells and subtle horizontal dividers without vertical gridlines. Use sentence case for headers.
- `.table-responsive`: Wrap a table when its columns cannot fit at narrow widths. It contains horizontal overflow without clipping the visualization.
- `.table-sm`: Add to `.table` when more rows need to fit; it reduces cell padding without shrinking text.
- `.text-end`, `.text-center`, and `.text-nowrap`: Use inside `.table` for numeric/end alignment, centered values, or values that must stay on one line. Numeric cells use tabular figures when end-aligned.

### Text

- `.text-small`: Use for the smallest host-scaled secondary chart labels and annotations, never below 11px or for essential content.
- `.text-muted`: Use for secondary units, captions, timestamps, and context, never essential values or labels.
- `.text-destructive`: Use only for error or validation text the user needs to notice or act on.
- `<code>`: Use for inline commands, file names, symbols, or short references; put multiline code in `<pre><code>`.
- `.sr-only`: Use for visually hidden accessible text.

## Charts

**General Instructions:**

- Resolve theme colors before passing them to canvas or chart APIs that cannot parse CSS variables or `light-dark(...)`; redraw when the theme changes.
- Use a tooltip unless it would distract from a simple, directly labeled chart. Keep chart-library tooltips and grouped legend interactions native; never replace them with a custom one-point tooltip.
- Animate transitions between chart states so lines and marks move to their new values, resampling paths when point counts differ. Do not animate initial appearance or use fade-only effects; never loop motion, and honor `prefers-reduced-motion`.
- Include labeled axes, units, and directly labeled important values. Give every chart, SVG, canvas, and widget a concise screen-reader summary using a role and accessible name or description, SVG `<title>`/`<desc>`, fallback text, or an `.sr-only` heading or description.
- Format calendar-year ticks as whole years without digit grouping (e.g. `1920`). Keep the time scale proportional when observations are unevenly spaced.
- Reserve space for the longest formatted label at every supported width. Axis ticks are secondary and may use `.text-small` when space is tight. Never overlap or clip text against marks, axes, legends, labels, or edges; move or reduce labels rather than squeeze them.
- Add a legend only when multiple series cannot be labeled directly.
- Pair color with shape or text so meaning never depends on color alone.

<!-- BEGIN CODEX-ONLY CHARTS -->
### Standard Chart Families

For standard chart components, the selected family and shared contract govern rendering, composition and validation, taking precedence over general guidance for this chart artifact only, including its surrounding text, tables and controls. A chart composition may include a short analytical summary and an exact-values table. The CSP additionally permits `https://persistent.oaistatic.com/plugins/visualize/charts/` for the pinned component runtime.

These are built-in chart families that are higher quality and faster to render. If any are relevant to the user's request, read the relevant chart family file(s) and applicable shared chart guides to provide a complete visualization. Each family file contains its exact interface; the shared instructions contain the complete working HTML mounting example. Write or adapt freely; copying is optional.

It's critical to read the needed files in a single complete batch—some batches approach 15,000 tokens—to ensure quality and reduce latency from repeat reads.

- `charts/line.md`
- `charts/area.md`
- `charts/bar.md`
- `charts/pie.md`
- `charts/histogram.md`
- `charts/waterfall.md`
- `charts/heatmap.md`
- `charts/scatter.md`
- `charts/funnel.md`
- `charts/box-plot.md`
- `charts/sparkline.md`
- `charts/ranking.md`
- `charts/sankey.md`

When using a standard chart family, always read `charts/instructions.md` and any other guides below that apply to the requested output.

- `charts/instructions.md`: Whenever using a standard chart component, for shared configuration, mounting, updates and validation.
- `charts/cartesian-inputs.md`: For line, area, bar or sparkline charts, including data bindings, ordering and missing values.
- `charts/composition.md`: For charts with nearby analytical text, styled tables or collapsible sections.
- `charts/controls.md`: For native inputs that filter or calculate data and update a chart.
- `charts/coordinated.md`: For controls that synchronize charts and readouts, or for saved interaction state.
- `charts/annotations.md`: For reference lines, reference bands, point labels, or uncertainty marks called for by the shared chart rule.

### Fallback chart rendering

- Prefer inline SVG for simple charts and version-pinned approved-CDN libraries when native interaction, scales, legends, or layout materially improve the result.
- Prefer `<line>` for straight SVG axis, tick and connector segments. Explicitly set `fill="none"` on stroke-only `<path>` or `<polyline>` axes and leader lines: SVG fills open paths by implicitly closing them, so an L-shaped axis can otherwise become a filled triangle. Scope this to stroke-only geometry; preserve intentional fills on area bands, filled markers and other chart shapes.
- For a custom chart, check its data, calculations and geometry offline. Use an available preview only to diagnose concrete rendering or interaction breakage, or for explicitly requested testing. If rendering was not inspected, do not claim it was verified.
- For SVG, attach `data-tooltip` directly to the real pointer-accessible mark and include its label, value, and units; the sandbox handles themed positioning, keyboard focus, and touch.
- Keep decorative SVG fills, bands and leader lines from intercepting interactive marks (`pointer-events: none`). When observations overlap, use a grouped tooltip or series selection/focus so every observation remains inspectable; do not rely on tiny exposed edges. When a preview is needed under the validation policy, inspect an overlapping observation in the primary interaction.
- Scope SVG styles to the chart class. Never target every `svg` in a container that also contains Lucide icons.

<!-- END CODEX-ONLY CHARTS -->
## Icons and mockups

- Use the sandbox-provided global `lucide`. Add an icon name with `data-lucide`:

  ```html
  <i data-lucide="search" aria-hidden="true"></i>
  ```

- Never author inline icon SVG or icon paths. Use only supplied Lucide names; the sandbox replaces each placeholder with a host-sized `currentColor` SVG. Reserve authored inline SVG for charts and data marks.
- Mark decorative icons `aria-hidden="true"`. Put action icons inside labeled controls; use a visible label or `aria-label` for icon-only actions.
- Let the sandbox initialize static icons after the fragment without blocking first render. After adding icons dynamically, use `lucide.createIcons({ attrs: { width: 16, height: 16 } })`.
- Never load Lucide or another icon library from the network.
- Use visibly labeled buttons and inputs for small interactions. Keep all presentation-only interaction local to the fragment and make the first render useful before input changes.
- Use semantic controls, realistic spacing, and restrained chrome for mockups. Never fake product screenshots when inspectable UI is needed.
